/*  Bondgraph Modeling System, version 1.0, 11 Jan 2001
 *  Copyright (C) 2001  Michigan State University
 * 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of version 2 of the GNU General Public License as
 *  published by the Free Software Foundation.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *  
 *  Jianjun Hu            (hujianju@msu.edu)
 *  
 *  Computer Science Department
 *  EB 2340 GARAGe Group
 *  Michigan State University
 *  East Lansing, Michigan  48824
 *  USA
 *  
 */
// Bond.h: interface for the CBond class.
////////////////////////////////////////////////////////////////////////



#if !defined(AFX_BOND_H__042E35A8_A770_11D4_BB82_00105A06D5B4__INCLUDED_)

#define AFX_BOND_H__042E35A8_A770_11D4_BB82_00105A06D5B4__INCLUDED_



#if _MSC_VER > 1000

#pragma once

#endif // _MSC_VER > 1000



#include "Component.h"

#include "Junction.h"

#include "Element2Port.h"

#include "Port.h"
#include <iostream>



class CBond : public CComponent  

{

public:
	virtual void Reset();

	void InsertElement2Port(CElement2Port* pElement, CBond* pBond);

	void InsertJunction(CJunction *pJunction, CBond * pBond);
	CBond& operator =(CBond &bond);

	char m_Label;//label for bond type(connecting what):  'U': source, 'S':I,C, 'R': R, 'J': J0,J1,GY,TF
	CPort *	m_pFromPort;

	CPort * m_pToPort;

	CBond();

	virtual ~CBond();
	virtual void read(std::istream& ioIS);
	virtual void write(std::ostream& ioOS) const;



};



#endif // !defined(AFX_BOND_H__042E35A8_A770_11D4_BB82_00105A06D5B4__INCLUDED_)

