/*  Bondgraph Modeling System, version 1.0, 11 Jan 2001
 *  Copyright (C) 2001  Michigan State University
 * 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of version 2 of the GNU General Public License as
 *  published by the Free Software Foundation.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *  
 *  Jianjun Hu            (hujianju@msu.edu)
 *  
 *  Computer Science Department
 *  EB 2340 GARAGe Group
 *  Michigan State University
 *  East Lansing, Michigan  48824
 *  USA
 *  
 */
// BondGraphDynamic.h: interface for the CBondGraph class.
// This class implements dynamic memeory allocation of Bondgraph objects. 
// Elements in the bondgraphs are allocated dynamically.

//

//////////////////////////////////////////////////////////////////////



#if !defined(AFX_BONDGRAPHCLASS_H__975DB084_B50B_499B_BAA0_D89F8DA5C99A__INCLUDED_)

#define AFX_BONDGRAPHCLASS_H__975DB084_B50B_499B_BAA0_D89F8DA5C99A__INCLUDED_



#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//simplification option
#define SIMPLIFY_KEEP_EMBRYO		0
#define SIMPLIFY_ALL				1
#define SIMPLIFY_EXTRA_JUNCTION		2

#define NON_WRITEHEAD -10

#include "Junction.h"
#include "Bond.h"
#include "Component.h"
#include "GraphPrint.h"
#include <vector>
#include <iostream>

//for matrix operation
//#define WANT_STREAM                  // include.h will get stream fns
//#define WANT_MATH                    // include.h will get math fns
                                     // newmatap.h will get include.h
#include "newmat.h"	// need matrix output routines
using namespace NEWMAT;

//state equation formulation struct definition
struct PI{ //element pos index
	char part; //which part of Jmatrix
	int	index;// no of row of col
};
struct TI{
	int type; // type: EFFORT or FLOW//HJJ
	int index;// row no of col
};

typedef vector<TI> TIVector;

struct causalbase{
	int no;//sequence no of bond lable
	char label;//label for bonds
	int porti;//the Nth port of component
};

class CBondGraph  
{
public:
	void CleanVisitedLabel();
	void ClearDepthFlag();
	int GetMaxDepth();
	int nJunction1s();
	int nJunction0s();
	int nElements();
	int nFlowSources();
	int nEffortSources();
	int nTransformers();
	int nGyrates();
	int nResistors();
	int nInductors();
	int nCapacitors();
	int nPorts();
	int nBonds();
	int nJunctions();
	int SetCausalityKS();
	void Save(char* filename);
	void ClearPowerDirection();
	int CheckPowerDirection();
	int SetPowerDirection();
	void Calculate_A1();
	void Calculate_D();
	void Calculate_C();
	void Calculate_B();
	void Calculate_A();
	int FormulateStateEquation();
	void ClearCausality();
	int m_CausalityStatus;
	void ReportCausality();
	int CheckCausality();
	void Clean();
	// remove an 1 port element from a bond graph
	void removeElement1Port(CComponent* inElement);
	int SetCausality();
	CBondGraph();
	virtual ~CBondGraph();
  	virtual void        read(std::istream& ioIS);
  	virtual void        write(std::ostream& ioOS);

	int GetNewID(int Type=0){
		MaxID++;//All ID
		
		if(Type == BOND){ //Bond ID
			MaxBondID++;
			return MaxBondID;
		}
		else{//Other Component ID
			MaxComponentID++;
			return MaxComponentID;
		}
	};

	void Report(int What=BONDGRAPH_ALL);
	CGraphPrint* graph;//used for graphical bondgraph output


//Bondgraph link Lists
	list<CJunction*>	JunctionList;
	list<CBond*>		BondList;
	list<CComponent*>	ElementList;

//BondGraph Element Statistics
	int MaxID;// The max component ID of all the bondgraph, used to denote the identity of component
	int MaxBondID;
	int MaxComponentID;
	bool m_bRefreshed;

//state equation formulation Data structures
	Matrix Smat;
	Matrix Lmat;
	Matrix JFE, JF, JE, JI, Jreduced;
	Matrix A, B, C, D;
	double** A_;
	double** B_;
	double** C_;
	double** D_;

	//Postion index
	PI trow, tcol;
	//causality label
	causalbase base;
	//some pos type and pos index
	TIVector X, Xdot, Z, Di, Do, U, V, Ej, Fj;
	TIVector JFrow, JEcol, JIrow, JIcol;
	int	Sc,	Rc,	Uc, Jc, Subc, Jc2;

protected:
	void makeStatistics();
	int m_PowerDirectStatus;
	void initialize_Matrix();
	void efSet(char causal, double value, char label1, int rowno, char label2, int colno);
	void effortSet(double value, char label1, int rowno, char label2, int colno);
	void flowSet(double value, char label1, int rowno, char label2, int colno);
	int check_JImatrix();
	void calculate_Jreduced2();
	void calculate_Jreduced1();
	void make_Jmatrix();
	void make_Lmatrix();
	void labelingBond();
	void make_Smatrix();

public:
	virtual void Simplify(int option);
	void PrintGraph( int what, FILE* stream=stdout);
	void printGraphRecursive(CComponent* pComp, int x, int y, CGraphPrint*  g, int what=BONDGRAPH_FRAME);
	int calculateMaxDepth();
	void Save( int What, FILE* fp);
	//System features
	int m_nElements;
	int m_nFlowSources;
	int m_nEffortSources;
	int m_nTransformers;
	int m_nGyrates;
	int m_nResistors;
	int m_nInductors;
	int m_nCapacitors;
	int m_nPorts;
	int m_nBonds;
	int m_nJunctions;
	int m_nJunction0s;
	int m_nJunction1s;

	//Graph features
	int m_MaxDepth;		//Maximum of the node depth(shortest path length to the leaf)
	int m_nLeafs;		//How many leaf nodes, equavelent to m_nElements
	int m_nInternals;	//how many internal nodes, or 0/1/TF/GY
	int m_MaxPathLength;//the furthest path 
	int m_StructureComplexity;	//
	int m_nLoops;				//how many number of loops
	int m_MaxLoopCircumstance;	//Maximum of the loop length(How many nodes(or bonds) in the loop )
	double	m_SymetricIndex;
	int m_MaxDegree;// Max branch no of the node

	//print graph parameter 
	int m_LineSpace; //how many blank lines between two graph line, default 3
};
#endif // !defined(AFX_BONDGRAPHCLASS_H__975DB084_B50B_499B_BAA0_D89F8DA5C99A__INCLUDED_)

