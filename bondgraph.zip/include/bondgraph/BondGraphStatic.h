/*  Bondgraph Modeling System, version 1.0, 11 Jan 2001
 *  Copyright (C) 2001  Michigan State University
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of version 2 of the GNU General Public License as
 *  published by the Free Software Foundation.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *  Jianjun Hu            (hujianju@msu.edu)
 *
 *  Computer Science Department
 *  EB 2340 GARAGe Group
 *  Michigan State University
 *  East Lansing, Michigan  48824
 *  USA
 *
 */


// BondGraphStatic.h: interface for the CBondGraphStatic class.
//
// This class implements static memeory allocation of Bondgraph objects.
// Elements in the bondgraphs are allocated initally by static arrays.

//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BONDGRAPHSTATIC_H__6BD26B21_DAA8_11D4_A1ED_444553540000__INCLUDED_)
#define AFX_BONDGRAPHSTATIC_H__6BD26B21_DAA8_11D4_A1ED_444553540000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Bond.h"

#include "Port.h"

#include "Component.h"

#include "Element1Port.h"

#include "Element2Port.h"

#include "Gyrate.h"

#include "Junction.h"

#include "Junction1.h"

#include "Junction0.h"

#include "Transformer.h"

#include "Capacitor.h"

#include "Resistor.h"

#include "Inductor.h"

#include "Source.h"

#include "BondGraphDynamic.h"


//static array size.
#define MAX_BOND 5000
#define MAX_CAPACITOR 500
#define MAX_INDUCTOR 500
#define MAX_RESISTOR 500
#define MAX_SE 20
#define MAX_SF 20
#define MAX_GY 50
#define MAX_TF 50
#define MAX_J0 1000
#define MAX_J1 1000




//used to label the deleted components' store postion in corresponding array
struct CComponentPos{
	int Type;//Bond, SE,SF,...
	int Pos; //subscript number in the array
};

class CBondGraphStatic : public CBondGraph
{
public:
	CJunction* GetNextUnvisitedJunction();
	virtual void Simplify(int option);
	int DeleteComponent(CComponent* pCom);
	int FindComponentPos(CComponent* pComp);
	void DeleteComponent(int Type, int pos);
	int AvailabeIDInBackList(int Type);
	CComponent* GetNewComponent(int Type);
	CBondGraphStatic();
	virtual ~CBondGraphStatic();
	void Clean();//delete the content of Bondgraph

  virtual void        read(std::istream& ioIS);
  virtual void        write(std::ostream& ioOS);

	//Static Memeory Structure, + parallel dynamic allocation
	CBond			BondBase[MAX_BOND];//5000
	CCapacitor		CapacitorBase[MAX_CAPACITOR];//500
	CInductor		InductorBase[MAX_INDUCTOR];//500
	CResistor		ResistorBase[MAX_RESISTOR];//500
	CSourceEffort	SourceEffortBase[MAX_SE];//20
	CSourceFlow		SourceFlowBase[MAX_SF];//20
	CGyrate			GyrateBase[MAX_GY];//100
	CTransformer	TransformerBase[MAX_TF];//100
	CJunction0		Junction0Base[MAX_J0];//500
	CJunction1		Junction1Base[MAX_J1];//500

	//list of deleted component
	//we keep those unused array element type and subscript for later allocated for new components
	list<CComponentPos*>	DeletedStaticComponentList;

	//dyanmic allocation component list, used to
	//keep all the dynamic component in case out of
	//static array Boundary
	list<CComponent*> DynamicComponentList;

	//index of each component
	int CurrBondID;// current BondID --> current Max Array subscript of Bond array
	int CurrCapacitorID;
	int CurrInductorID;
	int CurrResistorID;
	int CurrSEID;
	int CurrSFID;
	int CurrGYID;
	int CurrTFID;
	int CurrJ0ID;
	int CurrJ1ID;

};

#endif // !defined(AFX_BONDGRAPHSTATIC_H__6BD26B21_DAA8_11D4_A1ED_444553540000__INCLUDED_)


