/*  Bondgraph Modeling System, version 1.0, 11 Jan 2001
 *  Copyright (C) 2001  Michigan State University
 * 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of version 2 of the GNU General Public License as
 *  published by the Free Software Foundation.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *  
 *  Jianjun Hu            (hujianju@msu.edu)
 *  
 *  Computer Science Department
 *  EB 2340 GARAGe Group
 *  Michigan State University
 *  East Lansing, Michigan  48824
 *  USA
 *  
 */

// Component.h: interface for the CComponent class.
////////////////////////////////////////////////////////////////////////



#if !defined(AFX_COMPONENT_H__042E35A1_A770_11D4_BB82_00105A06D5B4__INCLUDED_)
#define AFX_COMPONENT_H__042E35A1_A770_11D4_BB82_00105A06D5B4__INCLUDED_



#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "StdAfx.h"
#include <iostream>
#include <string>
#include "Port.h"
using namespace std ;

class CComponent  
{
public:
	bool m_bVisited;//used in print bondgraph, label if this component is printed or not
	int m_Depth;//the shortest path length of the component from any leaf
	virtual int SetPowerDirect(int direction,  CPort* pPort);
	virtual void Reset();
	virtual int SetCausalMark(int Type, CPort* pPort);
	void SetParamValue(double value);
	void SetNo(int ID);
	void	LinkPortToPort(CPort& FromPort,CBond*pBond, CPort& ToPort);//Link any component to a port, used for initial construction of BondGraph
	
	//data
	int				m_No;// integer used to identify uniquely the component
	string			m_Name;  //Name of this component
	ComponentType	m_Type;  //component type, int type
	double			m_ParamValue;// I, R, C, GY, TF's parameter value
	int				m_WriteNo;//the write site no
	int				m_PortNum;//how many ports it has
	CPort m_Port[MAX_PORT];

	CComponent();
	virtual ~CComponent();
	
	//serialization
	virtual void   read(std::istream& ioIS);
	virtual std::string serialize() const;
	virtual void   write(std::ostream& ioOS) const;
};
// Implemented in the source file.
std::istream& operator>>(std::istream& ioIS, CComponent& outObject);
std::ostream& operator<<(std::ostream& ioOS, const CComponent& inObject);
#endif // !defined(AFX_COMPONENT_H__042E35A1_A770_11D4_BB82_00105A06D5B4__INCLUDED_)

