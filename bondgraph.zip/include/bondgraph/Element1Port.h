/*  Bondgraph Modeling System, version 1.0, 11 Jan 2001
 *  Copyright (C) 2001  Michigan State University
 * 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of version 2 of the GNU General Public License as
 *  published by the Free Software Foundation.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *  
 *  Jianjun Hu            (hujianju@msu.edu)
 *  
 *  Computer Science Department
 *  EB 2340 GARAGe Group
 *  Michigan State University
 *  East Lansing, Michigan  48824
 *  USA
 *  
 */

// Element1Port.h: interface for the CElement1Port class.
////////////////////////////////////////////////////////////////////////



#if !defined(AFX_ELEMENT1PORT_H__FF40F325_A800_11D4_BB82_00105A06D5B4__INCLUDED_)

#define AFX_ELEMENT1PORT_H__FF40F325_A800_11D4_BB82_00105A06D5B4__INCLUDED_



#if _MSC_VER > 1000

#pragma once

#endif // _MSC_VER > 1000



#include "Junction.h"

#include "Component.h"

#include "Port.h"

#include <iostream>


class CElement1Port : public CComponent  

{

public:
	void Reset();
	virtual int SetPowerDirect(int direction, CPort* pPort=NULL);

	virtual int SetCausalMark(int Type, CPort* pPort=NULL);

	virtual int LinkToJunction(CJunction* junction, CBond* bond);
	void operator =(CElement1Port &el);

	//CPort m_Port[1];

	CElement1Port();

	virtual ~CElement1Port();

	virtual void read(std::istream& ioIS);
	virtual void write(std::ostream& ioOS) const;


};



#endif // !defined(AFX_ELEMENT1PORT_H__FF40F325_A800_11D4_BB82_00105A06D5B4__INCLUDED_)

