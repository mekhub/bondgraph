/*  Bondgraph Modeling System, version 1.0, 11 Jan 2001
 *  Copyright (C) 2001  Michigan State University
 * 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of version 2 of the GNU General Public License as
 *  published by the Free Software Foundation.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *  
 *  Jianjun Hu            (hujianju@msu.edu)
 *  
 *  Computer Science Department
 *  EB 2340 GARAGe Group
 *  Michigan State University
 *  East Lansing, Michigan  48824
 *  USA
 *  
 */

// GraphPrint.h: interface for the CGraphPrint class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GRAPHPRINT_H__DA891459_C7E4_49D9_9688_6ADB1D612EAA__INCLUDED_)
#define AFX_GRAPHPRINT_H__DA891459_C7E4_49D9_9688_6ADB1D612EAA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <stdio.h>

//move area types
#define BLOCK_RIGHT_SIDE	0
#define BLOCK_DOWN_SIDE		1
#define BLOCK_RIGHTDOWN_SIDE	2
#define BLOCK_LEFT_SIDE		3
#define BLOCK_UP_SIDE		4
#define BLOCK_UPLEFT_SIDE	5
#define BLOCK_BOX			6

//write direction
#define DIRECT_RIGHT	0
#define DIRECT_LEFT		1
#define DIRECT_UP		2
#define DIRECT_DOWN		3
#define CLOCKWISE			0
#define COUNTER_CLOCKWISE	1


// this class implements flexible graph output in command window.
// it is a good method without resorting to GUI windows interface.
// it uses the character array to hold all the output info, which is 
// written by some line functions, then it output the array to the
// screen at one time!



class CGraphPrint  
{
public:
	void flush();
	void Print();
	void Print(FILE* stream);
	int GetCurrentMaxY();
	int GetCurrentMaxX();
	bool IsLineSymbol(char sym);
	char CurrLineSymbol;
	void SetLineSymbol(int i, char sym);
	char lineSymbol[2];
	bool IsEmpty(int x, int y);
	bool IsPathEmpty(int x, int y, int x1, int y1,int direction);
	void WriteBlock(int x, int y, int x1, int y1, char**pstring);
	void CleanBlock(int x, int y, int x1, int y1);
	bool IsEmpty(int x, int y, int x1, int y1);//check if an area is empty or occupied
	bool IsValid(int x, int y);
	void WriteString(int x, int y, char* pString,int direction = DIRECT_RIGHT);//Default direction, right
	void Write(int x, int y, char sym);
	void MoveBlock(int x, int y, int x1, int y1, int what, int dx, int dy);
	void Line(int x, int y, int x1, int y1, char symbol, int direction);//use char symbol to 
				//draw a orthogonal line 
	CGraphPrint(int row, int col);
	CGraphPrint();
	virtual ~CGraphPrint();
	
	char grid[500][500];
	char copy[500][500];
	int Xmax, Ymax, Xmin, Ymin;
	int currXmax, currYmax, currXmin, currYmin;//define currently occupied rectangle



};

#endif // !defined(AFX_GRAPHPRINT_H__DA891459_C7E4_49D9_9688_6ADB1D612EAA__INCLUDED_)
