/*  Bondgraph Modeling System, version 1.0, 11 Jan 2001
 *  Copyright (C) 2001  Michigan State University
 * 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of version 2 of the GNU General Public License as
 *  published by the Free Software Foundation.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *  
 *  Jianjun Hu            (hujianju@msu.edu)
 *  www.hujianjun.com     www.DarwinInvention.com
 *
 *  Computer Science Department
 *  EB 2340 GARAGe Group
 *  Michigan State University
 *  East Lansing, Michigan  48824
 *  USA
 *  
 */
// Junction.h: interface for the CJunction class.
////////////////////////////////////////////////////////////////////////



#if !defined(AFX_JUNCTION_H__042E35A9_A770_11D4_BB82_00105A06D5B4__INCLUDED_)

#define AFX_JUNCTION_H__042E35A9_A770_11D4_BB82_00105A06D5B4__INCLUDED_



#if _MSC_VER > 1000

#pragma once

#endif // _MSC_VER > 1000



#include "Port.h"	// Added by ClassView

#include "Component.h"

//class CComponent;
//simplification option
#define SIMPLIFY_KEEP_EMBRYO		0
#define SIMPLIFY_ALL				1
#define SIMPLIFY_EXTRA_JUNCTION		2
#include <iostream>



class CJunction : public CComponent  

{

public:
	void Reset();
	int LinkToJunction(CJunction* pJuctionNeighbor, CBond* pBondNew);
	int LinkToSelf(CBond* pBond);
	virtual int SetPowerDirect(int direction, CPort* pPort=NULL);
	void SetPowerDirect(int powerdirection, int portNo);
	int FindNeighborJuctions(int option, int type, list<CJunction*>& AggregateJunctionList);
	int AddPortNum(int no);//return the new portNum

	int SetPortNum(int no);


	void SetPortCausalMark(int PortNo, int flag);
	void operator =(CJunction &junction);

	//CPort m_Port[MAX_PORT];

	CJunction();

	virtual ~CJunction();
	virtual void read(std::istream& ioIS);
	virtual void write(std::ostream& ioOS) const;

};



#endif // !defined(AFX_JUNCTION_H__042E35A9_A770_11D4_BB82_00105A06D5B4__INCLUDED_)

