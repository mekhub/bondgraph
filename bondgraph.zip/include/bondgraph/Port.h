/*  Bondgraph Modeling System, version 1.0, 11 Jan 2001
 *  Copyright (C) 2001  Michigan State University
 * 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of version 2 of the GNU General Public License as
 *  published by the Free Software Foundation.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *  
 *  Jianjun Hu            (hujianju@msu.edu)
 *  www.hujianjun.com     www.DarwinInvention.com
 *
 *  Computer Science Department
 *  EB 2340 GARAGe Group
 *  Michigan State University
 *  East Lansing, Michigan  48824
 *  USA
 *  
 */
// Port.h: interface for the CPort class.
// GARAGE Group, Michigan State University

////////////////////////////////////////////////////////////////////////



#if !defined(AFX_PORT_H__042E35A6_A770_11D4_BB82_00105A06D5B4__INCLUDED_)
#define AFX_PORT_H__042E35A6_A770_11D4_BB82_00105A06D5B4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include <stdlib.h>
#include "StdAfx.h"
class CBond;

//#include "Bond.h"	// Added by ClassView
//#include "Component.h"

class CComponent;
class CPort  
{
public:
	bool IsPowerDirectEqual(int direction);
	int GetPowerDirect();
	bool IsPowerDirectEqual(CPort*);
	int GetCausalityType();
	bool IsCausalityEqual(int Type);
	void ClearPowerDirect(){m_PowerDirect = -1;};// unspecify the power direction
	void SetPowerDirect(int flag){ 
		m_PowerDirect = flag;// OUT or IN
	};
	
	void operator =(CPort &el){ 
		m_CausalMark=el.m_CausalMark; 
		m_PowerDirect = el.m_PowerDirect;
		m_pBond = el.m_pBond;
		m_pComponent=el.m_pComponent;
	}

	void ClearCausalMark(){	m_CausalMark = -1;};

	int SetCausalMark(int Type){ 
		if(m_CausalMark==-1){// not set yet
			if(Type == EFFORT) 
				m_CausalMark = 1;
			else
				m_CausalMark = 0;
			return 0;//OK
		}
		else{
			if(m_CausalMark==Type) return 0;//reach end point
			else return -1; // conflict
		}

	};

	bool HasPowerDirect(){
		if(m_PowerDirect ==1)
			return true;
		else
			return false;
	};


	bool IsEffortCausal(){ 
		if(m_CausalMark == 1)
			return true;
		else
			return false;
	};

	bool IsFlowCausal(){
			if(m_CausalMark == 0)
				return true;
			else
				return false;
	};

	bool IsCausalityDefined(){
		if(m_CausalMark !=-1)
			return true;
		else 
			return false;
	}

	bool IsPowerDirectDefined(){
		if(m_PowerDirect !=-1)
			return true;
		else 
			return false;
	}
	void reset(){
		m_CausalMark=-1;
		m_PowerDirect=-1;
		m_pBond=NULL;
		m_pComponent=NULL;
	}
  
	CPort(){
		m_PowerDirect = -1;
		m_CausalMark = -1;
		m_pBond = NULL; 
		m_pComponent = NULL;
	};
	virtual ~CPort();
public:
	int m_CausalMark;// -1, not set, 0 (Flow causal), 1 with causal mark(Effort Causal)   
	int m_PowerDirect;// -1, net set, From PowerSource  0(OUT) , 1(IN) To PowerDirect mark
	CBond* m_pBond;
	CComponent * m_pComponent;

};



#endif // !defined(AFX_PORT_H__042E35A6_A770_11D4_BB82_00105A06D5B4__INCLUDED_)

