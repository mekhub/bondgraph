/*  Bondgraph Modeling System, version 1.0, 11 Jan 2001
 *  Copyright (C) 2001  Michigan State University
 * 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of version 2 of the GNU General Public License as
 *  published by the Free Software Foundation.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *  
 *  Jianjun Hu            (hujianju@msu.edu)
 *  www.hujianjun.com     www.DarwinInvention.com
 *
 *  Computer Science Department
 *  EB 2340 GARAGe Group
 *  Michigan State University
 *  East Lansing, Michigan  48824
 *  USA
 *  
 */
// Resistor.h: interface for the CResistor class.
////////////////////////////////////////////////////////////////////////



#if !defined(AFX_RESISTOR_H__FF40F326_A800_11D4_BB82_00105A06D5B4__INCLUDED_)

#define AFX_RESISTOR_H__FF40F326_A800_11D4_BB82_00105A06D5B4__INCLUDED_



#if _MSC_VER > 1000

#pragma once

#endif // _MSC_VER > 1000



#include "Element1Port.h"



class CResistor : public CElement1Port  

{

public:
	virtual void Reset();

	CResistor();

	virtual ~CResistor();



};



#endif // !defined(AFX_RESISTOR_H__FF40F326_A800_11D4_BB82_00105A06D5B4__INCLUDED_)

