/*  Bondgraph Modeling System, version 1.0, 11 Jan 2001
 *  Copyright (C) 2001  Michigan State University
 * 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of version 2 of the GNU General Public License as
 *  published by the Free Software Foundation.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *  
 *  Jianjun Hu            (hujianju@msu.edu)
 *  www.hujianjun.com     www.DarwinInvention.com
 *
 *  Computer Science Department
 *  EB 2340 GARAGe Group
 *  Michigan State University
 *  East Lansing, Michigan  48824
 *  USA
 *  
 */

// stdafx.h : include file for standard system include files,

//  or project specific include files that are used frequently, but

//      are changed infrequently

//



#if !defined(AFX_STDAFX_H__C75246A5_A74F_11D4_BB82_00105A06D5B4__INCLUDED_)

#define AFX_STDAFX_H__C75246A5_A74F_11D4_BB82_00105A06D5B4__INCLUDED_



#if _MSC_VER > 1000

#pragma once

#endif // _MSC_VER > 1000



#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers





#include <list>  // linked list of STL library

using namespace std;



//enum ComponentType{

//	SE, SF, CAPACITOR, INDUCTOR, RESISTOR,TF, GY, JUNCTION0, JUNCTION1, BOND};

//definie the constants for node(or return) TYPES  

#define SE			0	//return Type

#define SF			1	

#define CAPACITOR	2	

#define INDUCTOR	3

#define RESISTOR	4	

#define TF			5

#define GY			6

#define JUNCTION0		7

#define JUNCTION1		8	

#define BOND		9

#define INFINITY 999999 //defined in math.h
//causality types
#define EFFORT 1
#define FLOW 0
//Power Direction
#define OUT 1
#define IN 0

#define UNSET -1

typedef int ComponentType; 



#define MAX_PORT  50// Max port number of a Junctionon



#include <stdio.h>


#define CAUSALITY_SUCCESS_LEVEL_1 1//causality set by assign Se, Sf
#define CAUSALITY_SUCCESS_LEVEL_2 2 //causality set by assign I/C
#define CAUSALITY_SUCCESS_LEVEL_3 3 //causality set by assign Resistor
#define CAUSALITY_SUCCESS_LEVEL_4 4 //causality set by assign TF/GY

#define CAUSALITY_CONFLICT		 -1

//define the Bondgraph report content
#define BONDGRAPH_ALL		1	//output all bondgraph info
#define BONDGRAPH_CAUSALITY	2	//output the structure and causality
#define BONDGRAPH_PARAM		3	//output the sttucture and parameter

//print bondgraph structure option
//#define BONDGRAPH_ALL		1	//print all, frame, I R C, and all parameter value
#define BONDGRAPH_FRAME		4	//dont' print I R C
#define BONDGRAPH_NOLABEL	5	//don't print out element no in the graph






// TODO: reference additional headers your program requires here



//{{AFX_INSERT_LOCATION}}

// Microsoft Visual C++ will insert additional declarations immediately before the previous line.



#endif // !defined(AFX_STDAFX_H__C75246A5_A74F_11D4_BB82_00105A06D5B4__INCLUDED_)

