//[][]---------------------------------------------------------[][]

//

//  Dr. Kisung Seo

//		of Case Center		1999. 10

//							2000. 7

//

//	using

//  lil-gp Genetic Programming System, version 1.0, 11 July 1995

//  Copyright (C) 1995  Michigan State University

//

//[][]---------------------------------------------------------[][]




#ifndef _NUMERIC_H
#define _NUMERIC_H


#include <malloc.h>

//#include "state.h"



#define TINY		1.0e-20;





void inverse(double **a, int n, double **y);

void ludcmp(double **a, int n, int *indx, double *d);

void lubksb(double **a,  int n, int *indx, double b[]);

void fmmult( double **a, int a_rows, int a_cols,

             double **b, int b_rows, int b_cols, double **y);

void nrerror(char error_text[]);

//double *vector(int nl, int nh);

double *vector(int nl, int nh);

int *ivector(int nl, int nh);

double *dvector(int nl, int nh);

/*TI *TIvector(int nl, int nh);
*/
//void *free_vector(double *v, int nl, int nh);

void free_vector(double *v, int nl, int nh);

/*void free_TIvector(TI *v, int nl, int nh);
*/


void free_ivector(int *v, int nl, int nh);

void free_dvector(double *v, int nl, int nh);

//double **matrix(int nrl, int nrh, int ncl, int nch);
double **matrix(int nrl, int nrh, int ncl, int nch);

int **imatrix(int nrl, int nrh, int ncl, int nch);

double **dmatrix(int nrl, int nrh, int ncl, int nch);

//double free_matrix(double **m, int nrl, int nrh, int ncl, int nch);

void free_matrix(double **m, int nrl, int nrh, int ncl, int nch);

void free_dmatrix(double **m, int nrl, int nrh, int ncl, int nch);


void eigen_values(double **a, int size) ;



double **convert_matrix(double *a, int nrl, int nrh, int ncl, int nch);

void free_convert_matrix(double **b, int nrl, int nrh, int ncl, int nch);



void balanc(double **a, int n);

void elmhes(double **a, int n);

void hqr(double **a, int n, double wr[], double wi[]);





static double sqrarg;

#define SQR(a) ((sqrarg=(a)) == 0.0 ? 0.0 : sqrarg*sqrarg)



static double dsqrarg;

#define DSQR(a) ((dsqrarg=(a)) == 0.0 ? 0.0 : dsqrarg*dsqrarg)



static double dmaxarg1,dmaxarg2;

#define DMAX(a,b) (dmaxarg1=(a),dmaxarg2=(b),(dmaxarg1) > (dmaxarg2) ? (dmaxarg1) : (dmaxarg2))



static double dminarg1,dminarg2;

#define DMIN(a,b) (dminarg1=(a),dminarg2=(b),(dminarg1) < (dminarg2) ?  (dminarg1) : (dminarg2))



static double maxarg1,maxarg2;

#define FMAX(a,b) (maxarg1=(a),maxarg2=(b),(maxarg1) > (maxarg2) ? (maxarg1) : (maxarg2))



static double minarg1,minarg2;

#define FMIN(a,b) (minarg1=(a),minarg2=(b),(minarg1) < (minarg2) ? (minarg1) : (minarg2))



static int lmaxarg1,lmaxarg2;

#define LMAX(a,b) (lmaxarg1=(a),lmaxarg2=(b),(lmaxarg1) > (lmaxarg2) ?(lmaxarg1) : (lmaxarg2))



static int lminarg1,lminarg2;

#define LMIN(a,b) (lminarg1=(a),lminarg2=(b),(lminarg1) < (lminarg2) ?(lminarg1) : (lminarg2))



static int imaxarg1,imaxarg2;

#define IMAX(a,b) (imaxarg1=(a),imaxarg2=(b),(imaxarg1) > (imaxarg2) ?(imaxarg1) : (imaxarg2))



static int iminarg1,iminarg2;

#define IMIN(a,b) (iminarg1=(a),iminarg2=(b),(iminarg1) < (iminarg2) ?(iminarg1) : (iminarg2))



#define SIGN(a,b) ((b) >= 0.0 ? fabs(a) : -fabs(a))







#endif




