/*  Bondgraph Modeling System, version 1.0, 11 Jan 2001
 *  Copyright (C) 2001  Michigan State University
 * 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of version 2 of the GNU General Public License as
 *  published by the Free Software Foundation.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *  
 *  Jianjun Hu            (hujianju@msu.edu)
 *  Computer Science Department
 *  EB 2340 GARAGe Group
 *  Michigan State University
 *  East Lansing, Michigan  48824
 *  USA
 *  
 */

// Bond.cpp: implementation of the CBond class.
//
//////////////////////////////////////////////////////////////////////



#include "bondgraph/Bond.h"

#include "bondgraph/Element1Port.h"



//////////////////////////////////////////////////////////////////////

// Construction/Destruction

//////////////////////////////////////////////////////////////////////



CBond::CBond()
{
    CComponent::CComponent();
    m_No = 0;

    m_Name = "BOND";

    m_Type = BOND;

    m_PortNum=2;

    m_ParamValue=0;// I, R, C, GY, TF's parameter value

    m_pFromPort = NULL;

    m_pToPort = NULL;



}

CBond::~CBond()
{


}
//  Insert Juntion into the middle of the Bond by creating a new bond(pBond)
void CBond::InsertJunction(CJunction *pJunction, CBond *pBond)
{
    CPort* pToPort;
    if(this->m_pToPort->GetPowerDirect() == OUT) {
        //if power direction is not from FromPort to ToPort,
        //then exchange the fromPort and ToPort
        //printf("CBond:  fromport exchange with Toport\n");
        pToPort  = this->m_pToPort;
        this->m_pToPort = this->m_pFromPort;
        this->m_pFromPort = pToPort;
    }

    //link oldbond, new junction, new bond old component together
    pJunction->m_Port[0].SetPowerDirect(IN);//
    pJunction->m_Port[1].SetPowerDirect(OUT);//

    CPort* pOldPort;
    pOldPort = this->m_pToPort;

    this->m_pToPort = &(pJunction->m_Port[0]);
    pJunction->m_Port[0].m_pBond = this;
    pJunction->m_Port[1].m_pBond = pBond;
    pBond->m_pFromPort = &(pJunction->m_Port[1]);
    pBond->m_pToPort = pOldPort;
    pOldPort->m_pBond = pBond;
}



//  Insert Element into the middle of the Bond by creating a new bond(pBond)

void CBond::InsertElement2Port(CElement2Port *pElement, CBond *pBond)
{
    CPort* pToPort;
    //make sure FromPort is the port from Energy source
    //OUT means energy output!
    if(this->m_pToPort->GetPowerDirect() == OUT) {
        //if power direction is not from FromPort to ToPort,
        //then exchange the fromPort and ToPort
        //printf(" CBond:  fromport exchange with Toport\n");
        pToPort  = this->m_pToPort;
        this->m_pToPort = this->m_pFromPort;
        this->m_pFromPort = pToPort;
    }

    pElement->m_Port[0].SetPowerDirect(IN);//
    pElement->m_Port[1].SetPowerDirect(OUT);//

    //link oldbond, new junction, new bond old component together
    CPort* pOldPort;
    pOldPort = this->m_pToPort;


    this->m_pToPort = &(pElement->m_Port[0]);

    pElement->m_Port[0].m_pBond = this;
    pElement->m_Port[1].m_pBond = pBond;
    pBond->m_pFromPort = &(pElement->m_Port[1]);
    pBond->m_pToPort = pOldPort;
    pOldPort->m_pBond = pBond;	//link oldbond, new junction, new bond old component together
}


void CBond::Reset() {

    CBond();
    CComponent::Reset();
}

CBond& CBond::operator =(CBond &bond) {
    if(&bond==this)
        return *this;
    m_pFromPort = bond.m_pFromPort;
    m_pToPort = bond.m_pToPort;

    m_No=bond.m_No;// int
    m_Name=bond.m_Name;  //
    m_Type=bond.m_Type;  //
    m_ParamValue=bond.m_ParamValue;
    m_PortNum=bond.m_PortNum;//
    return *this;
}



/*!
 *  \brief Extract Object from a  input stream.
 *  \param ioIS Input stream to read the object from.
 */
void CBond::read(std::istream& ioIS) {
    //Type  Name  ID writeHead portNo  PortList paramNo paramList
    //int paramNum;
    //ioIS>>m_Type;
    ioIS>>m_Name;
    ioIS>>m_No;
    ioIS>>m_WriteNo;

    ioIS>>m_PortNum;
    //ioIS>>paramNum;
    //ioIS>>m_ParamValue;

    //the connection information need to be read by Bondgraph object
}


/*!
 *  \brief Insert an CComponent into a Beagle output stream.
 *  \param ioOS Output stream to write the object into.
 *  \throw  Beagle::CComponentException If the method is not overdefined in a subclass.
 */
void CBond::write(ostream& ioOS) const {
    ioOS<<m_Type<<"\t";
    ioOS<<m_Name<<"\t";
    ioOS<<m_No<<"\t";
    ioOS<<m_WriteNo<<"\t";

    ioOS<<2<<"\t";

    //record the connection information
    if(m_pFromPort!=NULL) {
        ioOS<<m_pFromPort->m_pComponent->m_Type<<"\t";
        ioOS<<m_pFromPort->m_pComponent->m_No<<"\t";
        //port number!
        int i;
        for(i=0;i<m_pFromPort->m_pComponent->m_PortNum;i++) {
            if(m_pFromPort==& m_pFromPort->m_pComponent->m_Port[i])
                break;
        }
        ioOS<<i<<"\t";
    }
    if(m_pToPort!=NULL) {
        ioOS<<m_pToPort->m_pComponent->m_Type<<"\t";
        ioOS<<m_pToPort->m_pComponent->m_No<<"\t";
        //port number!
        int i;
        for(i=0;i<m_pToPort->m_pComponent->m_PortNum;i++) {
            if(m_pToPort==& m_pToPort->m_pComponent->m_Port[i])
                break;
        }
        ioOS<<i<<"\t";
    }
    ioOS<<"\n";

    //ioOS<<1<<"\t";
    //ioOS<<m_ParamValue<<"\t";
}

