/*  Bondgraph Modeling System, version 1.0, 11 Jan 2001
 *  Copyright (C) 2001  Michigan State University
 * 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of version 2 of the GNU General Public License as
 *  published by the Free Software Foundation.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *  
 *  Jianjun Hu            (hujianju@msu.edu)
 *  
 *  Computer Science Department
 *  EB 2340 GARAGe Group
 *  Michigan State University
 *  East Lansing, Michigan  48824
 *  USA
 *  
 */

// BondGraphClass.cpp: implementation of the CBondGraph class.
// Modification history by Jianjun Hu
//
//4-1-01   Solve the print_graph problem, now we don't have overlapped branches.
//			But we still can't represent loops.

//////////////////////////////////////////////////////////////////////




#include <iostream> //for cout, cin output
#include "bondgraph/BondGraph.h"
#include "bondgraph/BondGraphDynamic.h"
#include "bondgraph/GraphPrint.h"
#include <math.h>
//matrix operations for eigen-value calculation
void free_matrix(double **m, int nrl, int nrh, int ncl, int nch);
void eigen_values(double **a, int size) ;
double **matrix(int nrl, int nrh, int ncl, int nch);

#include <vector>
using namespace std;




//#define JDDuse;
//#define _DEBUG_EQU

//////////////////////////////////////////////////////////////////////
// This class implements dynamic memeory allocation of Bondgraph objects.
// Elements in the bondgraphs are allocated dynamically.
//
// Construction/Destruction

//////////////////////////////////////////////////////////////////////



CBondGraph::CBondGraph()

{

    graph=new CGraphPrint(500,500);//dos command window, print graph toolbox

    MaxID=-1;// The max component ID of all the bondgraph, used to denote the identity of component

    MaxBondID=-1;

    MaxComponentID=-1;

    m_CausalityStatus = 1; // Causality not set!

    m_bRefreshed = false;
    m_nElements = 0;
    m_nFlowSources = 0;
    m_nEffortSources = 0;
    m_nTransformers = 0;
    m_nGyrates = 0;
    m_nResistors = 0;
    m_nInductors = 0;
    m_nCapacitors = 0;
    m_nPorts = 0;
    m_nBonds = 0;
    m_nJunctions = 0;
    m_nJunction0s = 0;
    m_nJunction1s = 0;
    m_MaxDepth = 0;

    m_LineSpace = 5;//when w

    Sc=Rc=Uc=Jc=Subc=Jc2=0;
    X.reserve(500);//HJJE
    Xdot.reserve(500);
    Z.reserve(500);
    Di.reserve(500);
    Do.reserve(500);
    U.reserve(500);
    V.reserve(500);
    Ej.reserve(500);
    Fj.reserve(500);
    JFrow.reserve(500);
    JEcol.reserve(500);
    JIrow.reserve(500);
    JIcol.reserve(500);
}



CBondGraph::~CBondGraph()
{
    delete graph;

    X.clear();
    Xdot.clear();
    Z.clear();
    Di.clear();
    Do.clear();
    U.clear();
    V.clear();
    Ej.clear();
    Fj.clear();
    JFrow.clear();
    JEcol.clear();
    JIrow.clear();
    JIcol.clear();

    Smat.CleanUp();
    Lmat.CleanUp();
    JFE.CleanUp();
    JF.CleanUp();
    JE.CleanUp();
    JI.CleanUp();
    Jreduced.CleanUp();
    A.CleanUp();
    B.CleanUp();
    C.CleanUp();
    D.CleanUp();
    if(A_!=NULL)
        free_matrix(A_,1,Sc,1,Sc);
    if(B_!=NULL)
        free_matrix(B_,1,Sc,1,Sc);
    if(C_!=NULL)
        free_matrix(C_,1,Sc,1,Sc);
    if(D_!=NULL)
        free_matrix(D_,1,Sc,1,Sc);
}

void CBondGraph:: Report(int What) {
    list<CJunction*>::iterator jk;//define the iterator of list
    list<CBond*>::iterator bk;
    list<CComponent*>::iterator ek;//element list

    //	printf("__________________________________________________________________________\n");
    printf("                        Bondgraph Information  \n");
    printf("__________________________________________________________________________\n");
    printf("Bonds: %d     Junctions: %d     Elements: %d \n", BondList.size(),JunctionList.size(),
           ElementList.size());
    printf("SE: %d   SF: %d    C: %d     I: %d    R: %d    GY: %d   TF: %d\n\n",nEffortSources(),nFlowSources(), nCapacitors(),nInductors(),nResistors(), nGyrates(),nTransformers());

    //Output the Structure of Bondgraph
    PrintGraph(BONDGRAPH_ALL, stdout);

    //Output the parameters of Bondgraph
    if(What==BONDGRAPH_ALL||What==BONDGRAPH_PARAM) {
        printf(".....................................................Bondgraph Parameters\n");
        printf("Type...ElementNo..........ParamValue...PortNum...WriteHead\n");
        for(ek = ElementList.begin(); ek!= ElementList.end();ek++) {
            printf("%3s  %6d         %15.4f      %4d      %3d\n",
                   (*ek)->m_Name.data(),(*ek)->m_No,(*ek)->m_ParamValue,(*ek)->m_PortNum,(*ek)->m_WriteNo);
        }
    }

    //Output the causality of bondgraph
    if(What==BONDGRAPH_ALL||What==BONDGRAPH_CAUSALITY) {
        printf("Bond No.......Elno:typ|CA|PW ........  Elno:typ|CA|PW  WriteHead\n");
        //		printf("__________________________________________________________________\n");
        for(bk = BondList.begin();bk!=BondList.end();bk++) {
            printf("%4d     ==  %4d:%3s|%2d|%2d <------>  %4d:%3s|%2d|%2d....%3d\n",
                   (*bk)->m_No,(*bk)->m_pFromPort->m_pComponent->m_No, (*bk)->m_pFromPort->m_pComponent->m_Name.data(),
                   (*bk)->m_pFromPort->GetCausalityType(),(*bk)->m_pFromPort->GetPowerDirect(),
                   (*bk)->m_pToPort->m_pComponent->m_No,(*bk)->m_pToPort->m_pComponent->m_Name.data(),
                   (*bk)->m_pToPort->GetCausalityType(),(*bk)->m_pToPort->GetPowerDirect(), (*bk)->m_WriteNo);
        }
    }

    if(What==BONDGRAPH_ALL) {
        printf("..................................\n");
        printf("Bondgraph Junctions\n\n");
        printf("Type...ElementNo..........ParamValue...PortNum....WriteHead\n");
        for(jk = JunctionList.begin(); jk!= JunctionList.end();jk++) {
            printf("%3s  %6d         %15.4f      %4d    %3d\n",
                   (*jk)->m_Name.data(),(*jk)->m_No,(*jk)->m_ParamValue,(*jk)->m_PortNum,(*jk)->m_WriteNo);
        }
    }
    printf("__________________________________________________________________________\n\n");
}

// Function name	: CBondGraph::CheckCausality
// Description	    : check the causality status,  -2 conflict, -1 insufficiency, 0 success,
// Return type		: int
int CBondGraph::CheckCausality() {
    //because the causality set routine of all the component make sure the
    //relation of the causality already set is legal, so we only check if all
    //the port has a causality set

    //conflict flag is already set by exit with conflict in setcausality
    //m_CausalityStatus = -1

    //We only need to check all the bond's port, since they connect all the ports
    list<CBond*>::iterator bk;
    if(m_CausalityStatus==-1)
        return -1;

    for(bk = BondList.begin();bk!=BondList.end();bk++) {
        if(!(*bk)->m_pFromPort->IsCausalityDefined() ||
                !(*bk)->m_pToPort->IsCausalityDefined())
            return (m_CausalityStatus=-2);// insufficiency
    }

    return (m_CausalityStatus=0);//success

}

int CBondGraph::SetCausality() {
    list<CJunction*>::iterator jk;	//define the iterator of list
    list<CBond*>::iterator bk;		//define bond list
    list<CComponent*>::iterator ek;	//define element list

    ClearCausality();

    int status;
    //set SE, SF who has no causality yet, with required causality
    for(ek = ElementList.begin(); ek!= ElementList.end();ek++) {
        if((*ek)->m_Type == SE) {  //HJJ pay attention to the {} of if statement!!!!
            if(!((CSourceEffort*)(*ek))->m_Port[0].IsCausalityDefined()) { //SE not specified
                status = (*ek)->SetCausalMark(FLOW, NULL);
                if(status==-1)
                    return (m_CausalityStatus=-1);
            }
        } else if((*ek)->m_Type == SF) {
            if(!((CSourceFlow*)(*ek))->m_Port[0].IsCausalityDefined()) { //SF not specified
                status = (*ek)->SetCausalMark(EFFORT, NULL);
                if(status==-1)
                    return (m_CausalityStatus=-1);
            }
        }
    }


    status = CheckCausality();
    if(status == 0)
        return CAUSALITY_SUCCESS_LEVEL_1; // causality success


    //in principle we should check if the causality is all satisfactorily set
    //then we decide if we go on the next steps, but because this check needs much
    //computation, for efficiency, we just go on to the next step

    //set I, C with preference causality
    for(ek = ElementList.begin(); ek!= ElementList.end();ek++) {
        if((*ek)->m_Type == INDUCTOR) {
            if(!((CInductor*)(*ek))->m_Port[0].IsCausalityDefined()) { //SE not specified
                status = (*ek)->SetCausalMark(EFFORT, NULL);
                if(status==-1)
                    return (m_CausalityStatus=CAUSALITY_CONFLICT);
            }
        } else if((*ek)->m_Type == CAPACITOR) {
            if(!((CCapacitor*)(*ek))->m_Port[0].IsCausalityDefined()) { //SF not specified
                status = (*ek)->SetCausalMark(FLOW, NULL);
                if(status==-1)
                    return (m_CausalityStatus=CAUSALITY_CONFLICT);
            }
        }
    }

    status = CheckCausality();
    if(status == 0)
        return CAUSALITY_SUCCESS_LEVEL_2; // causality success


    //*****************************
    //HJJ attention: in GPBG if allow level 3, then there are some problem!
    //So here if after 2 level, there is still insufficiency, we just return conflict!
    //return CAUSALITY_CONFLICT;


    //Third level causality assignment
    for(ek = ElementList.begin(); ek!= ElementList.end();ek++) {
        if((*ek)->m_Type ==	RESISTOR) {
            if(!((CResistor*)(*ek))->m_Port[0].IsCausalityDefined()) { //R not specified
                (*ek)->SetCausalMark(FLOW, NULL); //HJJ in fact, here can be random
            }
        }
    }
    status = CheckCausality();
    if(status ==0)
        return CAUSALITY_SUCCESS_LEVEL_3;


    return CAUSALITY_CONFLICT;//we only allow level 3 testing

    //4th level causality assignment
    for(ek = ElementList.begin(); ek!= ElementList.end();ek++) {
        if((*ek)->m_Type ==	TF) {
            if(!((CTransformer*)(*ek))->m_Port[0].IsCausalityDefined()) { //R not specified
                (*ek)->SetCausalMark(EFFORT, NULL); //HJJ in fact, here can be random
            }
        } else if((*ek)->m_Type ==GY) {
            if(!((CGyrate*)(*ek))->m_Port[0].IsCausalityDefined()) { //R not specified
                (*ek)->SetCausalMark(FLOW, NULL); //HJJ in fact, here can be random
            }
        }
    }
    status = CheckCausality();
    if(status ==0)
        return CAUSALITY_SUCCESS_LEVEL_4;


    return CAUSALITY_CONFLICT;

    //m_CausalityStatus=-2);// causality insufficiency
    //causality insufficiency process


}


void CBondGraph::Clean() {
    //*********************************************************
    //Clear the content of list evolved by the last individual program of GP

    list<CJunction*>::iterator jk;//define the iterator of list
    list<CBond*>::iterator bk;
    list<CComponent*>::iterator ek;//element list

    for(jk = JunctionList.begin();jk!=JunctionList.end();jk++)
        delete (*jk);
    JunctionList.clear();
    for(bk = BondList.begin();bk!=BondList.end();bk++)
        delete (*bk);
    BondList.clear();
    for(ek = ElementList.begin();ek!=ElementList.end();ek++)
        delete (*ek);

    ElementList.clear();
    MaxID = -1;// add one, and increase 1, so begin with 0.....n-1
    MaxBondID=-1;
    MaxComponentID=-1;

    m_CausalityStatus = 1;
    m_PowerDirectStatus = 1;


}




void CBondGraph::ReportCausality() {
    list<CBond*>::iterator bk;

    printf("Causality structure_________________________________\n");

    switch( m_CausalityStatus) {
    case 0:
        printf("Causality status:  %s\n", "Success");
        break;
    case -1:
        printf("Causality status:  %s\n", "Conflict!!!");
        break;
    case -2:
        printf("Causality status:  %s\n", "Insufficient!");
        break;
    case 1:
        printf("Causality status:  %s\n", "Causality not set yet!");
        break;

    }


    for(bk = BondList.begin();bk!=BondList.end();bk++) {
        printf("Bond[%4d] ==  %4d:%3s|%2d <------>  %4d:%3s|%2d\n",
               (*bk)->m_No,(*bk)->m_pFromPort->m_pComponent->m_No, (*bk)->m_pFromPort->m_pComponent->m_Name.data(),
               (*bk)->m_pFromPort->GetCausalityType(),
               (*bk)->m_pToPort->m_pComponent->m_No,(*bk)->m_pToPort->m_pComponent->m_Name.data(),
               (*bk)->m_pToPort->GetCausalityType());
    }


}

void CBondGraph::ClearCausality() {
    list<CBond*>::iterator bk;

    for(bk = BondList.begin();bk!=BondList.end();bk++) {
        (*bk)->m_pFromPort->ClearCausalMark();
        (*bk)->m_pToPort->ClearCausalMark();
    }
    m_CausalityStatus=1;// reset


}


int CBondGraph::FormulateStateEquation() {
    int status;

    if(m_CausalityStatus == CAUSALITY_CONFLICT) {
        printf("Causality conlict!.... no state equation formulated!\n");
        //		getch();
        return -1;
    }


    labelingBond();
    //	Report();
    //	getch();

    initialize_Matrix();
    //	getchar();
    make_Smatrix();
    //	printf("-----  before make_Rmatrix()\n");
    make_Lmatrix();
    //	printf("-----  before make_Jmatrix()\n");
    make_Jmatrix();
    status = check_JImatrix();
    //	printf("status =%d\n", status);
    if(status == 0)
        calculate_Jreduced1();
    else
        calculate_Jreduced2();

    //	getch();
#ifndef JDDuse

    Calculate_A();
#else

    Calculate_A1();
#endif

    Calculate_B();
    Calculate_C();
    Calculate_D();

    return 1;
}



void CBondGraph::make_Smatrix() {

    // make S matrix for Storage component
    //	for each C, I component
    //		S[i][i] = 1/I or 1/C;

    list<CComponent*>::iterator ei;//element list
    int in=0 ;

    for(ei = ElementList.begin(); ei!= ElementList.end();ei++) {
        if((*ei)->m_Type==INDUCTOR||(*ei)->m_Type==CAPACITOR) {
            if((*ei)->m_ParamValue == 0)
                Smat[in][in] = INFINITY;
            else
                Smat[in][in]=1/(*ei)->m_ParamValue;
            in++;
        }
    }


#ifdef _DEBUG_EQU
    printf("Smat.................\n");
    Smat.output();
    printf("\n");
    getchar();
#endif //_DEBUG

}


void CBondGraph::labelingBond() {
    list<CBond*>::iterator bk;

    for(bk = BondList.begin();bk!=BondList.end();bk++) {//HJJE
        if((*bk)->m_pFromPort->m_pComponent->m_Type==SE||(*bk)->m_pToPort->m_pComponent->m_Type==SE||
                (*bk)->m_pFromPort->m_pComponent->m_Type==SF||(*bk)->m_pToPort->m_pComponent->m_Type==SF)
            (*bk)->m_Label = 'U';
        else if((*bk)->m_pFromPort->m_pComponent->m_Type==INDUCTOR||(*bk)->m_pToPort->m_pComponent->m_Type==INDUCTOR||
                (*bk)->m_pFromPort->m_pComponent->m_Type==CAPACITOR||(*bk)->m_pToPort->m_pComponent->m_Type==CAPACITOR)
            (*bk)->m_Label = 'S';
        else if((*bk)->m_pFromPort->m_pComponent->m_Type==RESISTOR||(*bk)->m_pToPort->m_pComponent->m_Type==RESISTOR)
            (*bk)->m_Label = 'R';
        else if((*bk)->m_pFromPort->m_pComponent->m_Type==JUNCTION0||(*bk)->m_pToPort->m_pComponent->m_Type==JUNCTION0||
                (*bk)->m_pFromPort->m_pComponent->m_Type==JUNCTION1||(*bk)->m_pToPort->m_pComponent->m_Type==JUNCTION1)
            (*bk)->m_Label = 'J';
        else if((*bk)->m_pFromPort->m_pComponent->m_Type==GY||(*bk)->m_pToPort->m_pComponent->m_Type==GY||
                (*bk)->m_pFromPort->m_pComponent->m_Type==TF||(*bk)->m_pToPort->m_pComponent->m_Type==TF)
            (*bk)->m_Label = 'J';
    }




#ifdef _DEBUG_EQU
    for(bk = BondList.begin();bk!=BondList.end();bk++) {
        printf("Bond[%4d] ==  %4d:%3s|%2d <---%s--->  %4d:%3s|%2d\n",
               (*bk)->m_No,(*bk)->m_pFromPort->m_pComponent->m_No, (*bk)->m_pFromPort->m_pComponent->m_Name.data(),
               (*bk)->m_pFromPort->GetCausalityType(),&(*bk)->m_Label,
               (*bk)->m_pToPort->m_pComponent->m_No,(*bk)->m_pToPort->m_pComponent->m_Name.data(),
               (*bk)->m_pToPort->GetCausalityType());
    }
    getchar();
#endif //_DEBUG


}



void CBondGraph::make_Lmatrix() {
    // make L matrix for Dissipate component
    //	for each R component
    //		L[i][i] = R or 1/R;

    list<CComponent*>::iterator ei;//element list
    int in=0;

    for(ei = ElementList.begin(); ei!= ElementList.end();ei++) {
        if((*ei)->m_Type==RESISTOR) {
            if(((CResistor*)(*ei))->m_Port[0].IsEffortCausal()) {
                double value=(*ei)->m_ParamValue;
                if(value==0)
                    Lmat[in][in] = INFINITY;
                else
                    Lmat[in][in] = 1.0/value;
            } else
                Lmat[in][in] = (*ei)->m_ParamValue;
            in++;
        }
    }


#ifdef _DEBUG_EQU
    printf("Lmat...........\n");
    Lmat.output();
    getchar();
#endif //_DEBUG
}


//        -- make Jmatrix for Junction node
void CBondGraph::make_Jmatrix() {
    list<CComponent*>::iterator ei;//element list
    list<CJunction*>::iterator ej;//element list


    int j;
    float val;
    //	void flowSet(), effortSet(), efset();   // when using float -> differnet parameter passing problem!!
    //	void flowSet(float val, char label1, int rowno, char label2, int colno);
    //	void effortSet(float val, char label1, int rowno, char label2, int colno);
    //	void efset(char causal, float val, char label1, int rowno, char label2, int colno);

    char tmpcausal;


    for(ej = JunctionList.begin(); ej!= JunctionList.end();ej++) {
        switch ((*ej)->m_Type) {
        case JUNCTION0 :		//  junction 0
            {
                // e1 = e3, e2 = e3  : e3 is base
                // left side is row index, righrt side is column index
                CJunction0* pE = (CJunction0*)(*ej);
                for (j=0; j<pE->m_PortNum ; j++) {
                    if(pE->m_Port[j].IsEffortCausal()) {		//  set base i of 'e'
                        base.no = pE->m_Port[j].m_pBond->m_No;
                        base.label = pE->m_Port[j].m_pBond->m_Label;
                        base.porti = j;
                    }
                }

                for (j=0; j<pE->m_PortNum ; j++) {
                    if(!pE->m_Port[j].IsEffortCausal()) {		//  set base i of 'e'
                        val = 1.0;
                        effortSet(val, pE->m_Port[j].m_pBond->m_Label, pE->m_Port[j].m_pBond->m_No,
                                  base.label, base.no);
                    }
                }

                // determined by direction of flow
                // f3 = f1 - f2  : f3 is base
                // left side is row index, righrt side is column index
                for (j=0; j<pE->m_PortNum ; j++) {
                    if(j != base.porti) {
                        if(pE->m_Port[base.porti].IsPowerDirectEqual(&pE->m_Port[j])) //HJJ Powerdirection?
                            val = -1.0;
                        else
                            val = 1.0;
                        flowSet(val, base.label, base.no,
                                pE->m_Port[j].m_pBond->m_Label, pE->m_Port[j].m_pBond->m_No);
                    }
                }
                break;
            }
        case JUNCTION1 :		//  junction 1
            {
                //printf("(case 8 -> juncton 1 -----  compoindex i = %d\n", i);
                // f1 = f3, f2 = f3  : f3 is base
                // left side is row index, righrt side is column index
                CJunction1 *pE = (CJunction1*)(*ej);
                for (j=0; j<pE->m_PortNum ; j++) {
                    if(pE->m_Port[j].IsFlowCausal()) {		//  set base i of 'f'
                        base.no = pE->m_Port[j].m_pBond->m_No;
                        base.label = pE->m_Port[j].m_pBond->m_Label;
                        base.porti = j;
                    }
                }

                for (j=0; j<pE->m_PortNum ; j++) {
                    if(!pE->m_Port[j].IsFlowCausal()) {		//  set base i of 'e'
                        val = 1.0;
                        flowSet(val, pE->m_Port[j].m_pBond->m_Label, pE->m_Port[j].m_pBond->m_No,
                                base.label, base.no);
                    }
                }

                // determined by direction of flow
                // e3 = e1 - e2  : e3 is base
                // left side is row index, righrt side is column index
                for (j=0; j<pE->m_PortNum ; j++) {
                    if(j != base.porti) {
                        if(pE->m_Port[base.porti].IsPowerDirectEqual(&pE->m_Port[j]))
                            val = -1.0;
                        else
                            val = 1.0;
                        effortSet(val, base.label, base.no,
                                  pE->m_Port[j].m_pBond->m_Label, pE->m_Port[j].m_pBond->m_No);
                    }
                }
            }
            break;
        }//switch

    }//for

    for(ei = ElementList.begin(); ei!= ElementList.end();ei++) {
        if((*ei)->m_Type == TF) {
            //printf("(case 5 -> TF -----  compoindex i = %d\n", i);
            //e1 = m*e2, f1 = m*f2 :		|->TF|->  (standard)
            //e1 = 1/m*e2, f1 = 1/m*f2 :	->|TF->|
            //left side is row index, righrt side is column index
            val = (*ei)->m_ParamValue; 		// == m
            CTransformer * pE = (CTransformer*)(*ei);// Temp element pointer, for convenience
            if(pE->m_Port[0].IsFlowCausal()) {		//  standard
                effortSet(val, pE->m_Port[0].m_pBond->m_Label,pE->m_Port[0].m_pBond->m_No,
                          pE->m_Port[1].m_pBond->m_Label,pE->m_Port[1].m_pBond->m_No);

                flowSet(val, pE->m_Port[1].m_pBond->m_Label,pE->m_Port[1].m_pBond->m_No,
                        pE->m_Port[0].m_pBond->m_Label,pE->m_Port[0].m_pBond->m_No);
            } else { //  if(compo[i].port[0].causalmark == 'e') 		//  non-standard
                // val = 1/compo[i].LTIvalue; 		// == 1/m
                effortSet(val, pE->m_Port[1].m_pBond->m_Label,pE->m_Port[1].m_pBond->m_No,
                          pE->m_Port[0].m_pBond->m_Label,pE->m_Port[0].m_pBond->m_No);

                flowSet(val, pE->m_Port[0].m_pBond->m_Label,pE->m_Port[0].m_pBond->m_No,
                        pE->m_Port[1].m_pBond->m_Label,pE->m_Port[1].m_pBond->m_No);
            }
        } else if((*ei)->m_Type == GY) {

            //			printf("(case 5 -> TF -----  compoindex i = %d\n", i);
            // e1 = m*e2, f1 = m*f2 :		|->TF|->  (standard)
            // e1 = 1/m*e2, f1 = 1/m*f2 :	->|TF->|
            // left side is row index, righrt side is column index
            CGyrate * pE = (CGyrate*)(*ei);
            if(pE->m_Port[0].IsFlowCausal()) {		//  standard
                tmpcausal = 'e';
                val = pE->m_ParamValue; 		// == m
                efSet(tmpcausal,val, pE->m_Port[0].m_pBond->m_Label,pE->m_Port[0].m_pBond->m_No,
                      pE->m_Port[1].m_pBond->m_Label,pE->m_Port[1].m_pBond->m_No);

                efSet(tmpcausal,val, pE->m_Port[1].m_pBond->m_Label,pE->m_Port[1].m_pBond->m_No,
                      pE->m_Port[0].m_pBond->m_Label,pE->m_Port[0].m_pBond->m_No);
            } else { //  if(compo[i].port[0].causalmark == 'e') 		//  non-standard
                tmpcausal = 'e'; //HJJ ?
                if(pE->m_ParamValue==0)
                    val = INFINITY;
                else
                    val = 1/pE->m_ParamValue; 		// == m

                efSet(tmpcausal,val, pE->m_Port[1].m_pBond->m_Label,pE->m_Port[1].m_pBond->m_No,
                      pE->m_Port[0].m_pBond->m_Label,pE->m_Port[0].m_pBond->m_No);

                efSet(tmpcausal,val, pE->m_Port[0].m_pBond->m_Label,pE->m_Port[0].m_pBond->m_No,
                      pE->m_Port[1].m_pBond->m_Label,pE->m_Port[1].m_pBond->m_No);
            }
        }
    }//for

    //#define _DEBUG_EQU //HJJ1

#ifdef _DEBUG_EQU
    JI.output();
    printf("JI after make J................\n");
    getch();
#endif //_DEBUG


}

void CBondGraph::calculate_Jreduced1() {
    //called when JI =0 matrix
    //        -- calculate Jreduced matrix with  JFE+JF*JE
    //--------------------------------------------------------
    Matrix JF_JE(Subc, Subc);

#ifdef _DEBUG_EQU

    printf("JReducted1  (JI = 0\n");
    printf("Matrix JF...........\n");
    JF.output();
    printf("Matrix JE...........\n");
    JE.output();
    getch();
#endif //_DEBUG


    JF_JE = JF*JE;
    Jreduced = JFE+JF_JE;

#ifdef _DEBUG_EQU

    printf("JReducted1  (JI = 0\n");
    printf("Matrix JReducted1 (JI = 0)...........\n");
    Jreduced.output();
    getch();
#endif //_DEBUG

    JFE.CleanUp();
    JF.CleanUp();
    JE.CleanUp();
    JI.CleanUp();
    JF_JE.CleanUp();

}

void CBondGraph::calculate_Jreduced2() {
    //called when JI != 0 matrix
    //        -- calculate Jreduced matrix with  JFE+JF*JE'
    //--------------------------------------------------------
#ifdef _DEBUG_EQU
    printf("JReducted2  (JI != 0\n");
    printf("Matrix JF...........\n");
    JF.output();
    printf("Matrix JE...........\n");
    JE.output();
    getch();
#endif //_DEBUG

    Matrix I(Jc2,Jc2);
    Matrix I_JI(Jc2,Jc2);
    Matrix INV_I_JI(Jc2, Jc2);
    Matrix INV_I_JI_JE(Jc2,Subc);
    Matrix JF_INV_I_JI_JE(Subc,Subc);

    // the row and column size of JI -> Jc2
    // set up I matrix
    I.Unit();
    // calculate [I-JI]
    I_JI = I-JI;

#ifdef _DEBUG_EQU

    printf("I_JI\n");
    I_JI.output();
#endif //_DEBUG

    INV_I_JI = I_JI.i();

    INV_I_JI_JE = INV_I_JI*JE;
    JF_INV_I_JI_JE = JF*INV_I_JI_JE;

    Jreduced = JFE+JF_INV_I_JI_JE;

#ifdef _DEBUG_EQU

    printf("JReducted2  \n");
    printf("Matrix JReducted2 ...........\n");
    Jreduced.output();
    getch();
#endif //_DEBUG

    /*	I.CleanUp();
    	I_JI.CleanUp();
    	INV_I_JI.CleanUp();
    	INV_I_JI_JE.CleanUp();
    	JF_INV_I_JI_JE.CleanUp();
    */
    JFE.CleanUp();
    JF.CleanUp();
    JE.CleanUp();
    JI.CleanUp();
}

//        -- check JImatrix is zero or not
//--------------------------------------------------------
int CBondGraph::check_JImatrix() {
    int i,j;
    int nonzero=0;


#ifdef _DEBUG_EQU

    printf("JF..............\n");
    JF.output();
    getch();
    printf("JE..............\n");
    JE.output();
    printf("JFE..............\n");
    JFE.output();
    getch();
    printf("JI..............\n");
    JI.output();
    getch();
#endif //_DEBUG



    for(i=0;i<Jc2;i++) {
        for(j=0;j<Jc2;j++)
            if(JI[i][j] != 0) {
                nonzero = 1;
                break;
            }
        if(nonzero == 1)
            break;
    }
    return nonzero;
}

void CBondGraph::Calculate_A() {
    //        - calculate A matrix from Jreduced matrix
    //        - JDD = 0
    //        - A = (JXZ+JXD*L*JDZ)*S
    //
    //--------------------------------------------------------
    int i,j;

    Matrix JXZ(Sc,Sc), JXD(Sc,Rc),JDZ(Rc,Sc);
    Matrix JXD_L(Sc,Rc), JXD_L_JDZ(Sc,Sc), JXZ_JXD_L_JDZ(Sc,Sc);
    Matrix JXZ_JXD_L_JDZ_S(Sc,Sc);

    A.ReSize(Sc,Sc);
    A.Zero();

    // extract JXZ from Jreduced
    for(i=0;i<Sc;i++)
        for(j=0;j<Sc;j++)
            JXZ[i][j] = Jreduced[i][j];


    // extract JXD from Jreduced
    for(i=0;i<Sc;i++)
        for(j=0;j<Rc;j++)
            JXD[i][j] = Jreduced[i][j+Sc];


    // extract JDZ from Jreduced
    for(i=0;i<Rc;i++)
        for(j=0;j<Sc;j++)
            JDZ[i][j] = Jreduced[i+Sc][j];


    // calculate JXD*L*JDZ
    JXD_L = JXD*Lmat;
    JXD_L_JDZ = JXD_L*JDZ;

    JXZ_JXD_L_JDZ = JXZ + JXD_L_JDZ;

    // calculate JXZ+JXD*L*JDZ
    JXZ_JXD_L_JDZ_S = JXZ_JXD_L_JDZ*Smat;


    A = JXZ_JXD_L_JDZ_S;

#ifdef _DEBUG_EQU

    printf("Matrix JXZ..........\n");
    JXZ.output();
    printf("Matrix JXD..........\n");
    JXD.output();
    printf("Matrix JDZ..........\n");
    JDZ.output();
    printf("Matrix A..........\n");
    A.output();
    getch();
    printf("----------------------------------\n");
    printf("Matrix A..........\n");
    A.output();
#endif

    A_ = matrix(1,Sc,1,Sc); //HJJ  ?  only because the eignvalue function require subscrip begin from 1!!!
    //if use other eigenvalue routine then A_,B_,C_,D_ can be deleted
    for(i=0;i<Sc;i++)
        for(j=0;j<Sc;j++)
            A_[i+1][j+1] = A[i][j];


    //A.CleanUp();

}

void CBondGraph::Calculate_B() {
    //        -- calculate B matrix from Jreduced matrix
    //        -- JDD = 0
    //        - B = JXU+JXD*L*JDU
    //
    //--------------------------------------------------------
    int i,j;

    Matrix JXU(Sc,Uc);
    Matrix JXD(Sc,Rc);
    Matrix JDU(Rc,Uc);
    Matrix JXD_L(Sc,Rc);
    Matrix JXD_L_JDU(Sc,Uc);
    Matrix JXU_JXD_L_JDU(Sc,Uc);

    B.ReSize(Sc,Uc);
    B.Zero();

    // extract JXU from Jreduced
    for(i=0;i<Sc;i++)
        for(j=0;j<Uc;j++)
            JXU[i][j] = Jreduced[i][j+Sc+Rc];


    // extract JXD from Jreduced
    for(i=0;i<Sc;i++)
        for(j=0;j<Rc;j++)
            JXD[i][j] = Jreduced[i][j+Sc];


    // extract JDU from Jreduced
    for(i=0;i<Rc;i++)
        for(j=0;j<Uc;j++)
            JDU[i][j] = Jreduced[i+Sc][j+Sc+Rc];


    // calculate JXD*L*JDU
    JXD_L = JXD*Lmat;
    JXD_L_JDU = JXD_L*JDU;
    JXU_JXD_L_JDU = JXU + JXD_L_JDU;

    B = JXU_JXD_L_JDU;

#ifdef _DEBUG_EQU

    printf("Matrix JXU..........\n");
    JXU.output();
    printf("Matrix JXD..........\n");
    JXD.output();
    printf("Matrix JDU..........\n");
    JDU.output();
    printf("Matrix B..........\n");
    B.output();
    getch();
    printf("----------------------------------\n");
    printf("Matrix B..........\n");
    B.output();
#endif


    B_ = matrix(1,Sc,1,Uc);//can be delete later using other math lib!

    for(i=0;i<Sc;i++)
        for(j=0;j<Uc;j++)
            B_[i+1][j+1] = B[i][j];

    //since these matrix are local object, they memory will be freed
    //by the destructive funtion!


    //	B.CleanUp();

}

void CBondGraph::Calculate_C() {
    //        - calculate A matrix from Jreduced matrix
    //        - JDD = 0
    //        - c = (JVZ+JVD*L*JDZ)*S
    //
    //--------------------------------------------------------

    int i,j;


    Matrix	JVZ(Uc,Sc);
    Matrix	JVD(Uc,Rc);
    Matrix	JDZ(Rc,Sc);
    Matrix	JVD_L(Uc,Rc);
    Matrix	JVD_L_JDZ(Uc,Sc);
    Matrix	JVZ_JVD_L_JDZ(Uc,Sc);
    Matrix	JVZ_JVD_L_JDZ_S(Uc,Sc);

    C.ReSize(Uc,Sc);
    C.Zero();

    // extract JVZ from Jreduced
    for(i=0;i<Uc;i++)
        for(j=0;j<Sc;j++)
            JVZ[i][j] = Jreduced[i+Sc+Rc][j];


    // extract JVD from Jreduced
    for(i=0;i<Uc;i++)
        for(j=0;j<Rc;j++)
            JVD[i][j] = Jreduced[i+Sc+Rc][j+Sc];


    // extract JDZ from Jreduced
    for(i=0;i<Rc;i++)
        for(j=0;j<Sc;j++)
            JDZ[i][j] = Jreduced[i+Sc][j];


    // calculate JVD*L*JDZ
    JVD_L = JVD*Lmat;
    JVD_L_JDZ = JVD_L*JDZ;

    // calculate JVZ+JVD*L*JDZ
    JVZ_JVD_L_JDZ = JVZ+ JVD_L_JDZ;

    // calculate JVZ+JVD*L*JDZ*S
    JVZ_JVD_L_JDZ_S = JVZ_JVD_L_JDZ*Smat;


    C=JVZ_JVD_L_JDZ_S;

#ifdef _DEBUG_EQU

    printf("Matrix JVZ..........\n");
    JVZ.output();
    printf("Matrix JVD..........\n");
    JVD.output();
    printf("Matrix JDZ..........\n");
    JDZ.output();
    printf("Matrix C..........\n");
    C.output();
    getch();
    printf("----------------------------------\n");
    printf("Matrix C..........\n");
    C.output();
#endif

    C_ = matrix(1,Uc,1,Sc);//HJJ

    for(i=0;i<Uc;i++)
        for(j=0;j<Sc;j++)
            C_[i+1][j+1] = C[i][j];

}

void CBondGraph::Calculate_D() {
    //        -- calculate B matrix from Jreduced matrix
    //        -- JDD = 0
    //        - D = JVU+JVD*L*JDU
    //
    //--------------------------------------------------------

    int i,j;


    Matrix    JVU(Uc,Uc);
    Matrix    JVD(Uc,Rc);
    Matrix    JDU(Rc,Uc);
    Matrix    JVD_L(Uc,Rc);
    Matrix    JVD_L_JDU(Uc,Uc);
    Matrix    JVU_JVD_L_JDU(Uc,Uc);

    D.ReSize(Uc,Uc);
    D.Zero();
    // extract JVU from Jreduced
    for(i=0;i<Uc;i++)
        for(j=0;j<Uc;j++)
            JVU[i][j] = Jreduced[i+Sc+Rc][j+Sc+Rc];


    // extract JVD from Jreduced
    for(i=0;i<Uc;i++)
        for(j=0;j<Rc;j++)
            JVD[i][j] = Jreduced[i+Sc+Rc][j+Sc];


    // extract JDU from Jreduced
    for(i=0;i<Rc;i++)
        for(j=0;j<Uc;j++)
            JDU[i][j] = Jreduced[i+Sc][j+Sc+Rc];


    // calculate JVD*L*JDU
    JVD_L = JVD*Lmat;
    JVD_L_JDU = JVD_L*JDU;

    JVU_JVD_L_JDU = JVU+JVD_L_JDU;
    D = JVU_JVD_L_JDU;

#ifdef _DEBUG_EQU

    printf("Matrix JVU..........\n");
    JVU.output();
    printf("Matrix JVD..........\n");
    JVD.output();
    printf("Matrix JDU..........\n");
    JDU.output();
    printf("Matrix D..........\n");
    D.output();
    getch();
    printf("----------------------------------\n");
    printf("Matrix D..........\n");
    D.output();
#endif

    D_ = matrix(1,Uc,1,Uc);

    for(i=0;i<Uc;i++)
        for(j=0;j<Uc;j++)
            D_[i+1][j+1] = D[i][j];

}

//        -- set the element for Jmatrix when 'f' causal
void CBondGraph::flowSet(double val, char label1, int rowno, char label2, int colno) {

    int jr, jc;
    //global var, need initialization here
    trow.part=' ';
    trow.index=-1;
    tcol.part=' ';
    tcol.index=-1;


#ifdef _DEBUG_EQU

    printf("inside flowSet  label1=%c, rowno=%d  label2 =%c, rowno = %d\n",label1, rowno, label2, colno);
#endif //_DEBUG

    switch (label1) {
    case 'S' :
        for(jr = 0; jr<Subc; jr++)
            if(JFrow[jr].type == 'f' && JFrow[jr].index == rowno) {
                trow.part = 'F';
                trow.index = jr;
            }
        break;
    case 'R' :
        for(jr = 0; jr<Subc; jr++)
            if(JFrow[jr].type == 'f' && JFrow[jr].index == rowno) {
                trow.part = 'F';
                trow.index = jr;
            }
        break;
    case 'U' :
        for(jr = 0; jr<Subc; jr++) {
            if(JFrow[jr].type == 'f' && JFrow[jr].index == rowno) {
                trow.part = 'F';
                trow.index = jr;
            }
        }
        break;
    case 'J' :
        for(jr = 0; jr<Jc2; jr++)
            if(JIrow[jr].type == 'f' && JIrow[jr].index == rowno) {
                trow.part = 'I';
                trow.index = jr;
            }
        break;
    }

    //    printf("inside flowSet  label2=%c, colno=%d \n",label2, colno);
    switch (label2) {
    case 'S' :
        for(jc = 0; jc<Subc; jc++)
            if(JEcol[jc].type == 'f' && JEcol[jc].index == colno) {
                tcol.part = 'E';
                tcol.index = jc;
            }
        break;
    case 'R' :
        for(jc = 0; jc<Subc; jc++)
            if(JEcol[jc].type == 'f' && JEcol[jc].index == colno) {
                tcol.part = 'E';
                tcol.index = jc;
            }
        break;
    case 'U' :
        for(jc = 0; jc<Subc; jc++)
            if(JEcol[jc].type == 'f' && JEcol[jc].index == colno) {
                tcol.part = 'E';
                tcol.index = jc;
            }
        break;
    case 'J' :
        for(jc = 0; jc<Jc2; jc++)
            if(JIcol[jc].type == 'f' && JIcol[jc].index == colno) {
                tcol.part = 'I';
                tcol.index = jc;
            }
        break;
    }


#ifdef _DEBUG_EQU
    if(label1=='J'&&label2=='J') {
        printf("tcol.index = %d\n",tcol.index);
        getchar();
    }
#endif //_DEBUG
    //    printf("---trow.part =%c\n",trow.part);
    //    printf("---tcol.part =%c\n",tcol.part);

    if (trow.part == 'F' && tcol.part == 'E') {
        JFE[trow.index][tcol.index] = val;
    } else if (trow.part == 'F' && tcol.part == 'I') {
        JF[trow.index][tcol.index] = val;
    } else if (trow.part == 'I' && tcol.part == 'E') {
        JE[trow.index][tcol.index] = val;
    } else if (trow.part == 'I' && tcol.part == 'I') {
        JI[trow.index][tcol.index] = val;
    }
}



//        -- set the element for Jmatrix when 'e' causal
void CBondGraph::effortSet(double val, char label1, int rowno, char label2, int colno) {



    int jr, jc;
    //global var, need initialization here
    trow.part=' ';
    trow.index= -1;
    tcol.part=' ';
    tcol.index=-1;


#ifdef _DEBUG_EQU

    for(jr = 0; jr<Subc; jr++)
        printf("JFrow[jr].type == %c && JFrow[jr].index == %d\n",JFrow[jr].type,JFrow[jr].index);
    for(jr = 0; jr<Jc2; jr++)
        printf("JIrow[jr].type == %c && JIrow[jr].index == %d\n",JIrow[jr].type,JIrow[jr].index);
    getch();
    for(jr = 0; jr<Subc; jr++)
        printf("JEcol[jr].type == %c && JEcol[jr].index == %d\n",JEcol[jr].type,JEcol[jr].index);
    for(jr = 0; jr<Jc2; jr++)
        printf("JIcol[jr].type == %c && JIcol[jr].index == %d\n",JIcol[jr].type,JIcol[jr].index);
    getch();
    printf("inside effortSet  label1=%c, rowno=%d  label2 =%c, rowno = %d\n",label1, rowno, label2, colno);
#endif //_DEBUG

    switch (label1) {
    case 'S' :
        for(jr = 0; jr<Subc; jr++)
            if(JFrow[jr].type == 'e' && JFrow[jr].index == rowno) {
                trow.part = 'F';
                trow.index = jr;
            }
        break;
    case 'R' :
        for(jr = 0; jr<Subc; jr++)
            if(JFrow[jr].type == 'e' && JFrow[jr].index == rowno) {
                trow.part = 'F';
                trow.index = jr;
            }
        break;
    case 'U' :
        for(jr = 0; jr<Subc; jr++)
            if(JFrow[jr].type == 'e' && JFrow[jr].index == rowno) {
                trow.part = 'F';
                trow.index = jr;
            }
        break;
    case 'J' :
        for(jr = 0; jr<Jc2; jr++)
            if(JIrow[jr].type == 'e' && JIrow[jr].index == rowno) {
                trow.part = 'I';
                trow.index = jr;
            }
        break;
    }

    switch (label2) {
    case 'S' :
        for(jc = 0; jc<Subc; jc++)
            if(JEcol[jc].type == 'e' && JEcol[jc].index == colno) {
                tcol.part = 'E';
                tcol.index = jc;
            }
        break;
    case 'R' :
        for(jc = 0; jc<Subc; jc++)
            if(JEcol[jc].type == 'e' && JEcol[jc].index == colno) {
                tcol.part = 'E';
                tcol.index = jc;
            }
        break;
    case 'U' :
        for(jc = 0; jc<Subc; jc++)
            if(JEcol[jc].type == 'e' && JEcol[jc].index == colno) {
                tcol.part = 'E';
                tcol.index = jc;
            }
        break;
    case 'J' :
        for(jc = 0; jc<Jc2; jc++)
            if(JIcol[jc].type == 'e' && JIcol[jc].index == colno) {
                tcol.part = 'I';
                tcol.index = jc;
            }
        break;
    }


#ifdef _DEBUG_EQU
    printf("---trow.part =%c  index = %d\n",trow.part, trow.index);
    printf("---tcol.part =%c  index = %d\n",tcol.part,tcol.index);
#endif //_DEBUG_EQU


    if (trow.part == 'F' && tcol.part == 'E') {
        JFE[trow.index][tcol.index] = val;
    } else if (trow.part == 'F' && tcol.part == 'I') {
        JF[trow.index][tcol.index] = val;
    } else if (trow.part == 'I' && tcol.part == 'E') {
        JE[trow.index][tcol.index] = val;
    } else if (trow.part == 'I' && tcol.part == 'I') {
        JI[trow.index][tcol.index] = val;
#ifdef _DEBUG_EQU

        printf("*****Jint Matrix is set an element value %f\n",val);
        getch();
#endif //_DEBUG_EQU

    }

}


//        -- set the element for Jmatrix with GY
void CBondGraph::efSet(char causal, double val, char label1, int rowno, char label2, int colno) {

    int jr, jc;
    char anticausal;
    //global var, need initialization here
    trow.part=' ';
    trow.index=-1;
    tcol.part=' ';
    tcol.index=-1;

    if (causal == 'e')
        anticausal = 'f';
    else
        anticausal = 'e';


    switch (label1) {
    case 'S' :
        for(jr = 0; jr<Subc; jr++)
            if(JFrow[jr].type == causal && JFrow[jr].index == rowno) {
                trow.part = 'F';
                trow.index = jr;
            }
        break;
    case 'R' :
        for(jr = 0; jr<Subc; jr++)
            if(JFrow[jr].type == causal && JFrow[jr].index == rowno) {
                trow.part = 'F';
                trow.index = jr;
            }
        break;
    case 'U' :
        for(jr = 0; jr<Subc; jr++)
            if(JFrow[jr].type == causal && JFrow[jr].index == rowno) {
                trow.part = 'F';
                trow.index = jr;
            }
        break;
    case 'J' :
        for(jr = 0; jr<Jc2; jr++)
            if(JIrow[jr].type == causal && JIrow[jr].index == rowno) {
                trow.part = 'I';
                trow.index = jr;
            }
        break;
    }

    switch (label2) {
    case 'S' :
        for(jc = 0; jc<Subc; jc++)
            if(JEcol[jc].type == anticausal && JEcol[jc].index == colno) {
                tcol.part = 'E';
                tcol.index = jc;
            }
        break;
    case 'R' :
        for(jc = 0; jc<Subc; jc++)
            if(JEcol[jc].type == anticausal && JEcol[jc].index == colno) {
                tcol.part = 'E';
                tcol.index = jc;
            }
        break;
    case 'U' :
        for(jc = 0; jc<Subc; jc++)
            if(JEcol[jc].type == anticausal && JEcol[jc].index == colno) {
                tcol.part = 'E';
                tcol.index = jc;
            }
        break;
    case 'J' :
        for(jc = 0; jc<Jc2; jc++)
            if(JIcol[jc].type == anticausal && JIcol[jc].index == colno) {
                tcol.part = 'I';
                tcol.index = jc;
            }
        break;
    }


    if (trow.part == 'F' && tcol.part == 'E') {
        JFE[trow.index][tcol.index] = val;
    } else if (trow.part == 'F' && tcol.part == 'I') {
        JF[trow.index][tcol.index] = val;
    } else if (trow.part == 'I' && tcol.part == 'E') {
        JE[trow.index][tcol.index] = val;
    } else if (trow.part == 'I' && tcol.part == 'I') {
        JI[trow.index][tcol.index] = val;
    }
}

void CBondGraph::Calculate_A1() {
    //        -- calculate A matrix from Jreduced matrix
    //        -- JDD != 0
    //
    //--------------------------------------------------------
    int i,j;


    Matrix    I (Rc,Rc);
    Matrix    JXZ(Sc,Sc);
    Matrix    JXZ_S(Sc,Sc);
    Matrix    JXD(Sc,Rc);
    Matrix    JXD_L(Sc,Rc);
    Matrix    JDZ (Rc,Sc);
    Matrix    JDZ_S(Rc,Sc);

    Matrix  JDD(Rc,Rc);
    Matrix  I_JDD(Rc,Rc);
    Matrix  INV_I_JDD(Rc,Rc);
    Matrix  JXD_L_INV_I_JDD(Sc,Rc);
    Matrix 	JXD_L_INV_I_JDD_JDZ_S(Sc,Sc);

    A.ReSize(Sc,Sc);
    A.Zero();
    // extract JXZ from Jreduced
    // calculate JXZ*S
    for(i=0;i<Sc;i++)
        for(j=0;j<Sc;j++)
            JXZ[i][j] = Jreduced[i][j];

    JXZ_S = JXZ*Smat;
    // extract JXD from Jreduced
    // calculate JXD*L*inv(I-JDD)
    for(i=0;i<Sc;i++)
        for(j=0;j<Rc;j++) {
            JXD[i][j] = Jreduced[i][j+Sc];
        }
    JXD_L = JXD*Lmat;

#ifdef _DEBUG

    printf("Matrix JXZ..........\n");
    JXZ.output();
    printf("Matrix JXD..........\n");
    JXD.output();
#endif

    // set up I matrix for I-JDD
    I.Unit();
    // extract JDD from Jreduced
    // calculate [I-JDD]
    for(i=0;i<Rc;i++)
        for(j=0;j<Rc;j++) {
            JDD[i][j] = Jreduced[i+Sc][j+Sc];
        }
    for(i=0;i<Rc;i++)
        for(j=0;j<Rc;j++)
            I_JDD[i][j]= I[i][j] - JDD[i][j];


    INV_I_JDD = I_JDD.i();
    JXD_L_INV_I_JDD = JXD_L*INV_I_JDD;

#ifdef _DEBUG

    printf("Matrix JDD..........\n");
    JDD.output();
    printf("Matrix INV_I_JDD..........\n");
    INV_I_JDD.output();
    printf("Matrix JXD_L_INV_I_JDD..........\n");
    JXD_L_INV_I_JDD.output();
#endif

    // extract JDZ from Jreduced
    // calculate JDZ*S
    for(i=0;i<Rc;i++)
        for(j=0;j<Sc;j++) {
            JDZ[i][j] = Jreduced[i+Sc][j];
        }

    JDZ_S = JDZ*Smat;
    JXD_L_INV_I_JDD_JDZ_S = JXD_L_INV_I_JDD*JDZ_S;

    A = JXZ_S + JXD_L_INV_I_JDD_JDZ_S;

#ifdef _DEBUG

    printf("Matrix JXD_L_INV_I_JDD_JDZ_S..........\n");
    JXD_L_INV_I_JDD_JDZ_S.output();
    printf("Matrix A..........\n");
    A.output();
#endif

    A_ = matrix(1,Sc,1,Sc);
    for(i=0;i<Sc;i++)
        for(j=0;j<Sc;j++)
            A_[i+1][j+1] = A[i][j];

}

//the dimension and allocate memory for the intermediate matrix


void CBondGraph::initialize_Matrix() {
    list<CBond*>::iterator bk;

    int i,j;
    int Scount=0, Rcount=0, Ucount=0, Jcount=0;
    int si=0, ri=0, ui=0, ji=0;

    // count the no. of each U/S/R/J
    for(bk = BondList.begin();bk!=BondList.end();bk++) {
        if ((*bk)->m_Label== 'S' )
            Scount++;
        else if ((*bk)->m_Label== 'R' )
            Rcount++;
        else if ((*bk)->m_Label== 'U' )
            Ucount++;
        else if ((*bk)->m_Label== 'J' )
            Jcount++;
    }

    Sc = Scount;	// check later?
    Rc = Rcount;
    Uc = Ucount;
    Jc = Jcount;	//  distinguish
    Jc2 = 2*Jcount;	//  distinguish
    Subc = Sc + Rc + Uc;

    // memory allocation
    X.resize(Sc);
    Z.resize(Sc);
    Xdot.resize(Sc);


    U.resize(Uc);
    V.resize(Uc);
    Do.resize(Sc);
    Di.resize(Rc);

    Ej.resize(Jc);
    Fj.resize(Jc);

    JFrow.resize(Sc+Rc+Uc);
    JEcol.resize(Sc+Rc+Uc);

    JIrow.resize(Jc2);
    JIcol.resize(Jc2);

    Smat.ReSize(Sc,Sc);
    Lmat.ReSize(Rc,Rc);

    JFE.ReSize(Subc,Subc);
    JF.ReSize(Subc,Jc2);
    JE.ReSize(Jc2,Subc);
    JI.ReSize(Jc2,Jc2);
    Jreduced.ReSize(Subc,Subc);

    for(bk = BondList.begin();bk!=BondList.end();bk++) {
        i = (*bk)->m_No;
        ; //HJJ
        if ((*bk)->m_Label== 'S' ) { //I/C
            //fromport is from Energy source, Toport is Energy absorber.
            if ((*bk)->m_pFromPort->IsEffortCausal()) {  //so from and To must be made different
                X[si].type = 'p';
                Z[si].type = 'e';
                Z[si].index = i;
                Xdot[si].type = 'f';
                Xdot[si].index = i;
                si++;
            } else {
                X[si].type = 'q';
                Z[si].type = 'f';
                Z[si].index = i;
                Xdot[si].type = 'e';
                Xdot[si].index = i;
                si++;
            }
        } else if ((*bk)->m_Label== 'R' ) { //Resistor
            if ((*bk)->m_pFromPort->IsEffortCausal()) {  //so from and To must be made different
                Do[ri].type = 'e';
                Do[ri].index = i;
                Di[ri].type = 'f';
                Di[ri].index = i;
                ri++;
            } else {
                Do[ri].type = 'f';
                Do[ri].index = i;
                Di[ri].type = 'e';
                Di[ri].index = i;
                ri++;
            }
        } else if ((*bk)->m_Label== 'U' ) {//SE, SF  later  Sf check!!!
            CPort *pToPort;
            pToPort = (*bk)->m_pToPort;

            //find the port attached to SE/SF
            if((*bk)->m_pToPort->m_pComponent->m_Type!=SE&&
                    (*bk)->m_pToPort->m_pComponent->m_Type!=SF)
                pToPort = (*bk)->m_pFromPort;

            //we decide the row and column variable by Energy Source Types
            if (pToPort->m_pComponent->m_Type ==SE) {  //so from and To must be made different
                U[ui].type = 'e';
                U[ui].index = i;
                V[ui].type = 'f';
                V[ui].index = i;
                ui++;
            } else {
                U[ui].type = 'f';
                U[ui].index = i;
                V[ui].type = 'e';
                V[ui].index = i;
                ui++;
            }
        } else if ((*bk)->m_Label== 'J' ) {
            Ej[ji].type = 'e';
            Ej[ji].index = i;
            Fj[ji].type = 'f';
            Fj[ji].index = i;
            ji++;
        }
    }

    // assign row and column for entire J matrix
    j=0;
    for (si=0; si<Sc; si++) {
        JFrow[j].index = Xdot[si].index;
        JFrow[j].type = Xdot[si].type;
        JEcol[j].index = Z[si].index;
        JEcol[j].type = Z[si].type;
        j++;
    }
    //    getchar();
    for (ri=0; ri<Rc; ri++) {
        JFrow[j].index = Di[ri].index;
        JFrow[j].type = Di[ri].type;
        JEcol[j].index = Do[ri].index;
        JEcol[j].type = Do[ri].type;
        j++;
    }
    //	getchar();
    for (ui=0; ui<Uc; ui++) {
        JFrow[j].index = V[ui].index;
        JFrow[j].type = V[ui].type;
        JEcol[j].index = U[ui].index;
        JEcol[j].type = U[ui].type;
        j++;
    }
    //	getchar();
    j =0;
    for (ji=0; ji<Jc; ji++) {
        JIrow[j].index = Ej[ji].index;
        JIrow[j].type = Ej[ji].type;
        JIcol[j].index = Ej[ji].index;
        JIcol[j].type = Ej[ji].type;
        j++;
    }
    //	   getchar();
    for (ji=0; ji<Jc; ji++) {
        JIrow[j].index = Fj[ji].index;
        JIrow[j].type = Fj[ji].type;
        JIcol[j].index = Fj[ji].index;
        JIcol[j].type = Fj[ji].type;
        j++;
    }
    //    getchar();


    Smat.Zero();
    Lmat.Zero();
    JFE.Zero();
    JE.Zero();
    JF.Zero();
    JI.Zero();
    Jreduced.Zero();

    if(A_!=NULL)
        free_matrix(A_,1,Sc,1,Sc);
    if(B_!=NULL)
        free_matrix(B_,1,Sc,1,Sc);
    if(C_!=NULL)
        free_matrix(C_,1,Sc,1,Sc);
    if(D_!=NULL)
        free_matrix(D_,1,Sc,1,Sc);


}

int CBondGraph::SetPowerDirection() {
    int status;
    printf("\n\nOOPS Problem remains, to be debuged\n");
    exit(0);

    //HJJ temporary routine
    list<CComponent*>::iterator ek;//element list
    //set SE, SF who has no causality yet, with required causality

    ClearPowerDirection();

    for(ek = ElementList.begin(); ek!= ElementList.end();ek++) {
        if((*ek)->m_Type == SE||(*ek)->m_Type == SF) {  //HJJ pay attention to the {} of if statement!!!!
            if(!((CElement1Port*)(*ek))->m_Port[0].IsPowerDirectDefined()) { //SE not specified
                status = (*ek)->SetPowerDirect(OUT, NULL);
                if(status==-1)
                    return (m_PowerDirectStatus=-1);
            }
        }
    }

    for(ek = ElementList.begin(); ek!= ElementList.end();ek++) {
        if((*ek)->m_Type == INDUCTOR ||(*ek)->m_Type ==CAPACITOR||(*ek)->m_Type ==RESISTOR) {
            if(!((CElement1Port*)(*ek))->m_Port[0].IsPowerDirectDefined()) { //SE not specified
                status = ((CElement1Port*)(*ek))->SetPowerDirect(IN);
                if(status==-1)
                    return (m_PowerDirectStatus=-1);
            }
        }
    }
    /*	Report();
    	getch();*/
    return 0;

}

int CBondGraph::CheckPowerDirection() {
    list<CBond*>::iterator bk;

    //	printf("checking causality....\n");
    //	ReportCausality();
    for(bk = BondList.begin();bk!=BondList.end();bk++) {
        if(!(*bk)->m_pFromPort->IsPowerDirectDefined() ||!(*bk)->m_pToPort->IsPowerDirectDefined())
            return (m_PowerDirectStatus=-1);// insufficiency
    }

    return (m_PowerDirectStatus=0);//success

}

void CBondGraph::ClearPowerDirection() {
    list<CBond*>::iterator bk;

    for(bk = BondList.begin();bk!=BondList.end();bk++) {
        (*bk)->m_pFromPort->ClearPowerDirect();
        (*bk)->m_pToPort->ClearPowerDirect();
    }
    m_PowerDirectStatus=1;// reset

}

void CBondGraph::Save( int What, FILE* fp) {

    //	int What = BONDGRAPH_ALL;
    list<CJunction*>::iterator jk;//define the iterator of list
    list<CBond*>::iterator bk;
    list<CComponent*>::iterator ek;//element list

    //save the result to file
    fprintf(fp,"\n>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n");
    //save the bondgraph structure
    PrintGraph(BONDGRAPH_ALL, fp);

    //Save parameters of elements in Bondgraph
    if(What==BONDGRAPH_ALL||What==BONDGRAPH_PARAM) {
        fprintf(fp,"..................................\n");
        fprintf(fp,"Bondgraph Parameters\n");
        fprintf(fp,"Bonds:  %d\tJunctions:  %d\tElements:  %d\n\n", BondList.size(),
                JunctionList.size(),ElementList.size());

        for(ek = ElementList.begin(); ek!= ElementList.end();ek++) {
            fprintf(fp,"Element[%4d]: name = %s, PortNum = %4d, ParamValue = %10.3f\n",
                    (*ek)->m_No,(*ek)->m_Name.data(),(*ek)->m_PortNum, (*ek)->m_ParamValue);
        }
    }

    //Save the causality and power direction
    if(What==BONDGRAPH_ALL||What==BONDGRAPH_CAUSALITY) {
        fprintf(fp,"..................................\n");
        fprintf(fp,"Topology connections.\n");
        fprintf(fp,"\nBond[num ] ==  Elno:typ|CA|PW <------>  Elno:typ|CA|PW\n");
        fprintf(fp,"......................................................\n");
        for(bk = BondList.begin();bk!=BondList.end();bk++) {
            fprintf(fp,"Bond[%4d] ==  %4d:%3s|%2d|%2d <------>  %4d:%3s|%2d|%2d\n",
                    (*bk)->m_No,(*bk)->m_pFromPort->m_pComponent->m_No, (*bk)->m_pFromPort->m_pComponent->m_Name.data(),
                    (*bk)->m_pFromPort->GetCausalityType(),(*bk)->m_pFromPort->GetPowerDirect(),
                    (*bk)->m_pToPort->m_pComponent->m_No,(*bk)->m_pToPort->m_pComponent->m_Name.data(),
                    (*bk)->m_pToPort->GetCausalityType(),(*bk)->m_pToPort->GetPowerDirect());
        }
    }
    fprintf(fp,"\n<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<\n");

}

void CBondGraph::Save(char *filename) {
    FILE* fp;
    fp = fopen(filename,"w+");
    if ( fp == NULL ) {
        printf("Error: Couldn't open file: \"%s\".",
               filename );
        exit(-1);
    }
    Save(BONDGRAPH_ALL, fp);
    fclose(fp);

}

int CBondGraph::nJunctions() {
    if(!m_bRefreshed)
        makeStatistics();

    return m_nJunctions;

}

int CBondGraph::nBonds() {
    if(!m_bRefreshed)
        makeStatistics();

    return m_nBonds;

}

int CBondGraph::nPorts() {
    if(!m_bRefreshed)
        makeStatistics();

    return m_nPorts;

}

int CBondGraph::nCapacitors() {
    if(!m_bRefreshed)
        makeStatistics();

    return m_nCapacitors;
}

int CBondGraph::nInductors() {
    if(!m_bRefreshed)
        makeStatistics();

    return m_nInductors;
}

int CBondGraph::nResistors() {
    if(!m_bRefreshed)
        makeStatistics();

    return m_nResistors;
}

int CBondGraph::nGyrates() {
    if(!m_bRefreshed)
        makeStatistics();

    return m_nGyrates;
}

int CBondGraph::nTransformers() {
    if(!m_bRefreshed)
        makeStatistics();

    return m_nTransformers;
}

int CBondGraph::nEffortSources() {
    if(!m_bRefreshed)
        makeStatistics();

    return m_nEffortSources;

}

int CBondGraph::nFlowSources() {
    if(!m_bRefreshed)
        makeStatistics();

    return m_nFlowSources;

}

int CBondGraph::nElements() {
    if(!m_bRefreshed)
        makeStatistics();

    return m_nElements;

}
int CBondGraph::nJunction0s() {
    if(!m_bRefreshed)
        makeStatistics();

    return m_nJunction0s;

}

int CBondGraph::nJunction1s() {
    if(!m_bRefreshed)
        makeStatistics();

    return m_nJunction1s;

}


void CBondGraph::makeStatistics() {
    if(m_bRefreshed)
        return;//there is no change since last MakeStatistics,
    //So unnecesseary to calculate the statistics of
    //Bondgraph again!
    list<CJunction*>::iterator jk;//define the iterator of list
    list<CBond*>::iterator bk;
    list<CComponent*>::iterator ek;//element list

    m_nElements = ElementList.size();//How many I/R/C/SE/SF/GY/TF
    m_nBonds = BondList.size();
    m_nJunctions =JunctionList.size();
    m_nJunction0s =0;
    m_nJunction1s =0;

    m_nPorts = m_nBonds*2;

    m_nFlowSources  = 0;
    m_nEffortSources = 0;
    m_nTransformers = 0;
    m_nGyrates = 0;
    m_nResistors = 0;
    m_nInductors = 0;
    m_nCapacitors = 0;


    int maxDegree = 1;

    for(jk = JunctionList.begin(); jk!=JunctionList.end();jk++) {
        if((*jk)->m_Type==JUNCTION0)
            m_nJunction0s++;
        if((*jk)->m_PortNum > maxDegree)
            maxDegree= (*jk)->m_PortNum;
    }

    m_MaxDegree = maxDegree;
    m_nJunction1s = m_nJunctions-m_nJunction0s;



    for(ek = ElementList.begin(); ek!= ElementList.end();ek++) {
        //		printf("makeStatistics: element = %s \n", (*ek)->m_Name.data());
        switch((*ek)->m_Type) {
        case SE:
            m_nEffortSources++;
            break;
        case SF:
            m_nFlowSources++;
            break;
        case CAPACITOR:
            m_nCapacitors++;
            break;
        case INDUCTOR:
            m_nInductors++;
            break;
        case RESISTOR:
            m_nResistors++;
            break;
        case TF:
            m_nTransformers++;
            break;
        case GY:
            m_nGyrates++;
            break;
        }
    }

    //compute the depth of the Bondgraph
    calculateMaxDepth();
    m_bRefreshed = true;
}





int CBondGraph::GetMaxDepth() {
    if(!m_bRefreshed)
        makeStatistics();

    return m_MaxDepth;


}


//HJJD  need more debug!
int CBondGraph::calculateMaxDepth() {

    list<CJunction*>::iterator jk;//define the iterator of list
    list<CBond*>::iterator bk;
    list<CComponent*>::iterator ek;//element list

    ClearDepthFlag();//initialize the depth flag

    int currMaxDepth=0;
    int setNo=0;
    CComponent* pComp;
    do {
        setNo = 0;
        for(ek = ElementList.begin(); ek!= ElementList.end();ek++) {
            if((*ek)->m_Depth!=-1)
                continue;

            if((*ek)->m_Type == TF||(*ek)->m_Type== GY||(*ek)->m_Type== JUNCTION0||(*ek)->m_Type== JUNCTION1) {
                //bool bFound=false;

                for(int i=0;i<(*ek)->m_PortNum; i++) {
                    if((*ek)->m_Type==TF||(*ek)->m_Type== GY)
                        pComp = ((CElement2Port*)(*ek))->m_Port[i].m_pComponent;
                    else
                        pComp = ((CJunction*)(*ek))->m_Port[i].m_pComponent;

                    if(pComp->m_Depth==currMaxDepth) {
                        (*ek)->m_Depth=currMaxDepth++;
                        setNo++;//
                        break;
                    }
                }
            }
        }

        if(setNo!=0)
            currMaxDepth++;
    } while(setNo!=0);

    m_MaxDepth = currMaxDepth;


    return currMaxDepth;
}

void CBondGraph::ClearDepthFlag() {
    list<CJunction*>::iterator jk;//define the iterator of list
    for(jk = JunctionList.begin(); jk!=JunctionList.end();jk++) {
        (*jk)->m_Depth=-1;
    }
}



void CBondGraph::printGraphRecursive(CComponent *pComp, int x, int y, CGraphPrint* g, int what) {
    char symbol;
    int i;
    list<CComponent*>	pNeighborList;
    vector<CComponent*>   pElementList;
    list<CComponent*>::iterator ek;//element list
    CPort* pEndPort;
    //printf(" Node type = %s\n", pComp->m_Name.data());



    //************************************************************************
    //print out 0 1, TF, GY, I R C

    if( what == BONDGRAPH_PARAM || what == BONDGRAPH_ALL) {
        if(pComp==NULL)
            return;
        if(pComp->m_Type != JUNCTION0 && pComp->m_Type!=JUNCTION1 &&
                pComp->m_Type!= TF && pComp->m_Type!=GY) {
            printf("CBondgraph:: printGraphResursive: Error!\n");
            printf("pcomponent Type: %s\n", pComp->m_Name.data());
            printf("printGraphResursive:  Junction node required!\n");
            exit(-1);
            return;
        }

        //find neighbor junctions
        for(i=0;i<pComp->m_PortNum;i++) {
            if(pComp->m_Type ==TF || pComp->m_Type ==GY) {
                if(((CElement2Port*)pComp)->m_Port[i].m_pBond->m_pToPort == &((CElement2Port*)pComp)->m_Port[i])
                    pEndPort = ((CJunction*)pComp)->m_Port[i].m_pBond->m_pFromPort;
                else
                    pEndPort = ((CJunction*)pComp)->m_Port[i].m_pBond->m_pToPort;
            } else {
                if(((CJunction*)pComp)->m_Port[i].m_pBond->m_pToPort == &((CJunction*)pComp)->m_Port[i])
                    pEndPort = ((CJunction*)pComp)->m_Port[i].m_pBond->m_pFromPort;
                else
                    pEndPort = ((CJunction*)pComp)->m_Port[i].m_pBond->m_pToPort;
            }

            if((pEndPort->m_pComponent->m_Type == JUNCTION0 ||pEndPort->m_pComponent->m_Type == JUNCTION1
                    ||pEndPort->m_pComponent->m_Type == TF ||pEndPort->m_pComponent->m_Type == GY) &&
                    (!pEndPort->m_pComponent->m_bVisited)) {
                pNeighborList.push_back(pEndPort->m_pComponent);
            } else if((pEndPort->m_pComponent->m_Type == INDUCTOR ||pEndPort->m_pComponent->m_Type == CAPACITOR
                       ||pEndPort->m_pComponent->m_Type == RESISTOR||pEndPort->m_pComponent->m_Type == SE
                       ||pEndPort->m_pComponent->m_Type == SF ) && 	(!pEndPort->m_pComponent->m_bVisited)) {
                pElementList.push_back(pEndPort->m_pComponent);
            }

        }

        //print current junction
        switch (pComp->m_Type) {
        case JUNCTION0:
            symbol='0';
            break;
        case JUNCTION1:
            symbol='1';
            break;
        case TF:
            symbol='T';
            break;
        case GY:
            symbol='G';
            break;
        }
        g->Write(x,y,symbol);
        pComp->m_bVisited=true;

        //Print the label of each component
        //we can represent the loop by two duplicate of the same Junction of TF/GY
        if( what == BONDGRAPH_ALL) {
            char param[10];
            //itoa(pComp->m_No,param,10);
            sprintf(param,"%d",pComp->m_No);

            int slength = 0;
            while(param[slength]!= '\0')
                slength++;
            for(int si =0;si<slength;si++)
                g->Write(x-slength+si,y, param[si]);
        }


        //recursively call to print the neighbor node
        if(pNeighborList.size() == 0) {
            //print related I R C SF SE node
            for(int ki=0;ki<pElementList.size();ki++) {
                CComponent *pComp = pElementList[ki];
                char param[10];
                //itoa(pComp->m_No,param,10);
                sprintf(param,"%d",pComp->m_No);
                switch(pComp->m_Type) {
                case INDUCTOR:
                    g->Write(x-1, y+1+ki,'I');
                    break;
                case CAPACITOR:
                    g->Write(x-1, y+1+ki,'C');
                    break;
                case RESISTOR:
                    g->Write(x-1, y+1+ki,'R');
                    break;
                case SE:
                    g->Write(x-1, y+1+ki,'E');
                    break;
                case SF:
                    g->Write(x-1, y+1+ki,'F');
                    break;
                }

                if( what == BONDGRAPH_ALL) {
                    int slength = 0;
                    while(param[slength]!= '\0')
                        slength++;
                    for(int si =0;si<slength;si++) {
                        g->Write(x-1-slength+si,y+1+ki, param[si]);
                    }
                }
            }
            return;
        }

        //alternate between two kinds of line symbol
        if(g->CurrLineSymbol==g->lineSymbol[0])
            g->CurrLineSymbol = g->lineSymbol[1];
        else
            g->CurrLineSymbol = g->lineSymbol[0];
        char lineSym = g->CurrLineSymbol;//used for this generation



        i=0;
        int EndX,EndY,StartX,StartY;
        for(ek = pNeighborList.begin(); ek!= pNeighborList.end();ek++) {
            if(i==0) {
                StartX = x+1;
                StartY = y;
                EndX = x+m_LineSpace+1;
                EndY = y;

                g->Line(StartX, StartY, EndX,EndY,lineSym, COUNTER_CLOCKWISE);
                printGraphRecursive((*ek),EndX, EndY,g, what);
                i++;
            } else {
                StartX = x;
                StartY = y+1;
                EndX = x+m_LineSpace+1;
                EndY = y+i*(m_LineSpace+1);
                if(!g->IsPathEmpty(StartX, StartY, g->Xmax,EndY,COUNTER_CLOCKWISE)) {
                    EndY = g->GetCurrentMaxY() + 2;//
                }

                g->Line(StartX, StartY, EndX,EndY,lineSym, COUNTER_CLOCKWISE);
                printGraphRecursive((*ek),EndX, EndY,g, what);
                i++;
            }

        }

        //print related I R C SF SE node
        for(int ki=0;ki<pElementList.size();ki++) {
            CComponent *pComp = pElementList[ki];
            char param[10];
            //itoa(pComp->m_No,param,10);
            sprintf(param,"%d",pComp->m_No);

            switch(pComp->m_Type) {
            case INDUCTOR:
                g->Write(x-1, y+1+ki,'I');
                break;
            case CAPACITOR:
                g->Write(x-1, y+1+ki,'C');
                break;
            case RESISTOR:
                g->Write(x-1, y+1+ki,'R');
                break;
            case SE:
                g->Write(x-1, y+1+ki,'E');
                break;
            case SF:
                g->Write(x-1, y+1+ki,'F');
                break;
            }

            if( what == BONDGRAPH_ALL) {
                int slength = 0;
                while(param[slength]!= '\0')
                    slength++;
                for(int si =0;si<slength;si++) {
                    g->Write(x-1-slength+si,y+1+ki, param[si]);
                }
            }

        }
        return;
    }

    //Print option 1:  only printout the junction 0/1 structure
    //Seldom used
    if( what == BONDGRAPH_FRAME) {
        if(pComp->m_Type != JUNCTION0 && pComp->m_Type!=JUNCTION1) {
            printf("pcomponent Type: %s\n", pComp->m_Name.data());
            printf("printGraphResursive:  Junction node required!\n");
            exit(-1);
            return;
        }


        //find neighbor junctions
        for(i=0;i<pComp->m_PortNum;i++) {

            if(((CJunction*)pComp)->m_Port[i].m_pBond->m_pToPort == &((CJunction*)pComp)->m_Port[i])
                pEndPort = ((CJunction*)pComp)->m_Port[i].m_pBond->m_pFromPort;
            else
                pEndPort = ((CJunction*)pComp)->m_Port[i].m_pBond->m_pToPort;

            if((pEndPort->m_pComponent->m_Type == JUNCTION0 ||pEndPort->m_pComponent->m_Type == JUNCTION1||
                    pEndPort->m_pComponent->m_Type == TF||pEndPort->m_pComponent->m_Type == GY  ) &&
                    (!pEndPort->m_pComponent->m_bVisited)) {
                pNeighborList.push_back(pEndPort->m_pComponent);
            }

        }


        //print current junction
        if(pComp->m_Type==JUNCTION0)
            symbol='0';
        else
            symbol = '1';
        g->Write(x,y,symbol);
        pComp->m_bVisited=true;


        //recursively call to print the neighbor node
        if(pNeighborList.size() == 0)
            return;

        //alternate between two kinds of line symbol
        if(g->CurrLineSymbol==g->lineSymbol[0])
            g->CurrLineSymbol = g->lineSymbol[1];
        else
            g->CurrLineSymbol = g->lineSymbol[0];
        char lineSym = g->CurrLineSymbol;//used for this generation



        i=0;
        int EndX,EndY,StartX,StartY;
        for(ek = pNeighborList.begin(); ek!= pNeighborList.end();ek++) {
            if(i==0) {
                StartX = x+1;
                StartY = y;
                EndX = x+m_LineSpace+1;
                EndY = y;
            } else {
                StartX = x;
                StartY = y+1;
                EndX = x+m_LineSpace+1;
                EndY = y+i*(m_LineSpace+1);
            }
            if(!g->IsPathEmpty(StartX, StartY, EndX,EndY,COUNTER_CLOCKWISE)) {
                EndX++;
                EndY--;
            }
            EndY = g->GetCurrentMaxY() + 2;

            g->Line(StartX, StartY, EndX,EndY,lineSym, COUNTER_CLOCKWISE);
            printGraphRecursive((*ek),EndX, EndY,g, what);
            i++;
        }
        return;
    }//printout bondgraph frame option

}

void CBondGraph::CleanVisitedLabel() {
    list<CBond*>::iterator bk;

    for(bk = BondList.begin();bk!=BondList.end();bk++) {
        (*bk)->m_pFromPort->m_pComponent->m_bVisited=false;
        (*bk)->m_pToPort->m_pComponent->m_bVisited=false;
    }


}



void CBondGraph::PrintGraph( int what, FILE* stream) {

    //	CGraphPrint* graph=new CGraphPrint(500,500);//dos command window, print graph toolbox
    graph->flush();
    graph->SetLineSymbol(0, '.');
    graph->SetLineSymbol(1, '.');
    CleanVisitedLabel();

    fprintf(stream,"......................................................Bondgraph Structure\n");

    //print to the char matrix
    if(JunctionList.size()==0) {
        //there is no junction in this bondgraph, so only one bond with two element. start from bond
        fprintf(stream,"********** bondgraph with no junction **********\n");
        return;
    } else {
        printGraphRecursive((*JunctionList.begin()), 5,1,graph,what);
    }

    //output the char matrix
    graph->Print(stream);

    return;
}

//simplify the bondgraph to be standard Bondgraph
// 1. eliminate junctions which has no junctions who has no one port element attached.
// 2. combine neighbor transformers and Gyrates
// 3. Combine parallel or serial I/R/C


void CBondGraph:: Simplify(int option){

}


/*!
 *  \brief Extract Object from a  input stream.
 *  \param ioIS Input stream to read the object from.
 */
void CBondGraph::read(std::istream& ioIS) {
    int nElements;
    int nJunctions;
    int nBonds;
    int componentType;
    CComponent* newElement;

    ioIS>>nElements;
    ioIS>>nJunctions;
    ioIS>>nBonds;
    for(int i=0;i<nElements;i++) {
        ioIS>>componentType;
        switch (componentType) {  //Algorithm update
        case SE:
            newElement =new CSourceEffort();
            ElementList.push_back(newElement);
            break;
        case SF:
            newElement = new CSourceFlow();
            ElementList.push_back(newElement);
            break;
        case CAPACITOR:
            newElement = new CCapacitor();
            ElementList.push_back(newElement);
            break;
        case INDUCTOR:
            newElement = new CInductor();
            ElementList.push_back(newElement);
            break;
        case RESISTOR:
            newElement = new CResistor();
            ElementList.push_back(newElement);
            break;
        case TF:
            newElement = new CTransformer();
            ElementList.push_back(newElement);
            break;
        case GY:
            newElement = new CGyrate();
            ElementList.push_back(newElement);
            break;
        }
        newElement->read(ioIS);
        for(int k=0;k<newElement->m_PortNum;k++)
            newElement->m_Port[k].m_pComponent=newElement;
    }

    for(int i=0;i<nJunctions;i++) {
        ioIS>>componentType;
        if(componentType==JUNCTION0) {
            newElement =new CJunction0();
            JunctionList.push_back((CJunction0*)newElement);
        } else {
            newElement =new CJunction1();
            JunctionList.push_back((CJunction1*)newElement);
        }
        newElement->read(ioIS);
        for(int k=0;k<newElement->m_PortNum;k++)
            newElement->m_Port[k].m_pComponent=newElement;
    }

    std::list<CComponent*>::iterator ei;//element list
    std::list<CBond*>::iterator bk;
    std::list<CJunction*>::iterator jk;

    int sourceType, sourceID, sourcePort;
    int destType, destID, destPort;
    CComponent* pSourceComponent, *pDestComponent;

    for(int i=0;i<nBonds;i++) {
        CBond* pBond = new CBond();
        BondList.push_back(pBond);
        ioIS>>pBond->m_Type;
        ioIS>>pBond->m_Name;
        ioIS>>pBond->m_No;
        ioIS>>pBond->m_WriteNo;
        ioIS>>pBond->m_PortNum;

        ioIS>>sourceType;
        ioIS>>sourceID;
        ioIS>>sourcePort;

        ioIS>>destType;
        ioIS>>destID;
        ioIS>>destPort;
        //check if the from element exist.
        if(sourceType==JUNCTION0 ||sourceType==JUNCTION1) {
            //search in junction list
            for(jk = JunctionList.begin(); jk!= JunctionList.end();jk++) {
                if( (*jk)->m_No == sourceID)
                    break;
            }
            if( jk==JunctionList.end()) {
                std::cout<<"error: junction "<< sourceID<<" doesn't exist!\n";
                exit(-1);
            } else
                pSourceComponent= (*jk);
        } else {
            //search in element list
            for(ei = ElementList.begin(); ei!= ElementList.end();ei++) {
                if( (*ei)->m_No == sourceID)
                    break;
            }
            if( ei==ElementList.end()) {
                std::cout<<"error: component "<< sourceID<<" doesn't exist!\n";
                exit(-1);
            } else
                pSourceComponent= (*ei);
        }

        //check if the to element exists.
        if(destType==JUNCTION0 ||destType==JUNCTION1) {
            //search in junction list
            for(jk = JunctionList.begin(); jk!= JunctionList.end();jk++) {
                if( (*jk)->m_No == destID)
                    break;
            }
            if( jk==JunctionList.end()) {
                std::cout<<"error: junction "<< destID<<" doesn't exist!\n";
                exit(-1);
            } else
                pDestComponent= (*jk);
        } else {
            //search in junction list
            for(ei = ElementList.begin(); ei!= ElementList.end();ei++) {
                if( (*ei)->m_No == destID)
                    break;
            }
            if( ei==ElementList.end()) {
                std::cout<<"error: component "<< destID<<" doesn't exist!\n";
                exit(-1);
            } else
                pDestComponent= (CComponent*)(*ei);
        }

        //connect this two components
        pSourceComponent->LinkPortToPort(pSourceComponent->m_Port[sourcePort],
                                         pBond,pDestComponent->m_Port[destPort]);
    }

}


/*!
 *  \brief Insert an CComponent into a Beagle output stream.
 *  \param ioOS Output stream to write the object into.
 *  \throw  Beagle::CComponentException If the method is not overdefined in a subclass.
 */
void CBondGraph::write(ostream& ioOS) {
    std::list<CComponent*>::iterator ei;//element list
    std::list<CBond*>::iterator bk;
    std::list<CJunction*>::iterator jk;


    ioOS<<ElementList.size()<<"\t";
    ioOS<<JunctionList.size()<<"\t";
    ioOS<<BondList.size()<<"\n";


    for(ei = ElementList.begin(); ei!= ElementList.end();ei++) {
        (*ei)->write(ioOS);
    }

    for(jk = JunctionList.begin(); jk!= JunctionList.end();jk++) {
        (*jk)->write(ioOS);
    }

    for(bk = BondList.begin(); bk!= BondList.end();bk++) {
        (*bk)->write(ioOS);
    }
}

//function remove an 1 port element from a bond graph 03/26/2004 Jianjun Hu
//input: an element to be removed along with its connected bond
//return: none
void CBondGraph::removeElement1Port(CComponent* pElement) {
    if(pElement->m_PortNum !=1)
        return; //we only deal with one-port component here
    std::list<CComponent*>::iterator ei;//element list
    std::list<CBond*>::iterator bk;
    std::list<CJunction*>::iterator jk;

    CBond* pBond = pElement->m_Port[0].m_pBond;
    CPort* pAttachPort= (pBond->m_pFromPort ==  &pElement->m_Port[0])
                        ? pBond->m_pToPort:pBond->m_pFromPort;
    //remove the bond and element
    for(ei = ElementList.begin(); ei!= ElementList.end();ei++) {
        if((*ei)==pElement) {
            ElementList.erase(ei);
            break;
        }
    }
    for(bk = BondList.begin(); bk!= BondList.end();bk++) {
        if((*bk)==pBond) {
            BondList.erase(bk);
            break;
        }
    }

    //reorganize the ports of the component that the victim element is
    //attached to.This can be done by relocate all the ports that are higher
    //than the victim port
    CComponent* pComponent = pAttachPort->m_pComponent;
    unsigned int nPorts = pComponent->m_PortNum;

    //std::cout<< "*******"<<nPorts<<"\n";

    int pos=0;
    for(int i=0;i<nPorts;i++) {
        if(& (pComponent->m_Port[i])==pAttachPort) {
            pos=i;
            break;
        }
    }

    if(pos!=nPorts-1) {
        for(int i=pos;i<nPorts-1;i++) {
            pComponent->m_Port[i]=pComponent->m_Port[i+1];
        }
    } else {
        pComponent->m_Port[nPorts-1].m_pBond=NULL;
    }
    pComponent->m_PortNum -=1;
}


