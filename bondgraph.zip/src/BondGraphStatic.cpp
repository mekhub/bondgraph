/*  Bondgraph Modeling System, version 1.0, 11 Jan 2001
 *  Copyright (C) 2001  Michigan State University
 * 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of version 2 of the GNU General Public License as
 *  published by the Free Software Foundation.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *  
 *  Jianjun Hu            (hujianju@msu.edu)
 *  
 *  Computer Science Department
 *  EB 2340 GARAGe Group
 *  Michigan State University
 *  East Lansing, Michigan  48824
 *  USA
 *  
 */

/* BondGraphStatic.cpp: implementation of the CBondGraphStatic class.
 
 
//  Causality OK					1/1/2001
//	State EQU  J Matrix				1/4/2001
//	TF&GY operator					1/6/2001
//	ADF								1/8/2001
//	Drawing of BondGraph			1/20/2001
////////////////////////////////////////////////////////////////////*/

#include "bondgraph/BondGraphStatic.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CBondGraphStatic::CBondGraphStatic() {
    MaxID = -1;
    MaxBondID=-1;
    MaxComponentID=-1;

    CurrBondID=0;// current BondID --> current Max Array subscript of Bond array
    CurrCapacitorID=0;
    CurrInductorID=0;
    CurrResistorID=0;
    CurrSEID=0;
    CurrSFID=0;
    CurrGYID=0;
    CurrTFID=0;
    CurrJ0ID=0;
    CurrJ1ID=0;

}

CBondGraphStatic::~CBondGraphStatic() {
    Clean();// clean the dynamic component

}

void CBondGraphStatic::Clean() {
    //*********************************************************

    CleanVisitedLabel();

    JunctionList.clear();
    BondList.clear();
    ElementList.clear();	//Clear the content of dynamic component list evolved by the last individual program of GP

    list<CComponent*>::iterator ek;//element list
    for(ek = DynamicComponentList.begin();ek!=DynamicComponentList.end();ek++)
        delete (*ek);
    DynamicComponentList.clear();

    list<CComponentPos*>::iterator pk;//element list
    if(!DeletedStaticComponentList.empty()) {
        for(pk = DeletedStaticComponentList.begin();pk!=DeletedStaticComponentList.end();pk++)
            delete (*pk); //memory leak bug here! we must release the memory!!!
    }

    DeletedStaticComponentList.clear();

    //clear the causality marks
    ClearCausality();
    //	printf("clean the bondgraph)


    MaxID = -1;
    MaxBondID=-1;
    MaxComponentID=-1;

    CurrBondID=0;// current BondID --> current Max Array subscript of Bond array
    CurrCapacitorID=0;
    CurrInductorID=0;
    CurrResistorID=0;
    CurrSEID=0;
    CurrSFID=0;
    CurrGYID=0;
    CurrTFID=0;
    CurrJ0ID=0;
    CurrJ1ID=0;
    m_CausalityStatus = 1;
    m_PowerDirectStatus = 1;


}

CComponent* CBondGraphStatic::GetNewComponent(int Type) {
    CComponent* pCompo;
    int pos;  //position in backup list (deleted list)

    //general method
    //first currentID in boundary, then just use the next one (most often)
    //else if there are some in the deleted back list, use this backup one(few)
    //else dynamic new one(seldom)

    switch(Type) {
    case SE: {

            if(CurrSEID<MAX_SE) {//in the static array sourceEffort, use static one instead
                pCompo = &(SourceEffortBase[CurrSEID]);
                ((CSourceEffort*)pCompo)->Reset();
                CurrSEID++;
            } else {//CurrentID reach bound, use the backup or new one
                pos=AvailabeIDInBackList(Type);
                if(pos!=-1) {//check if is availabe in deleted backup list (static one)
                    pCompo = &(SourceEffortBase[pos]);
                    ((CSourceEffort*)pCompo)->Reset();
                } else { //if static is used out completely, then allocate dynamically
                    pCompo = new CSourceEffort();
                    DynamicComponentList.push_back(pCompo);
                }
            }
        }
        break;
    case SF: {
            if(CurrSFID<MAX_SF) {
                pCompo = &(SourceFlowBase[CurrSFID]);
                ((CSourceFlow*)pCompo)->Reset();
                CurrSFID++;
            } else {
                pos=AvailabeIDInBackList(Type);
                if(pos!=-1) {//check if is availabe in deleted backup list (static one)
                    pCompo = &(SourceFlowBase[pos]);
                    ((CSourceFlow*)pCompo)->Reset();
                } else {
                    pCompo = new CSourceFlow();
                    DynamicComponentList.push_back(pCompo);
                }
            }
        }
        break;
    case CAPACITOR: {
            if(CurrCapacitorID<MAX_CAPACITOR) {
                pCompo = &(CapacitorBase[CurrCapacitorID]);
                ((CCapacitor*)pCompo)->Reset();
                CurrCapacitorID++;
            } else {
                pos=AvailabeIDInBackList(Type);
                if(pos!=-1) {//check if is availabe in deleted backup list (static one)
                    pCompo = &(CapacitorBase[pos]);
                    ((CCapacitor*)pCompo)->Reset();
                } else {
                    pCompo = new CCapacitor();
                    DynamicComponentList.push_back(pCompo);
                }
            }
        }
        break;
    case INDUCTOR: {
            if(CurrInductorID<MAX_INDUCTOR) {//run out of static array sourceEffort, use dynamic one instead
                pCompo = &(InductorBase[CurrInductorID]);
                ((CInductor*)pCompo)->Reset();
                CurrInductorID++;
            } else {
                pos=AvailabeIDInBackList(Type);
                if(pos!=-1) {//check if is availabe in deleted backup list (static one)
                    pCompo = &(InductorBase[pos]);
                    ((CInductor*)pCompo)->Reset();
                } else {
                    pCompo = new CInductor();
                    DynamicComponentList.push_back(pCompo);
                }
            }
        }
        break;
    case RESISTOR: {
            if(CurrResistorID<MAX_RESISTOR) {//run out of static array sourceEffort, use dynamic one instead
                pCompo = &(ResistorBase[CurrResistorID]);
                ((CResistor*)pCompo)->Reset();
                CurrResistorID++;
            } else {
                pos=AvailabeIDInBackList(Type);
                if(pos!=-1) {//check if is availabe in deleted backup list (static one)
                    pCompo = &(ResistorBase[pos]);
                    ((CResistor*)pCompo)->Reset();
                } else {
                    pCompo = new CResistor();
                    DynamicComponentList.push_back(pCompo);
                }
            }
        }
        break;
    case TF: {
            if(CurrTFID<MAX_TF) {//run out of static array sourceEffort, use dynamic one instead
                pCompo = &(TransformerBase[CurrTFID]);
                ((CTransformer*)pCompo)->Reset();
                CurrTFID++;
            } else {
                pos=AvailabeIDInBackList(Type);
                if(pos!=-1) {//check if is availabe in deleted backup list (static one)
                    pCompo = &(TransformerBase[pos]);
                    ((CTransformer*)pCompo)->Reset();
                } else {
                    pCompo = new CTransformer();
                    DynamicComponentList.push_back(pCompo);
                }
            }
        }
        break;
    case GY: {
            if(CurrGYID<MAX_GY) {//run out of static array sourceEffort, use dynamic one instead
                pCompo = &(GyrateBase[CurrGYID]);
                ((CGyrate*)pCompo)->Reset();
                CurrGYID++;
            } else {
                pos=AvailabeIDInBackList(Type);
                if(pos!=-1) {//check if is availabe in deleted backup list (static one)
                    pCompo = &(GyrateBase[pos]);
                    ((CGyrate*)pCompo)->Reset();
                } else {
                    pCompo = new CGyrate();
                    DynamicComponentList.push_back(pCompo);
                }
            }
        }
        break;
    case JUNCTION0: {
            if(CurrJ0ID<MAX_J0) {//run out of static array sourceEffort, use dynamic one instead
                pCompo = &(Junction0Base[CurrJ0ID]);
                ((CJunction0*)pCompo)->Reset();
                CurrJ0ID++;
            } else {
                pos=AvailabeIDInBackList(Type);
                if(pos!=-1) {//check if is availabe in deleted backup list (static one)
                    pCompo = &(Junction0Base[pos]);
                    ((CJunction0*)pCompo)->Reset();
                } else {
                    pCompo = new CJunction0();
                    DynamicComponentList.push_back(pCompo);
                }
            }
        }
        break;
    case JUNCTION1: {
            if(CurrJ1ID<MAX_J1) {//run out of static array sourceEffort, use dynamic one instead
                pCompo = &(Junction1Base[CurrJ1ID]);
                ((CJunction1*)pCompo)->Reset();
                CurrJ1ID++;
            } else {
                pos=AvailabeIDInBackList(Type);
                if(pos!=-1) {//check if is availabe in deleted backup list (static one)
                    pCompo = &(Junction1Base[pos]);
                    ((CJunction1*)pCompo)->Reset();
                } else {
                    pCompo = new CJunction1();
                    DynamicComponentList.push_back(pCompo);
                }
            }
        }
        break;
    case BOND: {
            if(CurrBondID<MAX_BOND) {//run out of static array sourceEffort, use dynamic one instead
                pCompo = &(BondBase[CurrBondID]);
                ((CBond*)pCompo)->Reset();
                CurrBondID++;
            } else {
                pos=AvailabeIDInBackList(Type);
                if(pos!=-1) {//check if is availabe in deleted backup list (static one)
                    pCompo = &(BondBase[pos]);
                    ((CBond*)pCompo)->Reset();
                } else {
                    pCompo = new CBond();
                    DynamicComponentList.push_back(pCompo);
                }
            }
        }
        break;
    default:
        pCompo=NULL;
    }


    return pCompo;

}

int CBondGraphStatic::AvailabeIDInBackList(int Type) {
    int pos;
    list<CComponentPos*>::iterator k;


    if(DeletedStaticComponentList.size()<0) {
        pos = -1;
    } else {
        for(k = DeletedStaticComponentList.begin(); k!=DeletedStaticComponentList.end();k++) {
            if((*k)->Type == Type) {//find one, then return
                pos = (*k)->Pos;
                return pos;
            }
        }
        //not find, then report -1
        pos = -1;
    }
    return pos;
}

// Function name	:
//CBondGraphStatic::DeleteComponent
// Description	    :
// Return type		:
// Argument         : Type

void CBondGraphStatic::DeleteComponent(int Type, int pos) {
    CComponentPos* newComponentID = new CComponentPos();
    newComponentID->Type = Type;
    newComponentID->Pos = pos;
    DeletedStaticComponentList.push_back(newComponentID);
}

int CBondGraphStatic::FindComponentPos(CComponent *pComp) {

    int i;
    switch(pComp->m_Type) {
    case SE: {
            for(i=0;i<MAX_SE;i++) {
                if(&SourceEffortBase[i] == pComp)
                    return i;
            }
        }
        break;
    case SF: {
            for(i=0;i<MAX_SF;i++) {
                if(&SourceFlowBase[i] == pComp)
                    return i;
            }

        }
        break;
    case CAPACITOR: {
            for(i=0;i<MAX_CAPACITOR;i++) {
                if(&CapacitorBase[i] == pComp)
                    return i;
            }
        }
        break;
    case INDUCTOR: {
            for(i=0;i<MAX_INDUCTOR;i++) {
                if(&InductorBase[i] == pComp)
                    return i;
            }
        }
        break;
    case RESISTOR: {
            for(i=0;i<MAX_RESISTOR;i++) {
                if(&ResistorBase[i] == pComp)
                    return i;
            }
        }
        break;
    case TF: {
            for(i=0;i<MAX_TF;i++) {
                if(&TransformerBase[i] == pComp)
                    return i;
            }
        }
        break;
    case GY: {
            for(i=0;i<MAX_GY;i++) {
                if(&GyrateBase[i] == pComp)
                    return i;
            }
        }
        break;
    case JUNCTION0: {
            for(i=0;i<MAX_J0;i++) {
                if(&Junction0Base[i] == pComp)
                    return i;
            }
        }
        break;
    case JUNCTION1: {
            for(i=0;i<MAX_J1;i++) {
                if(&Junction1Base[i] == pComp)
                    return i;
            }
        }
        break;
    case BOND: {
            for(i=0;i<MAX_BOND;i++) {
                if(&BondBase[i] == pComp)
                    return i;
            }
        }
        break;
    }

    return -1;

}

int CBondGraphStatic::DeleteComponent(CComponent *pCom) {

    //delete the component from the current bondgraph data structure
    list<CJunction*>::iterator jk;//define the iterator of list
    list<CBond*>::iterator bk;
    list<CComponent*>::iterator ek;//element list
    switch( pCom->m_Type ) {
    case JUNCTION0:
    case JUNCTION1:
        for(jk = JunctionList.begin(); jk!= JunctionList.end();jk++) {
            if ( (*jk)->m_No == pCom->m_No ) {
                JunctionList.erase( jk-- );
            }
        }
        break;
    case BOND:
        for(bk = BondList.begin(); bk!= BondList.end();bk++) {
            if ( (*bk)->m_No == pCom->m_No) {
                BondList.erase( bk-- );
            }
        }
        break;
    case INDUCTOR:
    case CAPACITOR:
    case RESISTOR:
    case SE:
    case SF:
    case TF:
    case GY:
        for(ek = ElementList.begin(); ek!= ElementList.end();ek++) {
            if ( (*ek)->m_No == pCom->m_No) {
                ElementList.erase( ek-- );
            }

        }
        break;
    }


    //release the memory of this component!
    int pos = FindComponentPos(pCom);
    if(pos !=-1) {//for static memory allocation, just register it as available for reuse
        pCom->Reset();
        DeleteComponent(pCom->m_Type,pos);
    } else {//not found, then this is a dynamic component
        delete pCom;
    }

    return 0;
}

//HJJ   10-16-2001
void CBondGraphStatic::Simplify(int option) {
    //return;

    list<CJunction*>::iterator jk, jk1, jk2, jk3;//define the iterator of vector
    list<CBond*>::iterator bk;
    list<CComponent*>::iterator ek;//element vector
    vector<CJunction*> JunctionRemovevector;



    CComponent* pComp1, *pComp2;
    //Rule 1. eliminate the empty junctions(with only two ports)
    for(jk = JunctionList.begin(); jk!= JunctionList.end();jk++) {

        if((*jk)->m_Port[0].m_pBond->m_pFromPort ==	&(*jk)->m_Port[0])
            pComp1= (*jk)->m_Port[0].m_pBond->m_pToPort->m_pComponent;
        else
            pComp1= (*jk)->m_Port[0].m_pBond->m_pFromPort->m_pComponent;

        if((*jk)->m_Port[1].m_pBond->m_pFromPort ==	&(*jk)->m_Port[1])
            pComp2= (*jk)->m_Port[1].m_pBond->m_pToPort->m_pComponent;
        else
            pComp2= (*jk)->m_Port[1].m_pBond->m_pFromPort->m_pComponent;


        int bCompressible=0;
        if(pComp1->m_PortNum==1) {
            if(pComp2->m_Type == (*jk)->m_Type)
                bCompressible =1;
        } else if(pComp2->m_PortNum==1) {
            if(pComp1->m_Type == (*jk)->m_Type)
                bCompressible =1;
        }
        bCompressible =0;

        if((pComp1->m_Type  ==JUNCTION0 ||pComp1->m_Type==JUNCTION1)&&
                (pComp2->m_Type==JUNCTION0 ||pComp2->m_Type==JUNCTION1)) //between two junction
            bCompressible = 1;

        if ( (*jk)->m_PortNum == 2 && bCompressible==1) {

            if(option ==SIMPLIFY_KEEP_EMBRYO && (*jk)->m_WriteNo ==0)
                continue;//we keep the embryo element untact

            CJunction* pJ = (CJunction*)(*jk);
            //now process 2 port junctions
            CBond*& pFromBond = (*jk)->m_Port[0].m_pBond;
            CBond*& pToBond = (*jk)->m_Port[1].m_pBond;
            CPort*& pLeftPort = (pFromBond->m_pFromPort==&(*jk)->m_Port[0])?
                                pFromBond->m_pFromPort:pFromBond->m_pToPort;
            CPort*& pRightPort = (pToBond->m_pFromPort==&(*jk)->m_Port[1])?
                                 pToBond->m_pToPort:pToBond->m_pFromPort;

            pLeftPort = pRightPort;
            pRightPort->m_pBond = pFromBond;
            DeleteComponent(pToBond);
            DeleteComponent((*jk--));
        }
    }
    //10-16-3:00 works OK the eigenvalue is also the same!

    if( option == SIMPLIFY_EXTRA_JUNCTION)
        return;
    //***************************************************************
    //Report(BONDGRAPH_PARAM); //HJJM
    //Rule2.
    if(option ==SIMPLIFY_KEEP_EMBRYO) {
        for(jk = JunctionList.begin(); jk!= JunctionList.end();jk++) {
            if((*jk)->m_WriteNo==-1)
                (*jk)->m_bVisited=true;
        }
    }

    CJunction* pJ=NULL;
    CleanVisitedLabel();

    while((pJ = GetNextUnvisitedJunction())!=NULL) {

        CJunction* pNewJunction=NULL;

        //printf("junction %d\n", pJ->m_No);
        list<CJunction*> AggregateJunctions;

        pJ->m_bVisited=true;
        int originJunctionNo = pJ->m_No;
        pJ->FindNeighborJuctions(option, pJ->m_Type,AggregateJunctions);
        AggregateJunctions.push_back(pJ);//add the starting point also!


        if(!AggregateJunctions.empty()) {
            //now collapse all the nodes
            vector<double> Resistors, Inductors, Capacitors;
            list<CJunction*>::iterator jk2;//define the iterator of list
            CBond* pBondTo;
            CComponent* pCompConnected;

            //even for junctions which don't have neighbor junctions of the same type, we
            //need to create a new junction, since we will change the No. of ports of the
            //current junction if we combine several C/I/R

            //create a new junction
            if(pJ->m_Type == JUNCTION0)
                pNewJunction = (CJunction0*)GetNewComponent(JUNCTION0);
            else
                pNewJunction = (CJunction1*)GetNewComponent(JUNCTION1);

            pNewJunction->m_bVisited=true;
            JunctionList.push_back(pNewJunction);


            int resistorNo = 0;  //the remaining No. of compressed resistors
            int capacitorNo = 0;
            int inductorNo = 0;

            for(jk2 = AggregateJunctions.begin(); jk2!= AggregateJunctions.end();jk2++) {
                CJunction* pJCollapse = (CJunction*) (*jk2);
                int k;
                for(k=0;k<(pJCollapse)->m_PortNum;k++) { //for each port of this junction
                    CPort* pComponentPort;//port of the bond pointing to component

                    if(pJCollapse->m_Port[k].m_pBond==NULL)
                        continue;

                    if((pJCollapse)->m_Port[k].m_pBond->m_pFromPort
                            ==&(pJCollapse)->m_Port[k]) {
                        pComponentPort= (pJCollapse)->m_Port[k].m_pBond->m_pToPort;
                    } else {
                        pComponentPort=(pJCollapse)->m_Port[k].m_pBond->m_pFromPort;
                    }

                    pCompConnected = pComponentPort->m_pComponent;
                    pBondTo = (pJCollapse)->m_Port[k].m_pBond;

                    //for I/R/C we delete all of them only keep the value of elements
                    if(pCompConnected->m_Type == RESISTOR ||pCompConnected->m_Type==CAPACITOR||
                            pCompConnected->m_Type== INDUCTOR) {

                        switch(pCompConnected->m_Type) {
                        case RESISTOR:
                            Resistors.push_back(pCompConnected->m_ParamValue);
                            resistorNo = pCompConnected->m_No;
                            break;
                        case CAPACITOR:
                            Capacitors.push_back(pCompConnected->m_ParamValue);
                            capacitorNo = pCompConnected->m_No;
                            break;
                        case INDUCTOR:
                            Inductors.push_back(pCompConnected->m_ParamValue);
                            inductorNo = pCompConnected->m_No;
                            break;
                        }
                        //delete the component and the bond
                        DeleteComponent(pCompConnected);
                        DeleteComponent(pBondTo);
                        (pJCollapse)->m_Port[k].m_pBond = NULL;
                    } else if(pCompConnected->m_Type == pJ->m_Type ) {

                        if(option==0 ||(option==1 && pCompConnected->m_WriteNo!=-1)) {
                            //for junction of the same type, then delete the bond between
                            if(pBondTo != NULL) {
                                if((pJCollapse)->m_Port[k].m_pBond->m_pFromPort
                                        ==&(pJCollapse)->m_Port[k]) {
                                    (pJCollapse)->m_Port[k].m_pBond->m_pToPort->m_pBond = NULL;
                                } else {
                                    (pJCollapse)->m_Port[k].m_pBond->m_pFromPort->m_pBond = NULL;
                                }
                                (pJCollapse)->m_Port[k].m_pBond = NULL;
                                DeleteComponent(pBondTo);
                            }
                        }
                    } else {
                        //for all other components, we have to point them to the new junction
                        int currentPort = pNewJunction->AddPortNum(1)-1;
                        CJunction *pjj = (CJunction *)(pJCollapse);

                        CPort pp = (pJCollapse)->m_Port[k];

                        if((pJCollapse)->m_Port[k].m_pBond->m_pFromPort
                                ==&(pJCollapse)->m_Port[k]) {

                            (pJCollapse)->m_Port[k].m_pBond->m_pFromPort = &(pNewJunction->m_Port[currentPort]);
                            pNewJunction->m_Port[currentPort].m_pBond = (pJCollapse)->m_Port[k].m_pBond;
                            pNewJunction->m_Port[currentPort].SetPowerDirect((pJCollapse)->m_Port[k].GetPowerDirect());

                        } else {
                            pJCollapse->m_Port[k].m_pBond->m_pToPort=& (pNewJunction->m_Port[currentPort]);
                            pNewJunction->m_Port[currentPort].m_pBond = (pJCollapse)->m_Port[k].m_pBond;
                            pNewJunction->m_Port[currentPort].SetPowerDirect((pJCollapse)->m_Port[k].GetPowerDirect());
                        }
                        (pJCollapse)->m_Port[k].m_pBond = NULL;

                    }
                }//end each port
            }//end neighbor junctions

            //delete the collapsed junctions
            for(jk2 = AggregateJunctions.begin(); jk2!= AggregateJunctions.end();jk2++) {
                //now delete all the old junctions
                DeleteComponent((* jk2));
                //printf("    junction %d collapsed\n", (*jk2)->m_No);
            }

            AggregateJunctions.clear();

            //create the attached I/R/C
            CInductor* pI;
            CCapacitor* pC;
            CResistor* pR;
            CBond* pB;
            int currentPort;
            if(!Capacitors.empty()) {
                pC = (CCapacitor*)GetNewComponent(CAPACITOR);
                pC->SetNo(capacitorNo);
                pC->m_Port[0].SetPowerDirect(IN);//set the power direction
                //that is pointing to the capacitor

                ElementList.push_back(pC);
                if(pJ->m_Type == JUNCTION0) {
                    for(int ic=0;ic<Capacitors.size();ic++)
                        pC->m_ParamValue += Capacitors[ic];
                } else {
                    for(int ic=0;ic<Capacitors.size();ic++)
                        pC->m_ParamValue += 1/Capacitors[ic];
                    pC->m_ParamValue = 1/pC->m_ParamValue;
                }
                currentPort = pNewJunction->AddPortNum(1)-1;
                pB= (CBond*) GetNewComponent(BOND);
                pB->SetNo(GetNewID(BOND));  // set the identity no
                BondList.push_back(pB);
                pC->LinkPortToPort(pNewJunction->m_Port[currentPort],pB,pC->m_Port[0] );
            }

            if(!Resistors.empty()) {
                pR = (CResistor*)GetNewComponent(RESISTOR);
                pR->SetNo(resistorNo);
                pR->m_Port[0].SetPowerDirect(IN);//set the power direction
                ElementList.push_back(pR);
                if(pJ->m_Type == JUNCTION1) {
                    for(int ir=0;ir<Resistors.size();ir++)
                        pR->m_ParamValue += Resistors[ir];
                } else {
                    for(int ic=0;ic<Resistors.size();ic++)
                        pR->m_ParamValue += 1/Resistors[ic];
                    pR->m_ParamValue = 1/pR->m_ParamValue;
                }
                currentPort = pNewJunction->AddPortNum(1)-1;
                pB= (CBond*) GetNewComponent(BOND);
                pB->SetNo(GetNewID(BOND));  // set the identity no
                BondList.push_back(pB);
                pR->LinkPortToPort(pNewJunction->m_Port[currentPort],pB,pR->m_Port[0] );
            }

            if(!Inductors.empty()) {
                pI = (CInductor*)GetNewComponent(INDUCTOR);
                pI->SetNo(inductorNo);
                pI->m_Port[0].SetPowerDirect(IN);//set the power direction
                ElementList.push_back(pI);
                if(pJ->m_Type == JUNCTION1) {
                    for(int ii=0;ii<Inductors.size();ii++)
                        pI->m_ParamValue += Inductors[ii];
                } else {
                    for(int ic=0;ic<Inductors.size();ic++)
                        pI->m_ParamValue += 1/Inductors[ic];
                    pI->m_ParamValue = 1/pI->m_ParamValue;
                }
                currentPort = pNewJunction->AddPortNum(1)-1;
                pB= (CBond*) GetNewComponent(BOND);
                pB->SetNo(GetNewID(BOND));  // set the identity no
                BondList.push_back(pB);
                pI->LinkPortToPort(pNewJunction->m_Port[currentPort],pB,pI->m_Port[0] );
            }
        }//find something to collaps

        pNewJunction->SetNo(originJunctionNo);  // set the identity no

    }//bigloop of rule 2, 3
	
	//printf("============after simplification\n");
    //
	//Report(BONDGRAPH_PARAM); //HJJM
}


//used for simplification, get the next unsimplified/unvisited junctions
CJunction* CBondGraphStatic::GetNextUnvisitedJunction() {
    list<CJunction*>::iterator jk;
    for(jk = JunctionList.begin(); jk!= JunctionList.end();jk++) {
        if((*jk)->m_bVisited==false) {
            return (*jk);
        }
    }
    return NULL;
}




/*!
 *  \brief Extract Object from a  input stream.
 *  \param ioIS Input stream to read the object from.
 */
void CBondGraphStatic::read(std::istream& ioIS) {
    int nElements;
    int nJunctions;
    int nBonds;
    int componentType;
    CComponent* newElement;

    ioIS>>nElements;
    ioIS>>nJunctions;
    ioIS>>nBonds;
    for(int i=0;i<nElements;i++) {
        ioIS>>componentType;
        //switch (componentType){  //Algorithm update
        //	case SE:  newElement =new CSourceEffort(); ElementList.push_back(newElement);break;
        //	case SF:  newElement = new CSourceFlow(); ElementList.push_back(newElement);break;
        //	case CAPACITOR:  newElement = new CCapacitor(); ElementList.push_back(newElement);break;
        //	case INDUCTOR:  newElement = new CInductor(); ElementList.push_back(newElement);break;
        //	case RESISTOR:  newElement = new CResistor(); ElementList.push_back(newElement);break;
        //	case TF:  newElement = new CTransformer(); ElementList.push_back(newElement);break;
        //	case GY:  newElement = new CGyrate(); ElementList.push_back(newElement);break;
        //}
        newElement =GetNewComponent(componentType);
        ElementList.push_back(newElement);

        newElement->read(ioIS);
        for(int k=0;k<newElement->m_PortNum;k++)
            newElement->m_Port[k].m_pComponent=newElement;
    }

    for(int i=0;i<nJunctions;i++) {
        ioIS>>componentType;
        //if(componentType==JUNCTION0){
        //	newElement =new CJunction0(); JunctionList.push_back((CJunction0*)newElement);
        //}
        //else{
        //	newElement =new CJunction1(); JunctionList.push_back((CJunction1*)newElement);
        //}
        newElement =GetNewComponent(componentType);
        JunctionList.push_back((CJunction0*)newElement);

        newElement->read(ioIS);
        for(int k=0;k<newElement->m_PortNum;k++)
            newElement->m_Port[k].m_pComponent=newElement;
    }

    std::list<CComponent*>::iterator ei;//element list
    std::list<CBond*>::iterator bk;
    std::list<CJunction*>::iterator jk;

    int sourceType, sourceID, sourcePort;
    int destType, destID, destPort;
    CComponent* pSourceComponent, *pDestComponent;

    for(int i=0;i<nBonds;i++) {
        CBond* pBond = (CBond*)GetNewComponent(BOND);
        BondList.push_back(pBond);
        ioIS>>pBond->m_Type;
        ioIS>>pBond->m_Name;
        ioIS>>pBond->m_No;
        ioIS>>pBond->m_WriteNo;
        ioIS>>pBond->m_PortNum;

        ioIS>>sourceType;
        ioIS>>sourceID;
        ioIS>>sourcePort;

        ioIS>>destType;
        ioIS>>destID;
        ioIS>>destPort;
        //check if the from element exist.
        if(sourceType==JUNCTION0 ||sourceType==JUNCTION1) {
            //search in junction list
            for(jk = JunctionList.begin(); jk!= JunctionList.end();jk++) {
                if( (*jk)->m_No == sourceID)
                    break;
            }
            if( jk==JunctionList.end()) {
                std::cout<<"error: junction "<< sourceID<<" doesn't exist!\n";
                exit(-1);
            } else
                pSourceComponent= (*jk);
        } else {
            //search in element list
            for(ei = ElementList.begin(); ei!= ElementList.end();ei++) {
                if( (*ei)->m_No == sourceID)
                    break;
            }
            if( ei==ElementList.end()) {
                std::cout<<"error: component "<< sourceID<<" doesn't exist!\n";
                exit(-1);
            } else
                pSourceComponent= (*ei);
        }

        //check if the to element exists.
        if(destType==JUNCTION0 ||destType==JUNCTION1) {
            //search in junction list
            for(jk = JunctionList.begin(); jk!= JunctionList.end();jk++) {
                if( (*jk)->m_No == destID)
                    break;
            }
            if( jk==JunctionList.end()) {
                std::cout<<"error: junction "<< destID<<" doesn't exist!\n";
                exit(-1);
            } else
                pDestComponent= (*jk);
        } else {
            //search in junction list
            for(ei = ElementList.begin(); ei!= ElementList.end();ei++) {
                if( (*ei)->m_No == destID)
                    break;
            }
            if( ei==ElementList.end()) {
                std::cout<<"error: component "<< destID<<" doesn't exist!\n";
                exit(-1);
            } else
                pDestComponent= (CComponent*)(*ei);
        }

        //connect this two components
        pSourceComponent->LinkPortToPort(pSourceComponent->m_Port[sourcePort],
                                         pBond,pDestComponent->m_Port[destPort]);
    }

}


/*!
 *  \brief Insert an CComponent into a Beagle output stream.
 *  \param ioOS Output stream to write the object into.
 *  \throw  Beagle::CComponentException If the method is not overdefined in a subclass.
 */
void CBondGraphStatic::write(ostream& ioOS) {
    std::list<CComponent*>::iterator ei;//element list
    std::list<CBond*>::iterator bk;
    std::list<CJunction*>::iterator jk;
    int in=0 ;

    ioOS<<ElementList.size()<<"\t";
    ioOS<<JunctionList.size()<<"\t";
    ioOS<<BondList.size()<<"\n";


    for(ei = ElementList.begin(); ei!= ElementList.end();ei++) {
        (*ei)->write(ioOS);
    }

    for(jk = JunctionList.begin(); jk!= JunctionList.end();jk++) {
        (*jk)->write(ioOS);
    }

    for(bk = BondList.begin(); bk!= BondList.end();bk++) {
        (*bk)->write(ioOS);
    }
}




