/*  Bondgraph Modeling System, version 1.0, 11 Jan 2001
 *  Copyright (C) 2001  Michigan State University
 * 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of version 2 of the GNU General Public License as
 *  published by the Free Software Foundation.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *  
 *  Jianjun Hu            (hujianju@msu.edu)
 *  
 *  Computer Science Department
 *  EB 2340 GARAGe Group
 *  Michigan State University
 *  East Lansing, Michigan  48824
 *  USA
 *  
 */

// Component.cpp: implementation of the CComponent class.

//

//////////////////////////////////////////////////////////////////////



#include "bondgraph/StdAfx.h"

#include "bondgraph/Component.h"

#include "bondgraph/Bond.h"
#include <sstream>



//////////////////////////////////////////////////////////////////////

// Construction/Destruction

//////////////////////////////////////////////////////////////////////



CComponent::CComponent()
{
    m_Depth = -1;
    m_Name = "";
    m_bVisited = false;
    m_WriteNo=-1;
}



CComponent::~CComponent()
{


}





//////////////////////////////////////////////////////////////////////

//Function  LinkPortToPort

//will use a new Bond and connect the Linking Port of this component

//to the port to be linked(LinkedPort)

//

//Condition:  You must have correctly set the portnum of junction,

//   Result:  set up the link relationship between two port connected by a bond

//////////////////////////////////////////////////////////////////////



//HJJ Attention!
//Default powerdirection condition:
//Energy must flow from the FromPort to ToPort
//for special case:  I, R, C, which only consume energy
//					 SE, SF   which only output energy
//the function can automatically adjust the FromPort and ToPort, so the
//parameter don't matter much
//but for connection of two junction, the FromPort must be the energy source junction
// the ToPort must be energy absorber junction, else the routine will make mistakes
// without letting you know!!!

void CComponent::LinkPortToPort(CPort& FromPort,CBond*pBond, CPort&  ToPort)
{
    ToPort.m_pBond = pBond;
    FromPort.m_pBond = pBond;
    pBond->m_pFromPort = &FromPort;
    pBond->m_pToPort = &ToPort;

    //Some definite case check
    if(FromPort.m_pComponent->m_Type== RESISTOR ||
            FromPort.m_pComponent->m_Type== CAPACITOR ||
            FromPort.m_pComponent->m_Type== INDUCTOR) {
        //make sure power only flow from others to  I/R/C
        pBond->m_pFromPort = &ToPort;
        pBond->m_pToPort = &FromPort;
    }
    //HJJM need to be confirmed!!
    /*		else if(ToPort.m_pComponent->m_Type== SE||
    			ToPort.m_pComponent->m_Type== SF){
    			pBond->m_pFromPort = &ToPort;
    			pBond->m_pToPort = &FromPort;
    		}
    */
    pBond->m_pFromPort->SetPowerDirect(OUT);
    pBond->m_pToPort->SetPowerDirect(IN);

}




void CComponent::SetNo(int ID)
{

    m_No = ID;



}



void CComponent::SetParamValue(double value)
{

    m_ParamValue = value;



}



int CComponent::SetCausalMark(int Type, CPort* pPort)
{
    return 0;
}


//initialize the component
void CComponent::Reset() {
    m_Depth = -1;
    m_bVisited = false;
    m_No =0;
    m_ParamValue = 0.0;
    m_PortNum = 0;
    m_WriteNo = -1;
}

int CComponent::SetPowerDirect(int direction, CPort *pPort) {
    return 0;

}


/*!
 *  \brief Extract Object from a  input stream.
 *  \param ioIS Input stream to read the object from.
 */
void CComponent::read(std::istream& ioIS) {
    std::cout<<"error: CComponent serialization not defined!\n";
}


/*!
 *  \brief Transform an CComponent into a linear string (using write method).
 *  \return String representing the CComponent.
 */
std::string CComponent::serialize() const {
    std::ostringstream lStringOS;
    write(lStringOS);
    return lStringOS.str();
}


/*!
 *  \brief Insert an CComponent into a Beagle output stream.
 *  \param ioOS Output stream to write the object into.
 *  \throw  Beagle::CComponentException If the method is not overdefined in a subclass.
 */
void CComponent::write(ostream& ioOS) const {
    std::cout<<"error: CComponent write method not defined!\n";
}


/*!
 *  \brief  Extract Object from standard C++ input stream.
 *  \param  ioIS      Standard C++ input stream.
 *  \param  outObject Object read from the stream.
 *  \return Reference to the C++ input stream.
 *  \throw  Beagle::IOException If format is invalid.
 */
std::istream& operator>>(std::istream& ioIS, CComponent& outObject) {
    outObject.read(ioIS);
    return ioIS;
}


/*!
 *  \brief  Insert Object into standard C++ output stream.
 *  \param  ioOS      Standard C++ output stream.
 *  \param  inObject  Object written into the stream.
 *  \return Reference to the C++ output stream.
 */
std::ostream& operator<<(std::ostream& ioOS, const CComponent& inObject) {
    inObject.write(ioOS);
    return ioOS;
}





