/*  Bondgraph Modeling System, version 1.0, 11 Jan 2001
 *  Copyright (C) 2001  Michigan State University
 * 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of version 2 of the GNU General Public License as
 *  published by the Free Software Foundation.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *  
 *  Jianjun Hu            (hujianju@msu.edu)
 *  
 *  Computer Science Department
 *  EB 2340 GARAGe Group
 *  Michigan State University
 *  East Lansing, Michigan  48824
 *  USA
 *  
 */

// Element1Port.cpp: implementation of the CElement1Port class.
//
//////////////////////////////////////////////////////////////////////


#include "bondgraph/Bond.h"

#include "bondgraph/Element1Port.h"



//////////////////////////////////////////////////////////////////////

// Construction/Destruction

//////////////////////////////////////////////////////////////////////



CElement1Port::CElement1Port()
{

    m_No = 0;

    m_PortNum=1;

    m_ParamValue=0;// I, R, C, GY, TF's parameter value

    m_Port[0].m_pBond = NULL;

    m_Port[0].m_pComponent = this;

    m_WriteNo =-1;

    m_Depth = 0;//leaf node



}



CElement1Port::~CElement1Port()
{


}





//////////////////////////////////////////////////////////////////////

// LinkToJunction

// Condition:  You don't know which port number of junction your bond will link to

//             YOu just create a new port( increase a new port) and link to it

//

//////////////////////////////////////////////////////////////////////



int CElement1Port::LinkToJunction(CJunction *pJunction, CBond *bond)
{
    int i;
    i = pJunction->AddPortNum(1) - 1;//add a port, return the total portnum, the last one is m_port[totalnum -1]
    if(i+1>MAX_PORT) {
        printf("bondgraph package:CElement1Port:LinkToJunction: Exceeding Max portNo, please increase MAX_PORT=%d in stdafx.h!\n",MAX_PORT);
        return -1;
    }

    if( this->m_Type ==SE ||this->m_Type ==SF) {
        pJunction->m_Port[i].m_pBond = bond; //link J to bond
        pJunction->m_Port[i].SetPowerDirect(IN);
        this->m_Port[0].m_pBond = bond;//link C to bond
        this->m_Port[0].SetPowerDirect(OUT);
        bond->m_pFromPort = &(this->m_Port[0]);//link bond to C
        bond->m_pToPort = &(pJunction->m_Port[i]);//link bond to J
    } else {//I, R, C
        pJunction->m_Port[i].m_pBond = bond; //link J to bond
        pJunction->m_Port[i].SetPowerDirect(OUT);
        this->m_Port[0].m_pBond = bond;//link C to bond
        this->m_Port[0].SetPowerDirect(IN);
        bond->m_pFromPort =&(pJunction->m_Port[i]) ;//link bond to C
        bond->m_pToPort = &(this->m_Port[0]);//link bond to J
    }
    return 0;
}




// Function name	: CElement1Port::SetCausalMark
// Description	    :
// Return type		: int report the result:  0 ok, -1 conflict;
// Argument         : int Type, causal type: EFFORT, or FLOW
int CElement1Port::SetCausalMark(int Type, CPort* pPort) {
    if(Type==EFFORT && m_Type == CAPACITOR)
        return -1; //conflict
    else if(Type==FLOW && m_Type == INDUCTOR)
        return -1;


    if(m_Port[0].IsCausalityDefined()) {  // if causality defined, then check conflict
        if(m_Port[0].IsCausalityEqual(Type))
            return 0;
        else
            return -1;
    } else { //assign causality

        m_Port[0].SetCausalMark(Type);
        //set the other end of the bond's causality
        if(m_Port[0].m_pBond->m_pFromPort == &(m_Port[0])) {//decide which port of bond is connected to one port element
            //used to find the port at the other end of bond
            if(m_Port[0].m_pBond->m_pToPort->IsCausalityDefined()) //check conflict
            {
                if(m_Port[0].m_pBond->m_pToPort->IsCausalityEqual((Type==EFFORT)?FLOW:EFFORT))
                    return 0; //!Type
                else
                    return -1;

            } else {//other end causality not set
                m_Port[0].m_pBond->m_pToPort->SetCausalMark((Type==EFFORT)?FLOW:EFFORT);// set the other port causality
                return m_Port[0].m_pBond->m_pToPort->m_pComponent->SetCausalMark
                       ((Type==EFFORT)?FLOW:EFFORT, m_Port[0].m_pBond->m_pToPort);//derive other causality given one port nos is !Type
            }
        } else {//the Toport is connected to this element
            if(m_Port[0].m_pBond->m_pFromPort->IsCausalityDefined()) //check conflict
            {
                if(m_Port[0].m_pBond->m_pFromPort->IsCausalityEqual((Type==EFFORT)?FLOW:EFFORT))
                    return 0; //!Type
                else
                    return -1;

            } else {//other end causality not set
                m_Port[0].m_pBond->m_pFromPort->SetCausalMark((Type==EFFORT)?FLOW:EFFORT);// set the other port causality
                return m_Port[0].m_pBond->m_pFromPort->m_pComponent->SetCausalMark
                       ((Type==EFFORT)?FLOW:EFFORT, m_Port[0].m_pBond->m_pFromPort);//derive other causality given one port nos is !Type
            }
        }
    }
}


void CElement1Port::operator =(CElement1Port &el) {

    m_Port[0] = el.m_Port[0];

    m_No=el.m_No;// int
    m_Name=el.m_Name;  //
    m_Type=el.m_Type;  //
    m_ParamValue=el.m_ParamValue;
    m_PortNum=el.m_PortNum;//

}

// Maximal automatic Power direction assignment reasonging routine,
// not complete!
int CElement1Port::SetPowerDirect(int direction,  CPort* pPort) {

    if(m_Port[0].IsPowerDirectDefined()) {  // if causality defined, then check conflict
        if(m_Port[0].IsPowerDirectEqual(direction))
            return 0;
        else
            return -1;
    } else { //assign causality

        m_Port[0].SetPowerDirect(direction);
        //set the other end of the bond's causality
        if(m_Port[0].m_pBond->m_pFromPort == &(m_Port[0])) {//decide which port of bond is connected to one port element
            //used to find the port at the other end of bond
            if(m_Port[0].m_pBond->m_pToPort->IsPowerDirectDefined()) //check conflict
            {
                if(m_Port[0].m_pBond->m_pToPort->IsPowerDirectEqual((direction==IN)?OUT:IN))
                    return 0; //!direction
                else
                    return -1;

            } else {//other end causality not set
                m_Port[0].m_pBond->m_pToPort->SetPowerDirect((direction==IN)?OUT:IN);// set the other port causality
                return m_Port[0].m_pBond->m_pToPort->m_pComponent->SetPowerDirect
                       ((direction==IN)?OUT:IN, m_Port[0].m_pBond->m_pToPort);//derive other causality given one port nos is !direction
            }
        } else {//the Toport is connected to this element
            if(m_Port[0].m_pBond->m_pFromPort->IsPowerDirectDefined()) //check conflict
            {
                if(m_Port[0].m_pBond->m_pFromPort->IsPowerDirectEqual((direction==IN)?OUT:IN))
                    return 0; //!direction
                else
                    return -1;

            } else {//other end causality not set
                m_Port[0].m_pBond->m_pFromPort->SetPowerDirect((direction==IN)?OUT:IN);// set the other port causality
                return m_Port[0].m_pBond->m_pFromPort->m_pComponent->SetPowerDirect
                       ((direction==IN)?OUT:IN, m_Port[0].m_pBond->m_pFromPort);//derive other causality given one port nos is !direction
            }
        }
    }
}

void CElement1Port::Reset() {
    CComponent::Reset();
    m_No = 0;

    m_PortNum=1;

    m_ParamValue=0;// I, R, C, GY, TF's parameter value

    m_Port[0].m_pBond = NULL;

    m_Port[0].m_pComponent = this;

    m_WriteNo = -1;

    m_Depth = 0;//leaf node


}

/*!
 *  \brief Extract Object from a  input stream.
 *  \param ioIS Input stream to read the object from.
 */
void CElement1Port::read(std::istream& ioIS) {
    //Type  Name  ID portNo paramNo writeHead  paramList
    int paramNum;
    //m_Type<<ioIS;
    ioIS>>m_Name;
    ioIS>>m_No;
    ioIS>>m_WriteNo;

    ioIS>>m_PortNum;
    ioIS>>m_Port[0].m_CausalMark;
    ioIS>>m_Port[0].m_PowerDirect;

    ioIS>>paramNum;
    ioIS>>m_ParamValue;
}


/*!
 *  \brief Insert an CComponent into a Beagle output stream.
 *  \param ioOS Output stream to write the object into.
 *  \throw  Beagle::CComponentException If the method is not overdefined in a subclass.
 */
void CElement1Port::write(ostream& ioOS) const {
    ioOS<<m_Type<<"\t";
    ioOS<<m_Name<<"\t";
    ioOS<<m_No<<"\t";
    ioOS<<m_WriteNo<<"\t";

    ioOS<<1<<"\t";
    ioOS<<m_Port[0].m_CausalMark<<"\t";
    ioOS<<m_Port[0].m_PowerDirect<<"\t";

    ioOS<<1<<"\t";
    ioOS<<m_ParamValue<<"\t";
    ioOS<<"\n";
}
