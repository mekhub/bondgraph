/*  Bondgraph Modeling System, version 1.0, 11 Jan 2001
 *  Copyright (C) 2001  Michigan State University
 * 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of version 2 of the GNU General Public License as
 *  published by the Free Software Foundation.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *  
 *  Jianjun Hu            (hujianju@msu.edu)
 *  
 *  Computer Science Department
 *  EB 2340 GARAGe Group
 *  Michigan State University
 *  East Lansing, Michigan  48824
 *  USA
 *  
 */

// Element2Port.cpp: implementation of the CElement2Port class.

//

//////////////////////////////////////////////////////////////////////



#include "bondgraph/StdAfx.h"

#include "bondgraph/Element2Port.h"
#include "bondgraph/Bond.h"


//////////////////////////////////////////////////////////////////////

// Construction/Destruction

//////////////////////////////////////////////////////////////////////



CElement2Port::CElement2Port()
{

    CComponent::Reset();
    m_No = 0;

    m_PortNum=2;

    m_ParamValue=0;// I, R, C, GY, TF's parameter value

    m_Port[0].m_pBond = NULL;

    m_Port[1].m_pBond = NULL;

    m_Port[0].m_pComponent = this;

    m_Port[1].m_pComponent = this;



}



CElement2Port::~CElement2Port()
{


}


void CElement2Port::operator =(CElement2Port &el) {
    m_Port[0] = el.m_Port[0];
    m_Port[1] = el.m_Port[1];

    m_No=el.m_No;// int
    m_Name=el.m_Name;  //
    m_Type=el.m_Type;  //
    m_ParamValue=el.m_ParamValue;
    m_WriteNo=el.m_WriteNo;//
    m_PortNum=el.m_PortNum;//

}
// Maximal automatic Power direction assignment reasonging routine,
// not complete!

int CElement2Port::SetPowerDirect(int direction, CPort *pPort) {
    CPort* pNewPort;

    if(&m_Port[0]==pPort)
        pNewPort = &m_Port[1];
    else
        pNewPort = &m_Port[0];

    //check the newport is set powerdirection or not
    if(pNewPort->IsPowerDirectDefined()) { //then check conflict
        if(!pNewPort->IsPowerDirectEqual(pPort->GetPowerDirect()))
            return 0;//consistent
        else
            return -1; //conflict

    } else {//the newport is not set causality

        pNewPort->SetPowerDirect((direction==IN)?OUT:IN);//set as equal for two port of the Gyrate

        if(pNewPort->m_pBond->m_pFromPort==pNewPort)// set the port at other end of the bond
        {
            // set as opposite for the two port of the same bond
            pNewPort->m_pBond->m_pToPort->SetPowerDirect(direction);
            return pNewPort->m_pBond->m_pToPort->m_pComponent->SetPowerDirect
                   (direction, pNewPort->m_pBond->m_pToPort);
        } else {
            pNewPort->m_pBond->m_pFromPort->SetPowerDirect(direction);
            return pNewPort->m_pBond->m_pFromPort->m_pComponent->SetPowerDirect
                   (direction, pNewPort->m_pBond->m_pFromPort);
        }

    }

}

void CElement2Port::Reset() {
    CComponent::Reset();
    m_No = 0;

    m_PortNum=2;

    m_ParamValue=0;// I, R, C, GY, TF's parameter value

    m_Port[0].m_pBond = NULL;

    m_Port[1].m_pBond = NULL;

    m_Port[0].m_pComponent = this;

    m_Port[1].m_pComponent = this;

}
/*!
 *  \brief Extract Object from a  input stream.
 *  \param ioIS Input stream to read the object from.
 */
void CElement2Port::read(std::istream& ioIS) {
    //Type  Name  ID writeHead portNo  PortList paramNo paramList
    int paramNum;
    //m_Type<<ioIS;
    ioIS>>m_Name;
    ioIS>>m_No;
    ioIS>>m_WriteNo;

    ioIS>>m_PortNum;
    ioIS>>m_Port[0].m_CausalMark;
    ioIS>>m_Port[0].m_PowerDirect;
    ioIS>>m_Port[1].m_CausalMark;
    ioIS>>m_Port[1].m_PowerDirect;

    ioIS>>paramNum;
    ioIS>>m_ParamValue;
}


/*!
 *  \brief Insert an CComponent into a Beagle output stream.
 *  \param ioOS Output stream to write the object into.
 *  \throw  Beagle::CComponentException If the method is not overdefined in a subclass.
 */
void CElement2Port::write(ostream& ioOS) const {
    ioOS<<m_Type<<"\t";
    ioOS<<m_Name<<"\t";
    ioOS<<m_No<<"\t";
    ioOS<<m_WriteNo<<"\t";

    ioOS<<2<<"\t";
    ioOS<<m_Port[0].m_CausalMark<<"\t";
    ioOS<<m_Port[0].m_PowerDirect<<"\t";
    ioOS<<m_Port[1].m_CausalMark<<"\t";
    ioOS<<m_Port[1].m_PowerDirect<<"\t";

    ioOS<<1<<"\t";
    ioOS<<m_ParamValue<<"\t";
    ioOS<<"\n";

}
