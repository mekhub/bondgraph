/*  Bondgraph Modeling System, version 1.0, 11 Jan 2001
 *  Copyright (C) 2001  Michigan State University
 * 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of version 2 of the GNU General Public License as
 *  published by the Free Software Foundation.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *  
 *  Jianjun Hu            (hujianju@msu.edu)
 *  
 *  Computer Science Department
 *  EB 2340 GARAGe Group
 *  Michigan State University
 *  East Lansing, Michigan  48824
 *  USA
 *  
 */

// GraphPrint.cpp: implementation of the CGraphPrint class.
//
//////////////////////////////////////////////////////////////////////

#include "bondgraph/GraphPrint.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGraphPrint::CGraphPrint() {
    Xmax=500;
    Ymax=500;
    Xmin=0;
    Ymin=0;
    currXmax=0;
    currYmax=0;
    for(int i=Xmin;i<Xmax;i++)
        for(int j=Ymin;j<Ymax;j++)
            grid[i][j]=' ';
    lineSymbol[0]='.';
    lineSymbol[1]=',';
    CurrLineSymbol = lineSymbol[0];
}

CGraphPrint::~CGraphPrint() {
}

CGraphPrint::CGraphPrint(int row, int col) {
    Xmax=row;
    Ymax=col;
    Xmin=0;
    Ymin=0;
    currXmax=0;
    currYmax=0;
    for(int i=Xmin;i<Xmax;i++)
        for(int j=Ymin;j<Ymax;j++)
            grid[i][j]=' ';
    lineSymbol[0]='.';
    lineSymbol[1]=',';
    CurrLineSymbol = lineSymbol[0];

}


// Function name	: CGraphPrint::Line
// Description	    :
// Return type		: void
// Argument         : int x
// Argument         : int y
// Argument         : int x1
// Argument         : int y1
// Argument         : char symbol
// Argument         : int direction   CLOCKWISE, OR COUNTER_CLOCKWISE
void CGraphPrint::Line(int x, int y, int x1, int y1, char symbol, int direction) {
    int i;
    if(direction == CLOCKWISE) {
        if(x1>=x && y1<=y) {// 1 right up
            for(i=y;i>=y1;i--)
                Write(x,i,symbol);
            for(i=x;i<=x1;i++)
                Write(i,y1,symbol);
        } else if(x1>=x &&y1>=y) {//2 right below
            for(i=x;i<=x1;i++)
                Write(i,y,symbol);
            for(i=y;i<=y1;i++)
                Write(x1,i,symbol);
        } else if(x1<=x &&y1>=y) {//3 left below
            for(i=y;i<=y1;i++)
                Write(x,i,symbol);
            for(i=x;i>=x1;i--)
                Write(i,y1,symbol);
        } else if(x1<=x &&y1<=y) {
            for(i=x;i>=x1;i--)
                Write(i,y,symbol);
            for(i=y;i>=y1;i--)
                Write(x1,i,symbol);
        }
    } else {//Counter clockwise polyline
        if(x1>=x && y1<=y) {// 1 right up
            for(i=x;i<=x1;i++)
                Write(i,y,symbol);
            for(i=y;i>=y1;i--)
                Write(x1,i,symbol);
        } else if(x1>=x &&y1>=y) {//2 right below
            for(i=y;i<=y1;i++)
                Write(x,i,symbol);
            for(i=x;i<=x1;i++)
                Write(i,y1,symbol);
        } else if(x1<=x &&y1>=y) {//3 left below
            for(i=x;i>=x1;i--)
                Write(i,y,symbol);
            for(i=y;i<=y1;i++)
                Write(x1,i,symbol);
        } else if(x1<=x &&y1<=y) {
            for(i=y;i>=y1;i--)
                Write(x,i,symbol);
            for(i=x;i>=x1;i--)
                Write(i,y1,symbol);
        }
    }
}


// Function name	: CGraphPrint::MoveBlock
// Description	    :
// Return type		: void
// Argument         : int x
// Argument         : int y
// Argument         : int x1
// Argument         : int y1
// Argument         : int what, which side area to move
// Argument         : int dx
// Argument         : int dy
void CGraphPrint::MoveBlock(int x, int y, int x1, int y1, int what, int dx, int dy) {
    int i,j;

    //make copy
    for(i=x;i<=x1;i++)
        for(j=y;j<=y1;j++) {
            copy[i-x][j-y]=grid[i][j];
            grid[i][j]=' ';
        }


    switch(what) {
    case BLOCK_RIGHT_SIDE:
        if(!(IsValid(x1+dx, y)))
            return;
        else
            WriteBlock(x+dx, y+dy, dx+x1, y1+dx, (char**)copy);
        break;
    case BLOCK_DOWN_SIDE:
        if(!(IsValid(x1+dx, y)))
            return;
        else
            WriteBlock(x+dx, y+dy, dx+x1, y1+dx, (char**)copy);
        break;
    case BLOCK_RIGHTDOWN_SIDE:
        if(!(IsValid(x1+dx, y)))
            return;
        else
            WriteBlock(x+dx, y+dy, dx+x1, y1+dx, (char**)copy);
        break;
    case BLOCK_LEFT_SIDE:
        if(!(IsValid(x1+dx, y)))
            return;
        else
            WriteBlock(x+dx, y+dy, dx+x1, y1+dx, (char**)copy);
        break;
    case BLOCK_UP_SIDE:
        if(!(IsValid(x1+dx, y)))
            return;
        else
            WriteBlock(x+dx, y+dy, dx+x1, y1+dx, (char**)copy);
        break;
    case BLOCK_UPLEFT_SIDE:
        if(!(IsValid(x1+dx, y)))
            return;
        else
            WriteBlock(x+dx, y+dy, dx+x1, y1+dx, (char**)copy);
        break;
    case BLOCK_BOX:
        if(!(IsValid(x1+dx, y)))
            return;
        else
            WriteBlock(x+dx, y+dy, dx+x1, y1+dx, (char**)copy);
        break;
    }
}

void CGraphPrint::Write(int x, int y, char sym) {
    if(!IsValid(x,y)) {
        return;
    }

    if(x>currXmax)
        currXmax=x;
    if(y>currYmax)
        currYmax=y;


    //HJJQ  here we don't overwrite an existing useful symbol
    //we write instead beside
    if(!IsLineSymbol(sym)) {
        if(grid[y][x]==' '|| IsLineSymbol(grid[y][x]))
            grid[y][x] = sym;
        else
            grid[y+1][x+1]=sym;
    } else {
        if(grid[y][x]==' '|| IsLineSymbol(grid[y][x]))
            grid[y][x] = sym;
        else
            ;//Don't write anything grid[y+1][x]=sym;

    }


}

void CGraphPrint::WriteString(int x, int y, char*pString,int direction)//Default direction, right
{
    int i;
    int len = strlen(pString);
    switch(direction) {
    case DIRECT_RIGHT:
        for(i=0;i<len;i++)
            if(IsValid(x+1+i,y))
                Write(x+1+i,y,pString[i]);
        break;
    case DIRECT_LEFT:
        for(i=0;i<len;i++)
            if(IsValid(x-len-1+i,y))
                Write(x-len-1+i,y,pString[i]);
        break;
    case DIRECT_UP:
        for(i=0;i<len;i++)
            if(IsValid(x, y-len-1+i))
                Write(x,y-len-1+i,pString[i]);
        break;
    case DIRECT_DOWN:
        for(i=0;i<len;i++)
            if(IsValid(x,y+1+i))
                Write(x,y+1+i,pString[i]);
        break;
    }




}

bool CGraphPrint::IsValid(int x, int y) {
    if(x>=currXmax)
        currXmax=x;
    if(y>=currYmax)
        currYmax=y;

    if (!(x>=Xmin && x<=Xmax && y>=Ymin && y<=Ymax)) {
        printf("CGraphPrint: x, y out of boundary! x= %5d, y=%5d\n", x, y);
        printf("CGraphPrint: Xmin=%d, Xmax=%d, Ymin=%d, Ymax=%d boundary!\n",Xmin,Xmax,Ymin, Ymax);
        exit(-1);
        return false;
    } else
        return true;


}

bool CGraphPrint::IsEmpty(int x, int y, int x1, int y1) {
    int i,j;
    int left, right, top, bottom;

    if(!(IsValid(x,y)&&IsValid(x1,y1))) {
        printf("CGraphPrint: IsEmpty: x,y, x1, y1, out of boundary!\n");
        exit(-1);
    }


    if(x<=x1) {
        left =x;
        right=x1;
    } else	{
        left= x1;
        right=x;
    }

    if(y<y1) {
        top=y;
        bottom=y1;
    } else	{
        top=y1;
        bottom=y;
    }

    for(i=left;i<=right;i++)
        for(j=top;j<=bottom;j++)
            if(grid[i][j]!=' ')
                return false;

    return true;


}

void CGraphPrint::CleanBlock(int x, int y, int x1, int y1) {
    int i,j;
    for(i=x;i<=x1;i++)
        for(j=y;j<=y1;j++)
            grid[i][j]=' ';

}

void CGraphPrint::WriteBlock(int x, int y, int x1, int y1, char **pstring) {
    int i,j;
    if(!(IsValid(x,y)&&IsValid(x1,y1)))
        return;

    for(i=x;i<=x1;i++)
        for(j=y;j<=y1;j++) {
            Write(i,j,pstring[i-x][j-y]);
        }
}



// Function name	: CGraphPrint::IsPathEmpty
// Description	    : check if the |_   _|  |-line is empty or occupied
// Return type		: bool
// Argument         : int x
// Argument         : int y
// Argument         : int x1
// Argument         : int y1
bool CGraphPrint::IsPathEmpty(int x, int y, int x1, int y1,int direction) {
    int i;
    if(direction == CLOCKWISE) {
        if(x1>=x && y1<=y) {//1right up
            for(i=y;i>=y1;i--)
                if(!IsEmpty(x,i))
                    return false;
            for(i=x;i<=x1;i++)
                if(!IsEmpty(i,y1))
                    return false;
        } else if(x1>=x &&y1>=y) {//2right below
            for(i=x;i<=x1;i++)
                if(!IsEmpty(i,y))
                    return false;
            for(i=y;i<=y1;i++)
                if(!IsEmpty(x1,i))
                    return false;
        } else if(x1<=x &&y1>=y) {//2left below
            for(i=y;i<=y1;i++)
                if(!IsEmpty(x,i))
                    return false;
            for(i=x;i>=x1;i--)
                if(!IsEmpty(i,y1))
                    return false;
        } else if(x1<=x &&y1<=y) {
            for(i=x;i>=x1;i--)
                if(!IsEmpty(i,y))
                    return false;
            for(i=y;i>=y1;i--)
                if(!IsEmpty(x1,i))
                    return false;
        }
        return true;
    } else {//Counter clockwise polyline
        if(x1>=x && y1<=y) {// right up
            for(i=x;i<=x1;i++)
                if(!IsEmpty(i,y))
                    return false;
            for(i=y;i>=y1;i--)
                if(!IsEmpty(x1,i))
                    return false;
        } else if(x1>=x &&y1>=y) {// right below
            for(i=y;i<=y1;i++)
                if(!IsEmpty(x,i))
                    return false;
            for(i=x;i<=x1;i++)
                if(!IsEmpty(i,y1))
                    return false;
        } else if(x1<=x &&y1>=y) {// left below
            for(i=x;i>=x1;i--)
                if(!IsEmpty(i,y))
                    return false;
            for(i=y;i<=y1;i++)
                if(!IsEmpty(x1,i))
                    return false;
        } else if(x1<=x &&y1<=y) {
            for(i=y;i>=y1;i--)
                if(!IsEmpty(x,i))
                    return false;
            for(i=x;i>=x1;i--)
                if(!IsEmpty(i,y1))
                    return false;
        }
        return true;
    }
}

bool CGraphPrint::IsEmpty(int x, int y) {
    if(grid[x][y]==' ')
        return true;
    else
        return false;
}



void CGraphPrint::SetLineSymbol(int i, char sym) {
    lineSymbol[i] = sym;
}

bool CGraphPrint::IsLineSymbol(char sym) {
    for( int i=0;i<2;i++) {
        if(sym ==lineSymbol[i])
            return true;
    }
    return false;
}

int CGraphPrint::GetCurrentMaxX() {
    return currXmax;

}

int CGraphPrint::GetCurrentMaxY() {

    return currYmax;
}

void CGraphPrint::Print(FILE *stream) {
    int i,j;
    for(j=0;j<=currYmax;j++) {
        for(i=0;i<=currXmax;i++)
            fprintf(stream, "%c",grid[j][i]);
        fprintf(stream,"\n");
    }
}

void CGraphPrint::Print() {
    Print(stdout);

}

void CGraphPrint::flush() {
    currXmax=0;
    currYmax=0;
    for(int i=Xmin;i<Xmax;i++)
        for(int j=Ymin;j<Ymax;j++)
            grid[i][j]=' ';
    lineSymbol[0]='.';
    lineSymbol[1]=',';
    CurrLineSymbol = lineSymbol[0];
}
