/*  Bondgraph Modeling System, version 1.0, 11 Jan 2001
 *  Copyright (C) 2001  Michigan State University
 * 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of version 2 of the GNU General Public License as
 *  published by the Free Software Foundation.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *  
 *  Jianjun Hu            (hujianju@msu.edu)
 *  www.hujianjun.com     www.DarwinInvention.com
 *
 *  Computer Science Department
 *  EB 2340 GARAGe Group
 *  Michigan State University
 *  East Lansing, Michigan  48824
 *  USA
 *  
 */

// Junction.cpp: implementation of the CJunction class.

//

//////////////////////////////////////////////////////////////////////



#include "bondgraph/StdAfx.h"

#include "bondgraph/Junction.h"
#include "bondgraph/Port.h"
#include "bondgraph/Bond.h"
//#include "BondGraphStatic.h"

//////////////////////////////////////////////////////////////////////

// Construction/Destruction

//////////////////////////////////////////////////////////////////////



CJunction::CJunction()
{

    CComponent::Reset();
    m_WriteNo=-1;

    m_PortNum=0;

    m_ParamValue =0;

    for(int i=0;i<MAX_PORT;i++) {
        m_Port[i].m_pBond=NULL;
        m_Port[i].m_pComponent=this;
    }
}



CJunction::~CJunction()
{


}



void CJunction::SetPortCausalMark(int PortNo, int flag)
{

    m_Port[PortNo].SetCausalMark(flag);
}









//This func is used to contruct embryo bondgraph manually, by initially set the portnum( you already know when you contruct the

//embryo Bondgraph.

int CJunction::SetPortNum(int no) {
    if(no>MAX_PORT) {
        printf("bondgraph package:CJunction:SetPortNum: Exceeding Max portNo, please increase MAX_PORT=%d in stdafx.h!\n",MAX_PORT);
        return -1;
    }

    if (no<0) {
        no = 0;
        return 0;
    }
    m_PortNum = no;
    for( int i =0;i<no;i++) {
        m_Port[i].m_pComponent = this;  // set the port pointer
    }
    return 0;
}



//Add more port to junction

int CJunction::AddPortNum(int no)
{

    int oldNo = m_PortNum;

    m_PortNum+=no;

    for(int i=oldNo; i< m_PortNum;i++) {
        m_Port[i].m_pBond = NULL;
        m_Port[i].m_pComponent = this;
    }

    return m_PortNum;//return the total portnum



}


void CJunction::operator =(CJunction &junction) {

    int i;
    for(i=0;i<MAX_PORT;i++) {
        if(i<junction.m_PortNum)
            m_Port[i] = junction.m_Port[i];
        else
            m_Port[i] = *(new CPort);
    }


    m_No=junction.m_No;// int
    m_Name=junction.m_Name;  //
    m_Type=junction.m_Type;  //
    m_ParamValue=junction.m_ParamValue;
    m_WriteNo=junction.m_WriteNo;//
    m_PortNum=junction.m_PortNum;//

}

void CJunction::SetPowerDirect(int powerdirection, int portNo) {
    CPort* pOtherEndPort;

    if(portNo>= m_PortNum)
        return;

    m_Port[portNo].SetPowerDirect(powerdirection);
    pOtherEndPort=(&m_Port[portNo]==m_Port[portNo].m_pBond->m_pFromPort)?
                  m_Port[portNo].m_pBond->m_pToPort:m_Port[portNo].m_pBond->m_pFromPort;

    pOtherEndPort->SetPowerDirect((powerdirection==IN)?OUT:IN);
}

// Maximal automatic Power direction assignment reasonging routine,
// not complete!
int CJunction::SetPowerDirect(int direction, CPort *pPort) {

    //Junction OUT causality  reasoning
    int i;
    int status;  //causality set status, 0 success, -1 conflict
    CPort* pNewPort;

    //if junction has m_PortNum-1 IN(OUT) in, then the last one must be OUT(IN)!
    int INNum=0, UnsetNum=0, UnsetPortNo;
    for(i=0;i<m_PortNum;i++) {
        if(!m_Port[i].IsPowerDirectDefined()) {
            UnsetNum++;
            UnsetPortNo=i;
        } else if(m_Port[i].GetPowerDirect()==direction)
            INNum++;
    }

    if(INNum == m_PortNum-1 && UnsetNum==1) {

        pNewPort = &m_Port[UnsetPortNo];
        //check if set
        if(pNewPort->IsPowerDirectDefined()) {
            if(pNewPort->IsPowerDirectEqual((direction==IN)?OUT:IN))
                return -1;// two OUT must be different
        } else {
            pNewPort->SetPowerDirect((direction==IN)?OUT:IN);//here !flag = false( IN causality)

            if(pNewPort->m_pBond->m_pFromPort==pNewPort) {
                pNewPort->m_pBond->m_pToPort->SetPowerDirect(direction);// check is same or opposite?
                status = pNewPort->m_pBond->m_pToPort->m_pComponent->
                         SetPowerDirect(direction,pNewPort->m_pBond->m_pToPort);
                if(status==-1)
                    return -1;
            } else {
                pNewPort->m_pBond->m_pFromPort->SetPowerDirect(direction);//check is same or opposite?
                status = pNewPort->m_pBond->m_pFromPort->m_pComponent->
                         SetPowerDirect(direction,pNewPort->m_pBond->m_pFromPort);
                if(status==-1)
                    return -1;
            }
        }
        return 0;
    } else
        return 0;
}

//connect the two port of pBond to the junction to construct a self-loop
//default power direction condition: connect from this junction to energy absorbing junction!

int CJunction::LinkToSelf(CBond *pBond) {
    int i;

    //add first port to junction
    i = AddPortNum(1) - 1;//add a port, return the total portnum, the last one is m_port[totalnum -1]
    if(i+1>MAX_PORT) {
        printf("CJunction::LinkToSelf:\n");
        printf("bondgraph package:CJunction:LinkToSelf:1 Exceeding Max portNo, please increase MAX_PORT=%d in stdafx.h!\n",MAX_PORT);
        return(-1);
    }

    m_Port[i].m_pBond = pBond; //link J to bond
    m_Port[i].SetPowerDirect(OUT);
    pBond->m_pFromPort = &(m_Port[i]);//link bond to C

    //add the second port to the same junction
    i = AddPortNum(1) - 1;//add a port, return the total portnum, the last one is m_port[totalnum -1]
    if(i+1>MAX_PORT) {
        printf("CJunction::LinkToSelf:\n");
        printf("bondgraph package:CJunction:LinkToSelf:2 Exceeding Max portNo, please increase MAX_PORT=%d in stdafx.h!\n",MAX_PORT);
        return -1;
    }

    m_Port[i].m_pBond = pBond; //link J to bond
    m_Port[i].SetPowerDirect(IN);
    pBond->m_pToPort = &(m_Port[i]);//link bond to J
}


// Function name	: CJunction::LinkToJunction
// Description	    : link this juction to another junction using the pBond
// Return type		: void
// Argument         : CJunction *pJuctionNeighbor
// Argument         : CBond *pBond
int CJunction::LinkToJunction(CJunction *pJuctionNeighbor, CBond *pBond) {
    int i;

    //add first port to junction
    i = AddPortNum(1) - 1;//add a port, return the total portnum, the last one is m_port[totalnum -1]
    if(i+1>MAX_PORT) {
        printf("bondgraph package:CJunction:LinkToJunction:1 Exceeding Max portNo, please increase MAX_PORT=%d in stdafx.h!\n",MAX_PORT);
        return -1;
    }

    m_Port[i].m_pBond = pBond;
    m_Port[i].SetPowerDirect(OUT);
    pBond->m_pFromPort = &(m_Port[i]);

    //add the second port to the  junction 2
    i = pJuctionNeighbor->AddPortNum(1) - 1;//add a port, return the total portnum, the last one is m_port[totalnum -1]
    if(i+1>MAX_PORT) {
        printf("bondgraph package:CJunction:LinkToJunction:2 Exceeding Max portNo, please increase MAX_PORT=%d in stdafx.h!\n",MAX_PORT);
        return -1;
    }

    pJuctionNeighbor->m_Port[i].m_pBond = pBond; //link J to bond
    pJuctionNeighbor->m_Port[i].SetPowerDirect(IN);
    pBond->m_pToPort = &(pJuctionNeighbor->m_Port[i]);//link bond to J

}


//find all neighbored junctions of the type 1
int CJunction::FindNeighborJuctions(int option, int type,list<CJunction*>& AggregateJunctionList) {
    list<CJunction*> NeighborJunctions;
    list<CJunction*>::iterator  kj;

    CComponent* pNeighborComp;

    int k=0;
    int i;
    for( i=0;i<m_PortNum;i++) {
        pNeighborComp = (m_Port[i].m_pBond->m_pToPort == &m_Port[i])?
                        m_Port[i].m_pBond->m_pFromPort->m_pComponent:
                        m_Port[i].m_pBond->m_pToPort->m_pComponent;

        if(pNeighborComp->m_WriteNo==0 && option==SIMPLIFY_KEEP_EMBRYO)
            continue; //we don't touch embryo bondgraph

        if(pNeighborComp->m_Type == type && pNeighborComp->m_bVisited==false) {
            NeighborJunctions.push_back((CJunction*)pNeighborComp);
            AggregateJunctionList.push_back((CJunction*)pNeighborComp);
            k++;
            pNeighborComp->m_bVisited=true;//label this as has been found
        }
    }

    //recursively find
    if(!NeighborJunctions.empty()) {
        for(kj = NeighborJunctions.begin();kj!=NeighborJunctions.end();kj++) {
            (*kj)->FindNeighborJuctions(option, type, AggregateJunctionList);
        }
    }
    return i; //how many new junction of type is added
}

void CJunction::Reset() {
    CComponent::Reset();
    m_WriteNo=-1;

    m_PortNum=0;

    m_ParamValue =0;

    for(int i=0;i<MAX_PORT;i++) {
        m_Port[i].m_pBond=NULL;
        m_Port[i].m_pComponent=this;
    }
}


/*!
 *  \brief Extract Object from a  input stream.
 *  \param ioIS Input stream to read the object from.
 */
void CJunction::read(std::istream& ioIS) {
    //Type  Name  ID writeHead portNo  PortList paramNo paramList
    int paramNum;
    //m_Type<<ioIS;
    ioIS>>m_Name;
    ioIS>>m_No;
    ioIS>>m_WriteNo;

    ioIS>>m_PortNum;
    for(int i=0;i<m_PortNum;i++) {
        ioIS>>m_Port[i].m_CausalMark;
        ioIS>>m_Port[i].m_PowerDirect;
    }
    //ioIS>>paramNum;
    //ioIS>>m_ParamValue;
}


/*!
 *  \brief Insert an CComponent into a Beagle output stream.
 *  \param ioOS Output stream to write the object into.
 *  \throw  Beagle::CComponentException If the method is not overdefined in a subclass.
 */
void CJunction::write(ostream& ioOS) const {
    ioOS<<m_Type<<"\t";
    ioOS<<m_Name<<"\t";
    ioOS<<m_No<<"\t";
    ioOS<<m_WriteNo<<"\t";

    ioOS<<m_PortNum<<"\t";
    for(int i=0;i<m_PortNum;i++) {
        ioOS<<m_Port[i].m_CausalMark<<"\t";
        ioOS<<m_Port[i].m_PowerDirect<<"\t";
    }

    ioOS<<"\n";
    //ioOS<<0<<"\t";
    //ioOS<<0<<"\t";
}



