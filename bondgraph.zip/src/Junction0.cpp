/*  Bondgraph Modeling System, version 1.0, 11 Jan 2001
 *  Copyright (C) 2001  Michigan State University
 * 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of version 2 of the GNU General Public License as
 *  published by the Free Software Foundation.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *  
 *  Jianjun Hu            (hujianju@msu.edu)
 *  www.hujianjun.com     www.DarwinInvention.com
 *
 *  Computer Science Department
 *  EB 2340 GARAGe Group
 *  Michigan State University
 *  East Lansing, Michigan  48824
 *  USA
 *  
 */
// Junction0.cpp: implementation of the CJunction0 class.

//

//////////////////////////////////////////////////////////////////////



#include "bondgraph/StdAfx.h"

#include "bondgraph/BondGraph.h"



//////////////////////////////////////////////////////////////////////

// Construction/Destruction

//////////////////////////////////////////////////////////////////////



CJunction0::CJunction0()
{
    CJunction::Reset();

    m_No = 0;

    m_Name = "J0";

    m_Type = JUNCTION0;

    m_PortNum = 0;

    m_WriteNo = -1;



}



CJunction0::~CJunction0()
{


}




// Function name	: CJunction0::SetCausalMark
// Description	    : This function is only be called by other causality set functions
//
// Return type		: int
// Argument         : int Type   the already set port of Gyrate with this causality
// Argument         : CPort* pPort, which port of Gyrate has been set, then use the logic
//						to set the other one
int CJunction0::SetCausalMark(int Type, CPort* pPort)
{

    //Junction effort causality  reasoning
    int i;
    int status;  //causality set status, 0 success, -1 conflict
    CPort* pNewPort;

    //if junction has m_PortNum-1 flow in, then the last one must be Effort!
    if(Type==FLOW) {
        int FlowNum=0, UnsetNum=0, UnsetPortNo;
        for(i=0;i<m_PortNum;i++) {
            if(!m_Port[i].IsCausalityDefined()) {
                UnsetNum++;
                UnsetPortNo=i;
            } else if(m_Port[i].GetCausalityType()==FLOW)
                FlowNum++;
        }

        if(FlowNum == m_PortNum-1 && UnsetNum==1) {

            pNewPort = &m_Port[UnsetPortNo];
            //check if set
            if(pNewPort->IsCausalityDefined()) {
                if(pNewPort->IsCausalityEqual(FLOW))
                    return -1;// two Effort must be different
            } else {
                pNewPort->SetCausalMark(EFFORT);//here !flag = false( flow causality)

                if(pNewPort->m_pBond->m_pFromPort==pNewPort) {
                    pNewPort->m_pBond->m_pToPort->SetCausalMark(FLOW);// check is same or opposite?
                    status = pNewPort->m_pBond->m_pToPort->m_pComponent->SetCausalMark(FLOW,pNewPort->m_pBond->m_pToPort);
                    if(status==-1)
                        return -1;
                } else {
                    pNewPort->m_pBond->m_pFromPort->SetCausalMark(FLOW);//check is same or opposite?
                    status = pNewPort->m_pBond->m_pFromPort->m_pComponent->SetCausalMark(FLOW,pNewPort->m_pBond->m_pFromPort);
                    if(status==-1)
                        return -1;
                }
                return 0;
            }
        } else
            return 0;
    }

    // Junction 0 allow only one effort, one effort reasoning
    //Deal with type = EFFORT

    for( i=0;i<m_PortNum;i++) {
        pNewPort = &m_Port[i];
        if(pNewPort!=pPort)//find other ports
        {
            //check if set
            if(pNewPort->IsCausalityDefined()) {
                if(pNewPort->IsCausalityEqual(FLOW))
                    continue;
                else
                    return -1;// two Effort not allowable
            } else {
                pNewPort->SetCausalMark(FLOW);//here !flag = false( flow causality)

                if(pNewPort->m_pBond->m_pFromPort==pNewPort) {
                    pNewPort->m_pBond->m_pToPort->SetCausalMark(EFFORT);// check is same or opposite?
                    status = pNewPort->m_pBond->m_pToPort->m_pComponent->SetCausalMark(EFFORT,pNewPort->m_pBond->m_pToPort);
                    if(status==-1)
                        return -1;
                } else {
                    pNewPort->m_pBond->m_pFromPort->SetCausalMark(EFFORT);//check is same or opposite?
                    status = pNewPort->m_pBond->m_pFromPort->m_pComponent->SetCausalMark(EFFORT,pNewPort->m_pBond->m_pFromPort);
                    if(status==-1)
                        return -1;
                }
            }
        }
    }
    return 0; //success
}


void CJunction0::Reset() {
    CJunction::Reset();

    m_No = 0;

    m_Name = "J0";

    m_Type = JUNCTION0;

    m_PortNum = 0;

    m_WriteNo = -1;

}
