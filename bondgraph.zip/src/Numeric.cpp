//[][]---------------------------------------------------------[][]

//

//  NUMERIC OPERATION

//

//		- Matrix Calculation,

//		- Eigen values
//

//  Dr. Kisung Seo

//		of Case Center

//

//				start							2000. 2. 22

//

//[][]---------------------------------------------------------[][]





#include "Numeric.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>


#define NR_END 1

#define FREE_ARG char*





//--------------------------------------------------------

//		nrerror()

//        -- Numerical Recipes run-time error messages

//--------------------------------------------------------

void nrerror(char error_text[]) {


    fprintf(stderr,"Numerical Recipes run-time error...\n");

    fprintf(stderr,"%s\n",error_text);

    fprintf(stderr,"...now exiting to system...\n");

    exit(-1);

}







//--------------------------------------------------------

//		*vector()

//        -- allocates a double vector with range [nl..nh]

//--------------------------------------------------------



/*
 
double *vector(int nl, int nh) {
 
	double *v;
 
 
 
	v = (double *)malloc((unsigned) (nh-nl+1)*sizeof(double));
 
	if (!v) nrerror("allocation failure in vector()");
 
	return v-nl;
 
}
 
*/



double *vector(int nl, int nh)

/* allocate a double vector with subscript range v[nl..nh] */

{

    double *v;



    v=(double *)malloc((size_t) ((nh-nl+1+NR_END)*sizeof(double)));

    if (!v)
        nrerror("allocation failure in vector()");

    return v-nl+NR_END;

}





//--------------------------------------------------------

//		*ivector()

//        -- allocates a int vector with range [nl..nh]

//--------------------------------------------------------





int *ivector(int nl, int nh) {

    int *v;



    v = (int *)malloc((unsigned) (nh-nl+1)*sizeof(int));

    if (!v)
        nrerror("allocation failure in ivector()");

    return v-nl;

}



//--------------------------------------------------------

//		*dvector()

//        -- allocates a double vector with range [nl..nh]

//--------------------------------------------------------



double *dvector(int nl, int nh) {

    double *v;



    v = (double *)malloc((unsigned) (nh-nl+1)*sizeof(double));

    if (!v)
        nrerror("allocation failure in dvector()");

    return v-nl;

}



//--------------------------------------------------------

//		*TIvector()

//        -- allocates a double vector with range [nl..nh]

//--------------------------------------------------------



/*
 
TI *TIvector(int nl, int nh) {
 
	TI *v;
 
 
 
	v = (TI *)malloc((unsigned) (nh-nl+1)*sizeof(TI));
 
	if (!v) nrerror("allocation failure in vector()");
 
	return v-nl;
 
}*/



//--------------------------------------------------------

//		free_TIvector()

//        -- frees a TI vector allocated by vector()

//--------------------------------------------------------


/*
void free_TIvector(TI *v, int nl, int nh)
 
/* free a double vector allocated with vector()
 
{
 
	free((FREE_ARG) (v+nl-NR_END));
 
}*/









//--------------------------------------------------------

//		free_vector()

//        -- frees a double vector allocated by vector()

//--------------------------------------------------------



/*void *free_vector(double *v, int nl, int nh) {
 
 
 
	free((char*) (v+nl));
 
}
 
*/



void free_vector(double *v, int nl, int nh)

/* free a double vector allocated with vector() */

{

    free((FREE_ARG) (v+nl-NR_END));

}



//--------------------------------------------------------

//		free_ivector()

//        -- frees a int vector allocated by ivector()

//--------------------------------------------------------



void free_ivector(int *v, int nl, int nh) {



    free((char*) (v+nl));

}



//--------------------------------------------------------

//		free_dvector()

//        -- frees a double vector allocated by dvector()

//--------------------------------------------------------



void free_dvector(double *v, int nl, int nh) {



    free((char*) (v+nl));

}





//-------------------------------------------------------------------

//		**matrix()

//        -- allocates a double matrix with range [nrl..nrh][ncl..nch]

//-------------------------------------------------------------------

/*
 
double **matrix(int nrl, int nrh, int ncl, int nch) {
 
	int i;
 
	double **m;
 
 
 
	m = (double **)malloc((unsigned) (nrh-nrl+1)*sizeof(double*));
 
	if (!m) nrerror("allocation failure 1 in matrix()");
 
	m -= nrl;
 
 
 
	for(i=nrl;i<=nrh;i++) {
 
		m[i] = (double *)malloc((unsigned) (nch-ncl+1)*sizeof(double));
 
		if (!m[i]) nrerror("allocation failure 2 in matrix()");
 
		m[i] -= ncl;
 
	}
 
	return m;
 
}
 
*/



// new version

double **matrix(int nrl, int nrh, int ncl, int nch)

/* allocate a double matrix with subscript range m[nrl..nrh][ncl..nch] */

{

    int i, nrow=nrh-nrl+1,ncol=nch-ncl+1;

    double **m;



    /* allocate pointers to rows */

    m=(double **) malloc((size_t)((nrow+NR_END)*sizeof(double*)));

    if (!m)
        nrerror("allocation failure 1 in matrix()");

    m += NR_END;

    m -= nrl;



    /* allocate rows and set pointers to them */

    m[nrl]=(double *) malloc((size_t)((nrow*ncol+NR_END)*sizeof(double)));

    if (!m[nrl])
        nrerror("allocation failure 2 in matrix()");

    m[nrl] += NR_END;



    m[nrl] -= ncl;



    for(i=nrl+1;i<=nrh;i++)
        m[i]=m[i-1]+ncol;



    /* return pointer to array of pointers to rows */

    return m;

}





//-------------------------------------------------------------------

//		**imatrix()

//        -- allocates a int matrix with range [nrl..nrh][ncl..nch]

//-------------------------------------------------------------------



int **imatrix(int nrl, int nrh, int ncl, int nch) {

    int i;

    int **m;



    m = (int **)malloc((unsigned) (nrh-nrl+1)*sizeof(int*));

    if (!m)
        nrerror("allocation failure 1 in imatrix()");

    m -= nrl;



    for(i=nrl;i<=nrh;i++) {

        m[i] = (int *)malloc((unsigned) (nch-ncl+1)*sizeof(int));

        if (!m[i])
            nrerror("allocation failure 2 in imatrix()");

        m[i] -= ncl;

    }

    return m;

}



//-------------------------------------------------------------------

//		**dmatrix()

//        -- allocates a double matrix with range [nrl..nrh][ncl..nch]

//-------------------------------------------------------------------



double **dmatrix(int nrl, int nrh, int ncl, int nch) {

    int i;

    double **m;



    m = (double**)malloc((unsigned) (nrh-nrl+1)*sizeof(double*));

    if (!m)
        nrerror("allocation failure 1 in dmatrix()");

    m -= nrl;



    for(i=nrl;i<=nrh;i++) {

        m[i] = (double *)malloc((unsigned) (nch-ncl+1)*sizeof(double));

        if (!m[i])
            nrerror("allocation failure 2 in dmatrix()");

        m[i] -= ncl;

    }

    return m;

}



//--------------------------------------------------------

//		free_matrix()

//        -- frees a double matrix allocated by vector()

//--------------------------------------------------------

/*
 
double free_matrix(double **m, int nrl, int nrh, int ncl, int nch) {
 
	int i;
 
 
 
	for(i=nrh;i>=nrl;i--)
 
		free((char*) (m[i]+ncl));
 
	free((char*) (m+nrl));
 
}
 
*/

// new version



void free_matrix(double **m, int nrl, int nrh, int ncl, int nch)

/* free a double matrix allocated by matrix() */

{

    free((FREE_ARG) (m[nrl]+ncl-NR_END));

    free((FREE_ARG) (m+nrl-NR_END));

}



//--------------------------------------------------------

//		free_imatrix()

//        -- frees a int matrix allocated by vector()

//--------------------------------------------------------



void free_imatrix(int **m, int nrl, int nrh, int ncl, int nch) {

    int i;



    for(i=nrh;i>=nrl;i--)

        free((char*) (m[i]+ncl));

    free((char*) (m+nrl));

}



//--------------------------------------------------------

//		free_dmatrix()

//        -- frees a double matrix allocated by vector()

//--------------------------------------------------------



void free_dmatrix(double **m, int nrl, int nrh, int ncl, int nch) {

    int i;



    for(i=nrh;i>=nrl;i--)

        free((char*) (m[i]+ncl));

    free((char*) (m+nrl));

}





double **convert_matrix(double *a, int nrl, int nrh, int ncl, int nch)

/* allocate a double matrix m[nrl..nrh][ncl..nch] that points to the matrix
 
declared in the standard C manner as a[nrow][ncol], where nrow=nrh-nrl+1
 
and ncol=nch-ncl+1. The routine should be called with the address
 
&a[0][0] as the first argument. */

{

    int i,j,nrow=nrh-nrl+1,ncol=nch-ncl+1;

    double **m;



    /* allocate pointers to rows */

    m=(double **) malloc((size_t) ((nrow+NR_END)*sizeof(double*)));

    if (!m)
        nrerror("allocation failure in convert_matrix()");

    m += NR_END;

    m -= nrl;



    /* set pointers to rows */

    m[nrl]=a-ncl;

    for(i=1,j=nrl+1;i<nrow;i++,j++)
        m[j]=m[j-1]+ncol;

    /* return pointer to array of pointers to rows */

    return m;

}



void free_convert_matrix(double **b, int nrl, int nrh, int ncl, int nch)

/* free a matrix allocated by convert_matrix() */

{

    free((FREE_ARG) (b+nrl-NR_END));

}









//--------------------------------------------------------

//		fmmult

//        -- multiply matrix

//			 intout : A, B matrix

//           output : C matrix

//--------------------------------------------------------

void fmmult( double **a, int a_rows, int a_cols,

             double **b, int b_rows, int b_cols, double **y)

/* multiply two matrices a, b, result in y. y must not be same as a or b */

{

    int i, j, k;

    double sum;



    if ( a_cols != b_rows ) {

        fprintf(stderr,"a_cols <> b_rows (%d,%d): fmmult\n", a_cols, b_rows);

        exit(1);

    }



    /*  getchar();

        dmdump( stdout, "Matrix a", a, a_rows, a_cols, "%8.2lf");

        dmdump( stdout, "Matrix b", b, b_rows, b_cols, "%8.2lf");

        getchar();

    */

    //   for ( i=1; i<=a_rows; i++ )

    //      for ( j=1; j<=b_cols; j++ ) {

    for ( i=0; i<a_rows; i++ )

        for ( j=0; j<b_cols; j++ ) {

            //			printf("a[%d][%d] =%f\n",i,j,a[i][j]);

            //			printf("b[%d][%d] =%f\n",i,j,b[i][j]);



        }



    //   for ( i=1; i<=a_rows; i++ )

    //      for ( j=1; j<=b_cols; j++ ) {

    for ( i=0; i<a_rows; i++ )

        for ( j=0; j<b_cols; j++ ) {

            sum = 0.0;

            for ( k=0; k<a_cols; k++ )
                sum += a[i][k]*b[k][j];

            y[i][j] = sum;

            //		 printf("y[%d][%d] =%f\n",i,j,y[i][j]);

        }

}



//--------------------------------------------------------

//		inverse_mat

//        -- inverse matrix

//			 intput : matrix a

//					  no of row,col n

//           output : matrix y

//--------------------------------------------------------

void inverse(double **a, int n, double **y) {

    double d, *col;

    int i,j;

    int *indx;	// integer vector

    //	void ludcmp(), lubksb();

    //	int *ivector();

    //	double *vector();



    indx = ivector( 1, n );

    col = vector( 1, n );



    ludcmp(a, n, indx, &d);

    for(j=1;j<=n;j++) {

        for(i=1;i<=n;i++)

            col[i] = 0.0;

        col[j] = 1.0;

        lubksb(a,n, indx, col);

        for(i=1;i<=n;i++) {

            y[i][j] = col[i];

            //			printf("col[%d]=%f\n",i,col[i]);

        }

    }

    free_ivector( indx, 1, n );

    free_vector( col, 1, n );

}



//--------------------------------------------------------

//		ludcmp

//        -- Lower and Upper decomposition

//			 intput : matrix a

//					  no of row,col n

//           output : vector indx

//					  the no. of intrchanges d

//--------------------------------------------------------

void ludcmp(double **a, int n, int *indx, double *d) {

    int i, imax, j, k;

    double big, dum, sum, temp;

    double *vv;

    //	double *vector();

    //	void nrerror(), free_vector();



    vv = vector(1,n);

    *d=1.0;

    for(i=1;i<=n;i++) {

        big = 0.0;

        for(j=1;j<=n;j++)

            if((temp=fabs(a[i][j])) > big)

                big = temp;

        if(big==0.0)

            nrerror("Singular matrix in routine LUDCMP");

        vv[i]=1.0/big;

    }

    for(j=1;j<=n;j++) {

        for(i=1;i<j;i++) {

            sum=a[i][j];

            for(k=1;k<i;k++)

                sum -= a[i][k]*a[k][j];

            a[i][j] = sum;

        }

        big=0.0;

        for(i=j;i<=n;i++) {

            sum=a[i][j];

            for(k=1;k<j;k++)

                sum -= a[i][k]*a[k][j];

            a[i][j] = sum;

            if((dum=vv[i]*fabs(sum)) >= big) {

                big = dum;

                imax=i;

            }

        }

        if(j != imax) {

            for (k=1;k<=n;k++) {

                dum = a[imax][k];

                a[imax][k] = a[j][k];

                a[j][k] = dum;

            }

            *d = -(*d);

            vv[imax] = vv[j];

        }

        indx[j]=imax;

        if(a[j][j] == 0.0)

            a[j][j] = TINY;

        if(j !=n) {

            dum = 1.0/(a[j][j]);

            for(i=j+1;i<=n;i++)

                a[i][j] *= dum;

        }


    }
    free_vector(vv,1,n);//HJJ !

}



//--------------------------------------------------------------

//		lubksb

//        -- LU back substitution, Solves A*X=B

//			 intput : matrix a(determined by ludcmp)

//					  no of row,col n

//                    vector indx(returned by ludcmp)

//					  vector b(right hand side vector B)

//           output : vector b (returns with solution vector X)

//--------------------------------------------------------------

void lubksb(double **a,  int n, int *indx, double b[]) {

    int i, ii=0, ip, j;

    double sum;



    for(i=1;i<=n;i++) {

        ip = indx[i];

        sum = b[ip];

        b[ip] = b[i];

        if(ii)

            for(j=ii;j<=i-1;j++)

                sum -= a[i][j]*b[j];

        else if(sum)

            ii = i;

        b[i]=sum;

    }

    for(i=n;i>=1;i--) {

        sum = b[i];

        for(j=i+1;j<=n;j++)

            sum -= a[i][j]*b[j];

        b[i] = sum/a[i][i];

    }

}









#define RADIX 2.0



void balanc(double **a, int n)
{

    int last,j,i;

    double s,r,g,f,c,sqrdx;



    sqrdx=RADIX*RADIX;

    last=0;

    while (last == 0) {

        last=1;

        for (i=1;i<=n;i++) {

            r=c=0.0;

            for (j=1;j<=n;j++)

                if (j != i) {

                    c += fabs(a[j][i]);

                    r += fabs(a[i][j]);

                }

            if (c && r) {

                g=r/RADIX;

                f=1.0;

                s=c+r;

                while (c<g) {

                    f *= RADIX;

                    c *= sqrdx;

                }

                g=r*RADIX;

                while (c>g) {

                    f /= RADIX;

                    c /= sqrdx;

                }

                if ((c+r)/f < 0.95*s) {

                    last=0;

                    g=1.0/f;

                    for (j=1;j<=n;j++)
                        a[i][j] *= g;

                    for (j=1;j<=n;j++)
                        a[j][i] *= f;

                }

            }

        }

    }

}

#undef RADIX



#define SWAP(g,h) {y=(g);(g)=(h);(h)=y;}



void elmhes(double **a, int n)
{

    int m,j,i;

    double y,x;



    for (m=2;m<n;m++) {

        x=0.0;

        i=m;

        for (j=m;j<=n;j++) {

            if (fabs(a[j][m-1]) > fabs(x)) {

                x=a[j][m-1];

                i=j;

            }

        }

        if (i != m) {

            for (j=m-1;j<=n;j++)
                SWAP(a[i][j],a[m][j])

                for (j=1;j<=n;j++)
                    SWAP(a[j][i],a[j][m])

                }

        if (x) {

            for (i=m+1;i<=n;i++) {

                if ((y=a[i][m-1]) != 0.0) {

                    y /= x;

                    a[i][m-1]=y;

                    for (j=m;j<=n;j++)

                        a[i][j] -= y*a[m][j];

                    for (j=1;j<=n;j++)

                        a[j][m] += y*a[j][i];

                }

            }

        }

    }

}

#undef SWAP



#define NRANSI



void hqr(double **a, int n, double wr[], double wi[])
{

    int nn,m,l,k,j,its,i,mmin;

    double z,y,x,w,v,u,t,s,r,q,p,anorm;



    anorm=0.0;

    for (i=1;i<=n;i++)

        for (j=IMAX(i-1,1);j<=n;j++)

            anorm += fabs(a[i][j]);

    nn=n;

    t=0.0;

    while (nn >= 1) {

        its=0;

        do {

            for (l=nn;l>=2;l--) {

                s=fabs(a[l-1][l-1])+fabs(a[l][l]);

                if (s == 0.0)
                    s=anorm;

                if ((double)(fabs(a[l][l-1]) + s) == s)
                    break;

            }

            x=a[nn][nn];

            if (l == nn) {

                wr[nn]=x+t;

                wi[nn--]=0.0;

            } else {

                y=a[nn-1][nn-1];

                w=a[nn][nn-1]*a[nn-1][nn];

                if (l == (nn-1)) {

                    p=0.5*(y-x);

                    q=p*p+w;

                    z=sqrt(fabs(q));

                    x += t;

                    if (q >= 0.0) {

                        z=p+SIGN(z,p);

                        wr[nn-1]=wr[nn]=x+z;

                        if (z)
                            wr[nn]=x-w/z;

                        wi[nn-1]=wi[nn]=0.0;

                    } else {

                        wr[nn-1]=wr[nn]=x+p;

                        wi[nn-1]= -(wi[nn]=z);

                    }

                    nn -= 2;

                } else {

                    //if (its == 30) nrerror("Too many iterations in hqr");
                    //if (its == 50) nrerror("Too many iterations in hqr");//HJJ comment
                    if (its == 300) nrerror("Too many iterations in hqr");//HJJ

                    if (its == 10 || its == 20) {

                        t += x;

                        for (i=1;i<=nn;i++)
                            a[i][i] -= x;

                        s=fabs(a[nn][nn-1])+fabs(a[nn-1][nn-2]);

                        y=x=0.75*s;

                        w = -0.4375*s*s;

                    }

                    ++its;

                    for (m=(nn-2);m>=l;m--) {

                        z=a[m][m];

                        r=x-z;

                        s=y-z;

                        p=(r*s-w)/a[m+1][m]+a[m][m+1];

                        q=a[m+1][m+1]-z-r-s;

                        r=a[m+2][m+1];

                        s=fabs(p)+fabs(q)+fabs(r);

                        p /= s;

                        q /= s;

                        r /= s;

                        if (m == l)
                            break;

                        u=fabs(a[m][m-1])*(fabs(q)+fabs(r));

                        v=fabs(p)*(fabs(a[m-1][m-1])+fabs(z)+fabs(a[m+1][m+1]));

                        if ((double)(u+v) == v)
                            break;

                    }

                    for (i=m+2;i<=nn;i++) {

                        a[i][i-2]=0.0;

                        if (i != (m+2))
                            a[i][i-3]=0.0;

                    }

                    for (k=m;k<=nn-1;k++) {

                        if (k != m) {

                            p=a[k][k-1];

                            q=a[k+1][k-1];

                            r=0.0;

                            if (k != (nn-1))
                                r=a[k+2][k-1];

                            if ((x=fabs(p)+fabs(q)+fabs(r)) != 0.0) {

                                p /= x;

                                q /= x;

                                r /= x;

                            }

                        }

                        if ((s=SIGN(sqrt(p*p+q*q+r*r),p)) != 0.0) {

                            if (k == m) {

                                if (l != m)

                                    a[k][k-1] = -a[k][k-1];

                            } else

                                a[k][k-1] = -s*x;

                            p += s;

                            x=p/s;

                            y=q/s;

                            z=r/s;

                            q /= p;

                            r /= p;

                            for (j=k;j<=nn;j++) {

                                p=a[k][j]+q*a[k+1][j];

                                if (k != (nn-1)) {

                                    p += r*a[k+2][j];

                                    a[k+2][j] -= p*z;

                                }

                                a[k+1][j] -= p*y;

                                a[k][j] -= p*x;

                            }

                            mmin = nn<k+3 ? nn : k+3;

                            for (i=l;i<=mmin;i++) {

                                p=x*a[i][k]+y*a[i][k+1];

                                if (k != (nn-1)) {

                                    p += z*a[i][k+2];

                                    a[i][k+2] -= p*r;

                                }

                                a[i][k+1] -= p*q;

                                a[i][k] -= p;

                            }

                        }

                    }

                }

            }

        } while (l < nn-1);

    }

}

void eigen_values(double **a, int size) {
    double *wr,*wi, *wk;
    wr=vector(1,size);
    wi=vector(1,size);
    wk=vector(1,size);

    balanc(a,size);
    elmhes(a,size);
    hqr(a,size,wr,wi);
    hqr(a,size,wr,wk);

    free_vector(wr,1,size);
    free_vector(wi,1,size);
    free_vector(wk,1,size);

}

#undef NRANSI









