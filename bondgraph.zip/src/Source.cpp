/*  Bondgraph Modeling System, version 1.0, 11 Jan 2001
 *  Copyright (C) 2001  Michigan State University
 * 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of version 2 of the GNU General Public License as
 *  published by the Free Software Foundation.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *  
 *  Jianjun Hu            (hujianju@msu.edu)
 *  www.hujianjun.com     www.DarwinInvention.com
 *
 *  Computer Science Department
 *  EB 2340 GARAGe Group
 *  Michigan State University
 *  East Lansing, Michigan  48824
 *  USA
 *  
 */
// Source.cpp: implementation of the CSourceEffort class.

//

//////////////////////////////////////////////////////////////////////



#include "bondgraph/Source.h"



//////////////////////////////////////////////////////////////////////

// Construction/Destruction

//////////////////////////////////////////////////////////////////////



CSourceEffort::CSourceEffort()
{


    CElement1Port::Reset();

    m_Name = "SE";

    m_Type = SE;

    m_ParamValue = 0;//10 V


    //   m_Port[0].SetPowerDirect(OUT);

    //   m_Port[0].SetCausalMark(FLOW);


}



CSourceEffort::~CSourceEffort()
{


}



//////////////////////////////////////////////////////////////////////

// CSourceFlow Class

//////////////////////////////////////////////////////////////////////



//////////////////////////////////////////////////////////////////////

// Construction/Destruction

//////////////////////////////////////////////////////////////////////



CSourceFlow::CSourceFlow()
{

    CElement1Port::Reset();
    m_No = 0;

    m_Name = "SF";

    m_Type = SF;

    m_ParamValue = 0;//10 V

    m_PortNum = 1;

    m_WriteNo = -1;

}



CSourceFlow::~CSourceFlow()
{


}


void CSourceEffort::Reset() {
    CElement1Port::Reset();
    CSourceEffort();
}

void CSourceFlow::Reset() {
    CElement1Port::Reset();
    CSourceFlow();
}
