/*  Bondgraph Modeling System, version 1.0, 11 Jan 2001
 *  Copyright (C) 2001  Michigan State University
 * 
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of version 2 of the GNU General Public License as
 *  published by the Free Software Foundation.
 * 
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 * 
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *  
 *  Jianjun Hu            (hujianju@msu.edu)
 *  www.hujianjun.com     www.DarwinInvention.com
 *
 *  Computer Science Department
 *  EB 2340 GARAGe Group
 *  Michigan State University
 *  East Lansing, Michigan  48824
 *  USA
 *  
 */

// Transformer.cpp: implementation of the CTransformer class.
//
//////////////////////////////////////////////////////////////////////



#include "bondgraph/StdAfx.h"

#include "bondgraph/BondGraph.h"



//////////////////////////////////////////////////////////////////////

// Construction/Destruction

//////////////////////////////////////////////////////////////////////



CTransformer::CTransformer()
{
    CElement2Port::Reset();

    m_Type = TF;
    m_Name = "TF";

    m_ParamValue=1;// I, R, C, GY, TF's parameter value


}



CTransformer::~CTransformer()
{


}



// This routine is called when there is one port's causality be set as flag

int CTransformer::SetCausalMark(int Type, CPort* pPort)
{
    CPort* pNewPort;

    if(&m_Port[0]==pPort)
        pNewPort = &m_Port[1];
    else
        pNewPort = &m_Port[0];

    //check the newport is set causality or not
    if(pNewPort->IsCausalityDefined()) { //then check conflict
        if(!pNewPort->IsCausalityEqual(pPort->GetCausalityType()))
            return 0;//consistent
        else
            return -1; //conflict

    } else {//the newport is not set causality

        pNewPort->SetCausalMark((Type==EFFORT)?FLOW:EFFORT);//set as opposite for two port of the Gyrate

        if(pNewPort->m_pBond->m_pFromPort==pNewPort)// set the port at other end of the bond
        {
            // set as opposite for the two port of the same bond
            pNewPort->m_pBond->m_pToPort->SetCausalMark(Type);
            return pNewPort->m_pBond->m_pToPort->m_pComponent->SetCausalMark
                   (Type, pNewPort->m_pBond->m_pToPort);
        } else {
            pNewPort->m_pBond->m_pFromPort->SetCausalMark(Type);
            return pNewPort->m_pBond->m_pFromPort->m_pComponent->SetCausalMark
                   (Type, pNewPort->m_pBond->m_pFromPort);
        }

    }
}


void CTransformer::Reset() {
    CElement2Port::Reset();
    CTransformer();
}
